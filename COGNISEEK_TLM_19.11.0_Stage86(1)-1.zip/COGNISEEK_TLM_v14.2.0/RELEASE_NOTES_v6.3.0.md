# COGNISEEK TLM v6.3.0 — Evidence Interpretation and Reviewer Appraisal

## Purpose
Connect retrieved passage candidates to explicit, append-only reviewer appraisal without treating retrieval as proof.

## Added
- `POST /api/cognitive-runtime/passage-appraisals`: record a reviewer appraisal linked to a passage in a specific runtime report.
- `GET /api/cognitive-runtime/reports/{report_id}/passage-appraisals`: list appraisal history and per-passage disagreement summary.
- Direction values: `+1` SUPPORTS, `-1` CONTRADICTS, `0` NO_INTERPRETABLE_DIRECTION (M-RBAM F4).
- Optional paired pre/post appraisal scores (0–10).
- Reviewer rationale, target claim, reviewer label, evidence reference, timestamp, and append-only appraisal ID.
- Disagreement is preserved; later reviews do not overwrite earlier reviews.

## M-RBAM handling
For D = +1 or -1:
- ΔA = A_post − A_pre
- U = D × ΔA

For D = 0:
- Form = F4
- U = null / undefined

No review record means NOT YET APPRAISED; it is not F4. F4 is an explicit reviewer determination that the evidence has no interpretable direction.

## Safety and governance boundaries
- Only passage references already linked to the runtime report can be appraised.
- Reviewer identity and judgement are caller-supplied, not independently authenticated.
- An appraisal is an interpretation record, not proof of source authenticity or scientific truth.
- Reviewer disagreement is surfaced, not silently resolved.
- This release does not automatically approve findings or release answers.
- v5.9 company policy gate remains separate and mandatory for governed output release.
- No model weights are trained or updated.

## Validation
- Full test suite: 389 passed, 0 failed.
- Python compileall: passed.
- ZIP integrity: passed.
