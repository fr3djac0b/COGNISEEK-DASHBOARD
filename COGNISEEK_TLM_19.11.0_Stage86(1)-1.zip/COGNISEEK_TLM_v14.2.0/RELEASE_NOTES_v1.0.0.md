# COGNISEEK TLM v1.0.0 — Optional Semantic Retrieval and Hybrid RAG

## Added
- Optional OpenAI-compatible embeddings provider using `/embeddings`.
- Configurable `EMBEDDING_BASE_URL`, `EMBEDDING_API_KEY`, and `EMBEDDING_MODEL`.
- Persistent chunk vectors in SQLite, keyed by project and embedding model.
- Cosine similarity ranking for semantic retrieval.
- Reciprocal Rank Fusion (RRF) to combine lexical and semantic result lists without mixing their raw score scales.
- Lexical fallback when embeddings are not configured or the embedding request fails.
- `GET /api/retrieval/status` reports provider configuration and stored vector counts.

## Setup
Set `EMBEDDING_MODEL` and credentials in the server environment. For a separate compatible provider, set `EMBEDDING_BASE_URL` and `EMBEDDING_API_KEY`. Re-ingest documents after configuring embeddings to create vectors.

## Boundaries
- No embedding model is bundled or trained by COGNISEEK.
- Semantic search is inactive until a compatible provider is configured and documents have been embedded.
- Existing v0.9 documents are not automatically embedded; re-ingest them or implement a backfill process.
- RRF combines retrieval ranks; it does not establish truth or evidence support.
- No live web crawling, source authentication, cross-source truth adjudication, or autonomous training.
