# COGNISEEK TLM v11.7.0 — Authorization Policy Hardening

## Implemented
- Added a central role-policy registry for the seven v11.4 routes that already used the verified identity boundary.
- Updated those route handlers to consume the central policy constants instead of embedding role lists.
- Added a second project-membership check inside the API authorization boundary. A returned principal whose `projects` collection does not include the requested project is denied and audited.
- Added tests for cross-project denial, insufficient role denial, administrator role hierarchy, policy registry completeness and unknown-policy rejection.

## Deliberate scope
This release does not automatically protect all 299 route entries. The v11.6 scanner identified routes requiring manual review, but its source-scan findings are not sufficient evidence to assign safe access policies to every legacy endpoint. No blanket ADMIN lock was applied. Unlisted routes remain outside the v11.7 explicit policy registry and must not be interpreted as certified public endpoints.

## Run
```bash
python -m pytest -q tests/test_v11_7_authorization_remediation.py
python -m pytest -q
python -m compileall -q app scripts
```

## Security limitations
- Tests use controlled identity-provider doubles; no live OIDC/JWKS provider was contacted.
- No penetration test or exhaustive route-level HTTP authorization test was performed.
- Existing API-key middleware remains optional and is not a substitute for project-scoped identity.
- This release is authorization hardening, not production security certification.

## Preservation
`app/research/m_rbam.py` is not modified. No M-RBAM formulas, thresholds, labels or protocol definitions are changed.
