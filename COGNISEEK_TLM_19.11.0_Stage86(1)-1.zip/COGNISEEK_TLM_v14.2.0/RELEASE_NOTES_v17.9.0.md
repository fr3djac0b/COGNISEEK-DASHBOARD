# COGNISEEK TLM v17.9.0

Stage 64: Autonomous Claim Extraction. Additive release from immutable v17.8.0 baseline.

Extracts stable sentence-level claim candidates with document lineage. It does not claim semantic understanding; all candidates remain unreviewed.
