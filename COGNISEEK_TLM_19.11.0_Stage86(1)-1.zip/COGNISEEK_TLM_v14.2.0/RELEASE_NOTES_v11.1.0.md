# COGNISEEK TLM v11.1.0 — End-to-End Episode Review Completion

## Release objective
Connect human appraisal to the v11.0 integrated request lifecycle and expose review coverage, review history, and completion checks without changing the established appraisal mathematics or protocol selection.

## Additions
- `app/episode_review_completion.py`: links integrated request runs to the existing unified cognitive runtime appraisal engine.
- Four API routes:
  - `POST /api/cognitive-runtime/integrated-requests/{run_id}/appraisals`
  - `GET /api/cognitive-runtime/integrated-requests/{run_id}/review-status`
  - `POST /api/cognitive-runtime/integrated-requests/{run_id}/complete-review`
  - `GET /api/cognitive-runtime/integrated-requests/{run_id}/review-history`
- Append-only linkage and completion-check events in `integrated_review_completion_events`.
- Review coverage distinguishes `PENDING` from `F4_NO_INTERPRETABLE_DIRECTION`.
- Multiple appraisals remain visible; conflicting directions are surfaced as `DISAGREEMENT_REQUIRES_REVIEW`.
- Completion is a coverage measure only; it never authorizes answer release.

## Mathematical and protocol preservation
- `app/research/m_rbam.py` is byte-for-byte unchanged from the v11.0.0 archive.
- The new module delegates appraisal calculations to `unified_cognitive_runtime.appraise_retrieved_passage`.
- No formulas, thresholds, categories, protocol defaults, or historical appraisal records were modified.
- Both existing `strict_alignment_v0.2` and `directional_v0.1` protocols remain governed by their original implementation. v11.1 does not force a new F1–F4 classification over the strict protocol's existing output.

## Controls and limitations
- Run and report are resolved within the requested project.
- A passage must be linked to the integrated run and underlying report.
- Reviewer identity remains caller-supplied and is not authenticated by this module.
- A completed review is not evidence sufficiency, source independence, truth determination, or release approval.
- Existing company policy and answer-release workflow remain the only release authority.
- Live external model-provider testing was not performed as part of this release.
