# v10.9.0 Test Plan

1. Empty-project evaluation and append-only persistence.
2. Project isolation for feedback metrics.
3. Separate reporting of support, contradiction, neutral, indeterminate, and reviewer disagreement.
4. Reject blank project identifiers.
5. Full inherited regression suite with isolated database.
6. Compileall, fresh FastAPI import and route checks, archive integrity.
