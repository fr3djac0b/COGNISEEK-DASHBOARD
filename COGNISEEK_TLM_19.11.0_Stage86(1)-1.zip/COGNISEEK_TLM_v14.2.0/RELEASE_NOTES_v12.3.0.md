# COGNISEEK TLM v12.3.0

## Milestone
**Episode and Learning Route Authorization**

This release protects 12 episode and learning API method/path entries with the
existing signed identity boundary and project-scoped role policies.

### Episode routes
- `GET /api/episodes` — ADMIN, REVIEWER, OPERATOR, VIEWER
- `GET /api/episodes/retrieve` — ADMIN, REVIEWER, OPERATOR, VIEWER
- `GET /api/episodes/outcomes` — ADMIN, REVIEWER, OPERATOR, VIEWER
- `POST /api/episodes/outcomes` — ADMIN, OPERATOR
- `POST /api/episodes/compare` — ADMIN, REVIEWER
- `POST /api/episodes/reconcile` — ADMIN, REVIEWER
- `GET /api/episodes/reconciliations` — ADMIN, REVIEWER, OPERATOR, VIEWER

### Learning routes
- `GET /api/learning/appraisals` — ADMIN, REVIEWER, OPERATOR, VIEWER
- `POST /api/learning/appraisals` — ADMIN, OPERATOR
- `GET /api/learning/outcomes` — ADMIN, REVIEWER, OPERATOR, VIEWER
- `POST /api/learning/outcomes` — ADMIN, REVIEWER
- `GET /api/learning/evaluation` — ADMIN, REVIEWER, OPERATOR, VIEWER

### Security behavior
- All newly protected routes require a verified bearer token.
- Project membership is rechecked by the authorization boundary.
- Episode comparisons and reconciliations are reviewer-level actions.
- Learning outcome submission is reviewer-level; appraisal creation is operator-level.
- Authorization outcomes are written to the existing append-only identity audit.
- Cross-project requests are rejected.

### Verification
- New authorization integration tests: 9 passed.
- Full regression suite: 793 passed, 0 failed.
- Route governance register: 299 entries; 23 explicit role policies;
  218 review-required; 58 unclassified; 0 declared public.
- Python compileall: PASS.
- FastAPI import: PASS; 307 routes registered.
- M-RBAM source unchanged byte-for-byte from v12.2.0.

### Scope limitations
This is a selected route remediation, not a complete authorization audit.
Other learning, trajectory, memory, cognitive-runtime, and episode-related
endpoints remain for future review. Live identity-provider/JWKS validation,
deployed penetration testing, and external security certification were not
performed.
