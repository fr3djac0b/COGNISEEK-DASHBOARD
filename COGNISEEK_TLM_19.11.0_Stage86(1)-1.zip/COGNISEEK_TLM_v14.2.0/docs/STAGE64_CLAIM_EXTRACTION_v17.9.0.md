# COGNISEEK TLM v17.9.0 — Stage 64: Autonomous Claim Extraction

Baseline: v17.8.0 (immutable).

## Scope

Extracts stable sentence-level claim candidates with document lineage. It does not claim semantic understanding; all candidates remain unreviewed.

## Files
- `app/stage64_claim_extraction.py`
- `tests/test_v17_9_0_stage64_claim_extraction.py`

## Validation boundary
This stage is additive. Its focused tests validate the documented deterministic behaviour only; they do not establish production readiness, model quality, factual accuracy or autonomous intelligence.
