# Stage 59 — Two-Times Reasoning Integration (E1/E2)

## Purpose
Stage 59 adds an auditable two-episode appraisal protocol. E1 captures an initial answer and freezes its evidence, assumptions, confidence and quality score. E2 is a separately recorded second appraisal with an explicit self-challenge and its own evidence references. The engine compares the two records without modifying E1.

## Workflow
1. `create_e1(...)` records the initial question, answer, conclusion, confidence, quality score, evidence references and assumptions. A SHA-256 digest is computed over the immutable snapshot payload.
2. `record_e2(...)` records the second appraisal exactly once for that episode. The caller supplies the second answer, conclusion, evidence references and self-challenge.
3. `record_falsification(...)` records an attempt to test an alternative or disconfirming hypothesis. Results are `survived`, `weakened`, `refuted` or `inconclusive`.
4. `compare(...)` reports conclusion agreement, evidence-reference overlap, an independence proxy, quality-score difference and falsification outcomes.
5. `finalize(...)` records one human/system-supplied appraisal decision: `retain_e1`, `revise_with_e2`, `qualify` or `withhold`.

## Measurement
For E1 evidence-reference set A and E2 set B:

`overlap = |A ∩ B| / |A ∪ B|`

`independence_proxy = 1 - overlap`

For quality scores Q1 and Q2, each constrained to [0,1]:

`incremental_quality_value = Q2 - Q1`

These are descriptive metrics. Distinct reference identifiers do not prove independent origins; duplicated or syndicated sources can appear under different identifiers. A supplied quality score is only as reliable as its evaluator and rubric. The module does not estimate statistical significance or causal effect.

## Safeguards
- SQLite triggers reject updates and deletes to E1 snapshots.
- E2 is stored in a separate table and cannot overwrite E1.
- Only one E2 and one final decision are accepted per episode/project.
- Evidence references are retained separately for both episodes.
- Agreement is explicitly not treated as proof.
- The module does not retrieve evidence, generate answers, authenticate evaluators, promote memory, change weights, or activate lessons in live reasoning.

## Example
```python
from app.stage59_two_times import TwoTimesEngine
engine = TwoTimesEngine("data/two_times.db")
e1 = engine.create_e1(
    question="Is the claim supported?", answer="Initial assessment",
    conclusion="supported", confidence=0.65, quality_score=0.60,
    evidence_refs=["source-1", "source-2"], assumptions=["sources are current"])
episode = e1["episode_id"]
engine.record_e2(
    episode, answer="Second assessment", conclusion="qualified support",
    confidence=0.72, quality_score=0.68,
    evidence_refs=["source-3", "source-4"],
    self_challenge="What credible evidence would disprove the initial conclusion?")
engine.record_falsification(
    episode, hypothesis="The initial result is explained by source bias",
    method="review source provenance and seek disconfirming evidence",
    result="inconclusive", evidence_refs=["source-5"])
comparison = engine.compare(episode)
```

## Limitations and status
This is an orchestration and audit component, not a complete autonomous two-pass reasoning system. E1 and E2 answers, evidence references, confidence and quality scores are provided by the calling application. No live retrieval adapter or model-inference adapter is connected in this stage. The independence score is a reference-overlap heuristic, not source-lineage analysis. The final decision is recorded, not autonomously selected. Production security, concurrency, authentication and load testing remain outstanding.
