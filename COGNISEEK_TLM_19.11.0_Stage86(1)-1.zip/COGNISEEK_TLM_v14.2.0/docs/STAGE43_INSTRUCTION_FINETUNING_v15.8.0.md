# Stage 43 — Instruction Fine-tuning (v15.8.0)

## Purpose
Add supervised instruction fine-tuning to the small CPU reference TLM. The stage turns prompt/response examples into response-token training targets while retaining the prompt as conditioning context.

## Added architecture
- `InstructionExample`: validated stable ID, prompt token IDs and response token IDs.
- `InstructionDataset`: separate non-empty train and validation splits; unique IDs and vocabulary-bound checks.
- `format_instruction`: deterministic human-readable instruction/response serialization.
- `FineTuningConfig`: validated epochs, learning rate, gradient clipping, context limit and deterministic shuffle seed.
- `InstructionFineTuner`: autoregressive response-only loss, gradient clipping, validation loss/token accuracy, best validation tracking and resumable progress state.
- Existing `CheckpointManager.save_engine/restore_engine` can persist the fine-tuner model, Adam state and progress using the same generic trainer interface.

## Training objective
For prompt tokens `p` and response tokens `r`, each response token is predicted from the prompt plus preceding response tokens. Prompt tokens are conditioning context and are not directly included as supervised targets. The objective is mean next-token cross-entropy over response tokens:

`L = -(1/N) Σ_t log P(r_t | p, r_<t)`

## Verification
Stage 43 targeted tests cover deterministic formatting, data validation, vocabulary checks, response-only supervision, training updates, validation metrics, checkpoint round-trip and progress validation. Stage 42 checkpoint regression is also run alongside Stage 43 tests.

## Boundaries and limitations
- This is supervised fine-tuning (SFT), not preference optimization, RLHF, DPO or online learning.
- Inputs are already-tokenized IDs; tokenizer integration and robust chat-template/tokenizer version pinning remain future work.
- The reference implementation performs one optimizer update per response token and is intended for small CPU experiments, not large-scale GPU/distributed training.
- No instruction corpus is bundled. Only appropriately licensed and quality-reviewed data should be used.
- Validation token accuracy is a simple diagnostic, not a complete measure of instruction-following quality.
