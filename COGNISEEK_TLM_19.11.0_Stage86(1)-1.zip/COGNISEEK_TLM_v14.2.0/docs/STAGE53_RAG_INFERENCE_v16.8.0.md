# Stage 53 — Retrieval-Augmented Inference Integration (v16.8.0)

## Purpose
Connect Stage 52 semantic/lexical hybrid retrieval to Stage 51 live inference through
an auditable episode workflow.

## Flow
Query intake -> optional hybrid retrieval -> evidence qualification/provenance ->
bounded context assembly -> Stage 51 `runtime.generate()` -> episode completion record.

## Evidence discipline
Retrieved passages are labelled `historical_retrieved_unverified`. Their chunk ID,
document ID, title, source name, rank, channel and available scores are preserved.
The prompt treats retrieved text as untrusted data, not instructions. Generated answers
are labelled `not_verified` and are not automatically inserted into the Stage 52 index.

## Persistence
`EpisodeStore` uses SQLite to record query, retrieval state, evidence snapshot, prompt,
response, status and error. This is a local append-oriented episode ledger, not yet a
distributed memory service, user-isolated tenancy system, or verified fact store.

## Usage
```python
from app.stage51_live_inference import LiveInferenceRuntime
from app.stage52_semantic_intelligence import SemanticIndex
from app.stage53_rag_inference import EpisodeStore, RAGInferencePipeline

runtime = LiveInferenceRuntime.from_artifacts("model.ckpt", "tokenizer.json")
index = SemanticIndex("data/semantic.sqlite")
episodes = EpisodeStore("data/episodes.sqlite")
rag = RAGInferencePipeline(runtime, index, episodes, project="default")
result = rag.run("Ask a question", retrieval_enabled=True, max_new_tokens=80)
print(result["answer"], result["sources"])
```

## Limitations
- Retrieval uses Stage 52's configured embedding provider and hybrid search; no new embedding model is trained here.
- Generation uses the existing Stage 51 TLM runtime and greedy decoding.
- Prompt budgeting is character-based, not exact tokenizer-token accounting.
- The model may still hallucinate; provenance is traceability, not proof of correctness.
- No automatic fact verification, user feedback adjudication, contradiction resolution,
  multi-user access controls, streaming, batching, or production API server is added.
- The stage tests use fake retrieval/runtime components; they validate orchestration, not
  the linguistic quality of trained model outputs.
