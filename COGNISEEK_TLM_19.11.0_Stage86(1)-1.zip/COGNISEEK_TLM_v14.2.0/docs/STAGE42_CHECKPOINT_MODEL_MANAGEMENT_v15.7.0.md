# Stage 42 — Checkpoint and Model Management (v15.7.0)

## Purpose

Stage 41 can train the reference MultiLayerGQATLM model, but model weights and Adam moments were not yet persisted as a single resumable artifact. Stage 42 adds versioned, integrity-checked checkpoint files and trainer-progress restoration.

## Implemented

- Atomic JSON checkpoint writes using a temporary file followed by `os.replace`.
- Model configuration and weight snapshots through the model's existing `state_dict` API.
- Adam optimizer state: step counter, learning rate, beta values, epsilon, first moments, and second moments.
- Strict format/version checks, parameter-shape checks, finite-number checks, and SHA-256 integrity verification.
- Trainer progress snapshots containing epoch history, best validation loss/epoch, early-stop status, and next epoch.
- `save_engine` / `restore_engine` convenience methods for Stage 41 `PretrainingEngine` instances.
- Best-validation checkpoint helper that only replaces the best artifact when validation loss improves.
- Checkpoint inventory listing, including invalid artifacts marked as invalid rather than silently accepted.

## Minimal use

```python
from app.checkpoint_manager import CheckpointManager

manager = CheckpointManager("artifacts/checkpoints")

# Save model, Adam state, and Stage 41 progress.
path = manager.save_engine("experiment-001", engine, tag="latest")

# In a fresh process, construct the same model/dataset/config first,
# then restore the complete checkpoint into a new engine.
manager.restore_engine(path, resumed_engine)
resumed_engine.fit()
```

For a best-validation snapshot:

```python
path, best_loss = manager.save_best(
    engine.model,
    validation_loss=current_validation_loss,
    best_validation_loss=previous_best_loss,
    name="best-model",
    trainer_state=engine.checkpoint_state(),
)
```

## Artifact format

Each checkpoint is a JSON object with `format=cogniseek-checkpoint-v1`, `artifact_version=1`, model state, optimizer state, trainer state, metrics, tag, timestamp, and SHA-256 digest. The digest covers the canonical JSON representation of every field except the digest itself.

## Verification

- Stage 42 focused tests: 8 passed.
- Targeted Stages 37–42 regression: 55 passed, 0 failed.
- Python compilation: passed.
- Protected M-RBAM source hash remains identical to the v15.6.0 baseline.

## Boundaries and limitations

- JSON checkpoints are readable and convenient for this small reference model, but are not optimized for large models or high-throughput I/O.
- Checkpoint integrity detects accidental or unauthorized modification only when the expected digest is trusted; it is not a digital signature or a secure supply-chain attestation.
- Checkpoints are local artifacts. Replication, encryption-at-rest, access control, retention policy, and remote object storage are not implemented here.
- Restoring requires constructing a compatible model and dataset pipeline first. Checkpoints do not contain the training corpus or tokenizer source corpus.
- This stage does not turn the CPU scalar-autodiff trainer into a production-scale distributed training system.
