# Stage 31 — COGNISEEK TLM Tokenizer (v14.6.0)

## Purpose
Introduce the first executable language-input encoding component: a deterministic,
trainable byte-level Byte Pair Encoding (BPE) tokenizer.

## Design
- UTF-8 byte alphabet (256 base tokens): every valid Unicode string is representable.
- Stable special-token IDs, including PAD/UNK/BOS/EOS/SEP and trajectory/evidence markers.
- Deterministic BPE training with frequency threshold and lexicographic tie-breaking.
- Encode/decode, optional BOS/EOS, optional special-token skipping.
- JSON model persistence with canonical SHA-256 integrity check.
- Corpus byte limit and explicit validation errors.

## COGNISEEK trajectory semantics
The tokenizer recognizes episode, current-request, fresh-evidence, historical-memory,
review-feedback, response and evidence-boundary markers as tokens. Token recognition
does not authenticate sources, assess claim support, establish source independence,
or grant historical memory evidentiary authority. Fresh evidence and historical memory
remain distinct input segments.

## Scope and limitations
This is a tokenizer, not a trained language model. It does not implement embeddings,
neural layers, optimizer, training loop, checkpoints, weights, inference, retrieval,
or deployment. Stage 30 remains an architecture specification. Training this tokenizer
only learns byte-pair merge rules from the supplied corpus; it does not train TLM weights.
The tokenizer is a simple reference implementation; its whole-string byte BPE training
is not a production-grade linguistic pre-tokenizer and should be benchmarked on a
representative multilingual corpus before production use.

## API
`ByteBPETokenizer.train(corpus, vocab_size=..., min_pair_frequency=...)`
`encode(text, add_bos=False, add_eos=False)` / `decode(ids, skip_special_tokens=False)`
`save(path)` / `load(path)`

## Preserved invariants
No M-RBAM equations, thresholds, F1–F4 definitions, appraisal logic or longitudinal
calculations are modified. The protected M-RBAM source file must remain byte-identical.
