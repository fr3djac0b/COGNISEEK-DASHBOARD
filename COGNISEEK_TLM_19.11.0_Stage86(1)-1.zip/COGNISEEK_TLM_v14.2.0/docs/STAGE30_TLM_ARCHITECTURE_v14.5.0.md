# Stage 30 — TLM Neural Architecture Specification (v14.5.0)

## Purpose
Establish an explicit, executable architecture specification for the COGNISEEK Trajectory Language Model before implementing a tokenizer, neural layers or training pipeline.

## Proposed architecture
A decoder-only autoregressive Transformer with learned token embeddings, rotary positional embeddings, causal grouped-query self-attention, pre-normalized RMSNorm residual blocks, SwiGLU feed-forward networks and a vocabulary projection. Word embeddings may be tied to the output projection.

## Trajectory-aware input design
The shape planner recognizes system instructions, the current request, fresh evidence, historical memory, review feedback and generated response segments. Historical memory is explicitly labelled contextual input rather than current proof. Fresh evidence and feedback are unverified inputs until separately assessed.

## Implemented in Stage 30
- `app/tlm_architecture.py`
- Validated model configuration.
- Dense parameter-count estimate, including grouped-query attention and tied/untied embeddings.
- Causal attention visibility plan.
- Episode-aware trajectory segment and context-window planner.
- Deterministic architecture manifest and internal consistency validator.

## Not implemented
No tokenizer, tensor operations, neural layers, optimizer, training loop, trained weights, checkpoint manager or independent inference engine. No external framework dependency is introduced. The parameter estimate excludes biases, optimizer state and runtime caches.

## Training objective proposals
Next-token autoregressive cross-entropy is the primary proposed objective. Evidence-conditioned response training, citation-span supervision, abstention/uncertainty supervision and trajectory-consistency objectives are future proposals only.

## Design constraints
The current request is a new episode. Historical memory can provide context but is not automatically trusted as current evidence. The evidence governance pipeline remains separate from neural model parameters. M-RBAM mathematics and protected source are unchanged.
