# Stage 44 — RAG and External Knowledge (v15.9.0)

## Additive boundary
This release adds `app/rag_external_knowledge.py` as a standalone local retrieval component. No existing source files, VERSION file, training modules, model architecture, or protected M-RBAM files are modified. It does not make network calls or invoke a language model.

## Workflow
1. Ingest documents with document ID, source, source type, observation time, license status, and reliability.
2. Validate provenance and authorization metadata.
3. Split text into overlapping chunks and hash each chunk.
4. Retrieve anew for each query using local BM25-style lexical scoring.
5. Return ranked evidence with source metadata and matched terms.
6. Group evidence by declared topic and flag differing declared claims; preserve every item rather than selecting a winner.

## Retrieval score
The implementation uses a BM25-style term score with a transparent reliability multiplier: `score = BM25(query, chunk) * (0.75 + 0.25 * reliability)`. Reliability affects ranking only; it does not establish truth.

## Boundaries and limitations
- Local lexical retrieval only; semantic embeddings, vector databases, live web connectors, reranking, and LLM answer synthesis are not implemented in this stage.
- Contradiction flags depend on supplied `metadata.topic` and `metadata.claim`; this is structured discordance preservation, not natural-language fact verification.
- No network fetch or external corpus is bundled.
- The module is standalone and is not wired into existing inference paths, preserving the v15.8.0 behavior.
