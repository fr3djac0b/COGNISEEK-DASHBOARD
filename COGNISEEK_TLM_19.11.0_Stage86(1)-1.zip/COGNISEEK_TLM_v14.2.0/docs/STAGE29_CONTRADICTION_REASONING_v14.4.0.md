# Stage 29 — Contradiction-Aware Evidence Reasoning (v14.4.0)

## Purpose
Compare Stage 28 reviewer-coded semantic assessments across passages while preserving opposing evidence and distinguishing apparent disagreements caused by explicit context differences.

## Implementation
- `app/stage29_contradiction_reasoning.py`
- Compares assessments for one exact project and claim.
- Detects opposing SUPPORTS and CONTRADICTS directions across distinct passages.
- Separately detects reviewer disagreement about the same passage.
- Flags explicit differences in population, geography, setting, time period, outcome, intervention, comparator, method and scope.
- Accepts explicit dependency declarations such as DERIVED_FROM, DUPLICATES, CITES, SHARES_DATASET and SAME_ORIGIN.
- Produces a review report with an input hash and optional append-only persistence.
- Provides project/claim-scoped history.

## Interpretation
- `UNRESOLVED_DIRECT_CONTRADICTION`: opposing directions with no explicit context mismatch supplied.
- `APPARENT_CONTRADICTION_CONTEXT_MISMATCH`: opposing directions and one or more explicit context differences.
- `REVIEWER_DISAGREEMENT_ON_SAME_PASSAGE`: reviewers assign opposing directions to the same evidence passage.
- Missing context is unknown, not equivalent context.
- Declared dependencies are review signals, not proof of shared origin.
- No detected dependency is not proof of source independence.

## Boundaries
No automated semantic inference, winner selection, truth certification, source-independence certification, public route, or model-weight update is introduced. NEUTRAL and INDETERMINATE remain distinct. M-RBAM source and mathematics remain unchanged.
