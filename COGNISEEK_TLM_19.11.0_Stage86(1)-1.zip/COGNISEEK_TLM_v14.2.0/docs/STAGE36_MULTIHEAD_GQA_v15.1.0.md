# Stage 36 — Multi-Head Attention and Grouped-Query Attention (v15.1.0)

## Implemented
- Differentiable grouped-query causal attention with independent query heads and
  shared key/value heads.
- Query-head to KV-head grouping, with query_heads divisible by kv_heads.
- Rotary position embedding applied to projected query and key vectors.
- A trainable `GroupedQueryTLM` decoder prototype.
- Independent Q, K and V projection dimensions; KV projection width is
  `kv_heads * head_dim`, reducing KV parameter and activation footprint.
- Parameter registration, Adam training, next-token loss, greedy generation
  and architecture-aware state-dictionary round-trip.

## Architecture
For hidden width d, query-head count Hq and KV-head count Hkv:
- head dimension: dh = d / Hq
- each query head uses KV head floor(h / (Hq/Hkv))
- Q projection width = d
- K and V projection width = Hkv * dh
- concatenated attention output width = d

The implementation requires d divisible by Hq, Hq divisible by Hkv, and an even
head dimension for RoPE.

## Limits
This remains a small scalar-autodiff Python reference implementation with one
decoder block. It is not a vectorized/GPU implementation, does not provide
multi-layer scaling, cache-based inference, distributed training or production
throughput. GQA reduces K/V projection width relative to full multi-head KV, but
performance benefits require optimized tensor kernels and realistic workloads.

The Stage 35 single-head TinyTLM remains available unchanged as a baseline.
No M-RBAM mathematical definitions or protected source files are changed.
