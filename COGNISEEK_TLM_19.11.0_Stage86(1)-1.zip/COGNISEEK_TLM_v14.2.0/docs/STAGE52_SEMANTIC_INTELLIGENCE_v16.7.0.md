# Stage 52 — Semantic Intelligence (v16.7.0)

## Purpose
Add a persistent semantic retrieval layer alongside the existing lexical/document and experience-memory systems. Retrieval proposes relevant context; it does not establish truth, validate a source, or replace current evidence.

## Components
- `SemanticIndex`: SQLite-backed chunk/vector index, partitioned by `project`.
- Embedding provider: injected callable for tests/custom providers, or the existing `app.embeddings.embed_texts` adapter. The default provider requires configured `EMBEDDING_API_KEY` (or `OPENAI_API_KEY`) and `EMBEDDING_MODEL`.
- `semantic_search`: cosine-ranked vector retrieval.
- `lexical_search`: BM25-style lexical retrieval over title + chunk text.
- `hybrid_search`: reciprocal-rank fusion (RRF), avoiding invalid direct addition of unlike raw score scales.
- `evaluate_retrieval`: Precision@K, Recall@K, MRR@K, and NDCG@K against caller-supplied relevance labels.

## Data flow
1. Caller supplies project, document ID, title, text, source name, and optional metadata.
2. Text is chunked (up to 1,200 characters per chunk).
3. The configured embedding provider generates one vector per chunk; dimensions and finite numeric values are validated.
4. Chunk text, provenance fields, and vectors are persisted in SQLite.
5. At query time, the same provider embeds the query; semantic and BM25 rankings are computed independently.
6. Hybrid retrieval merges ranked lists with RRF and returns channel provenance.
7. Offline evaluation compares ranked document IDs with a labelled relevant-ID set.

## Mathematical definitions
Cosine similarity:

`sim(q,d) = (q · d) / (||q|| ||d||)`

BM25-style term contribution (parameters k1=1.2, b=0.75):

`IDF(t) = ln(1 + (N - df(t) + 0.5)/(df(t) + 0.5))`

`BM25(t,d) = IDF(t) * tf(t,d)(k1+1) / (tf(t,d) + k1(1-b+b*|d|/avgdl))`

Reciprocal-rank fusion:

`RRF(d) = Σ_c 1/(k + rank_c(d))`, with default `k=60`.

Evaluation:
- `Precision@K = relevant retrieved / retrieved`
- `Recall@K = relevant retrieved / all labelled relevant`
- `MRR@K = reciprocal rank of first relevant result`
- `NDCG@K = DCG@K / ideal DCG@K`

## Important boundaries
- Embeddings are **not trained by this stage**. Semantic quality depends on the configured embedding model/provider. No offline learned embedding model is introduced.
- No deterministic hash-vector fallback is used: if the provider is unavailable, semantic indexing/search fails explicitly rather than disguising lexical features as semantics.
- SQLite persistence is local to the path supplied by the caller. This is not distributed vector infrastructure, a hosted service, or automatic integration into every answer-generation route.
- BM25 and semantic scores are not calibrated probabilities. RRF combines ranks, not truth values.
- Retrieval evaluation is only as valid as its human/curated relevance labels; it does not measure factuality, source credibility, or answer correctness.
- Existing TLM weights and inference path are not modified. This stage does not fine-tune the language model or automatically feed retrieved text into generation.

## Minimal use

```python
from app.stage52_semantic_intelligence import SemanticIndex

index = SemanticIndex("data/cogniseek_semantic.sqlite3")
index.add_document(
    project="research", document_id="doc-001", title="Example",
    text="Document text to index.", source_name="Example source"
)
results = index.hybrid_search("a question about the document", project="research")
```

Configure `EMBEDDING_API_KEY` and `EMBEDDING_MODEL` before using the default provider, or inject a callable embedding provider that accepts a list of strings and returns a same-length list of numeric vectors.
