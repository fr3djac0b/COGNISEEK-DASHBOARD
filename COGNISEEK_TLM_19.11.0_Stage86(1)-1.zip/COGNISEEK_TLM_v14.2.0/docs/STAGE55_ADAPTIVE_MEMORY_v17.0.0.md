# Stage 55 — Adaptive Memory Retrieval and Relevance Intelligence (v17.0.0)

## Objective
Upgrade Stage 54 episodic-memory lookup with optional semantic embeddings, lexical
fallback, temporal decay, explicit feedback, duplicate candidates and contradiction
relationships. Stage 54 is consumed through its existing SQLite schema and is not
modified by this release.

## Retrieval model
For each candidate, Stage 55 computes lexical relevance, optional embedding cosine
similarity, recency decay and a feedback signal. The weighted components are normalized
by their active weight total to produce `adaptive_score` in [0,1]. The default semantic
candidate floor is cosine similarity 0.20; zero cosine similarity is treated as zero
semantic relevance, not 0.5. Lexical candidates can still be returned with low semantic
similarity because they have direct term overlap.

Recency is exponential half-life decay:
`recency_factor = exp(-ln(2) * age_days / recency_half_life_days)`.

Feedback is a bounded net ratio:
`feedback_score = (useful - irrelevant - outdated - corrected) / max(1, total_feedback)`.

The resulting score is a retrieval-ranking heuristic, not a calibrated probability,
truth score, confidence estimate or evidence sufficiency decision.

## Features
- `index_event()` and `index_project()` persist optional vectors for Stage 54 events.
- `search()` merges lexical candidates with semantically similar indexed candidates.
- `record_feedback()` stores useful, irrelevant, outdated or corrected feedback.
- `detect_duplicates()` compares vectors and returns possible duplicate pairs only.
- `record_relation()` stores explicit `contradicts`, `duplicate_of` and `supersedes` links.
- Contradiction cautions are visible from either endpoint of a relation.
- Project-scoped retrieval, feedback and relations; bounded inputs and score explanations.
- Stage 55 closes its own SQLite connections and reads Stage 54 storage without changing
  Stage 54 source files or its database schema.

## Important limitations
- Embeddings require an injected provider. No embedding model is trained here.
- Without an embedder, retrieval falls back to lexical relevance plus recency and feedback.
- Contradiction detection is explicit-link based; the system does not prove logical
  contradiction autonomously.
- Duplicate detection returns candidates and never merges or deletes memories.
- Feedback influences ranking but does not rewrite memory content, verify claims or
  certify truth.
- No automatic fine-tuning or model-weight updates occur.
- SQLite project scoping is not production multi-tenant authorization.
- Full historical regression, external embedding-provider integration, live answer
  quality, production security, concurrency and load tests remain outstanding.
