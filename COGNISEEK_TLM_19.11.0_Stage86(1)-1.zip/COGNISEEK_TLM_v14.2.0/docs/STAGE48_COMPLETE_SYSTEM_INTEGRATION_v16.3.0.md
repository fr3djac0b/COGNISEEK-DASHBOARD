# Stage 48 — Complete System Integration (v16.3.0)

## Purpose
Add a composition layer across existing Stage 44–47 modules without changing any of their source files.

## Integrated path
1. `KnowledgeBase.retrieve` performs a fresh RAG retrieval for each question.
2. `PersistentExperienceMemory.retrieve` separately retrieves prior episodes.
3. `ReasoningToolOrchestrator` packages external evidence, remembered experience, discordance flags, and allowlisted tool outcomes.
4. The caller reviews the package and supplies the answer; Stage 48 does not generate an LLM response.
5. `complete_episode` appends the reviewed answer and evidence references to persistent memory.
6. Stage 47 metrics can be invoked over caller-provided labelled datasets.

## New API
- `CogniseekSystem(knowledge_base, memory, tool_registry=None, evaluator=None, top_k=5)`
- `begin_episode(question, tool_calls=(), request_id=None) -> EvidencePackage`
- `complete_episode(request_id, answer, outcome='unknown', source_ref='user_or_application') -> sha256`
- `evaluate(...) -> hash-protected evaluation summary`
- `audit_record(package) -> dict`

## Safety boundaries
- Evidence and memories remain separate. Memories are not automatically verified.
- Contradictions are retained and flagged for review; no automatic resolution.
- Tools remain subject to Stage 46 allowlisting and approval requirements.
- The integration layer does not browse, execute arbitrary code, or generate model answers.
- Existing inference, training, tokenizer, transformer, RBAM, and M-RBAM files are not modified.

## Scope limits
This is a functional orchestration layer over injected/local Stage 44–47 components, not a complete deployed application. It does not connect external live web services, provide a user interface, or perform automatic answer synthesis.
