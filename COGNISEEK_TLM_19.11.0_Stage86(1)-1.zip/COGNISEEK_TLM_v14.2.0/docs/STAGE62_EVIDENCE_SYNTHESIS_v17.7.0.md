# Stage 62 — Evidence Synthesis and Contradiction Resolution (v17.7.0)

## Purpose
Stage 62 consumes Stage 61 claim-level evidence links and produces an auditable
synthesis record. It preserves supporting, contradicting and neutral evidence
as separate groups, identifies support-versus-contradiction pairs, and records
human decisions about why evidence may disagree.

## Conflict dimensions
A reviewer may classify a disagreement as population, timeframe, measurement,
methodology, scope, provenance, or unexplained. A reviewer may record that it is
explained by context, remains a conflict, requires more evidence, or is not a
true conflict. Each decision requires an explanation and reviewer label.

## Synthesis states
- `indeterminate`: no linked evidence.
- `contested_unresolved`: at least one conflict pair is unreviewed, remains a
  conflict, or needs more evidence.
- `contextualized_for_human_review`: every identified support/contradiction pair
  has a recorded contextual explanation or is marked not a true conflict.
- `evidence_ready_for_human_review`: no conflict pairs and Stage 61 says
  sufficient for review.
- `insufficient_evidence`: remaining cases that do not pass Stage 61 sufficiency.

## Audit
Synthesis output is saved as a timestamped JSON snapshot with a SHA-256 content
hash. The snapshot records the original evidence directions and review outcomes.

## Limitations
- The engine does not read or semantically interpret source documents. Claim
  direction and source review data are inherited from caller-supplied Stage 61
  records; conflict classification and resolution are human supplied.
- A contextual explanation does not prove the studies are compatible or that
  either conclusion is correct.
- The system does not choose a winning side, erase evidence, or issue truth labels.
- No automatic evidence acquisition, model-weight update, or live reasoning
  activation occurs.
