# Stage 85 — Core Integration and Production Readiness

## Purpose
Integrate the Stage 81–84 capabilities into the FastAPI application and correct their identified fail-open or ambiguous behaviours. This stage does not claim production certification or actual deployment.

## Implemented
- `CoreIntegration` composes the Stage 81 evaluator, Stage 82 runtime security, Stage 83 bounded admission pool and Stage 84 deployment preflight.
- Application startup validates runtime security configuration; invalid production configuration prevents startup.
- HTTP requests pass through bounded non-blocking admission control; excess requests receive HTTP 503 and `Retry-After: 1`.
- `/api/operations/stage85` reports integration status without secrets.
- `/api/operations/deployment-preflight` exposes read-only deployment checks.
- `/api/evaluation/reasoning` runs the supplied-case rubric evaluator against caller-provided outputs. It does not invoke or independently verify the language model.
- Production database paths must be nonempty, absolute, and outside temporary path components.
- Work-pool timeout errors explicitly state that a running task may continue; Python threads cannot be forcibly cancelled safely.

## API examples
`GET /api/operations/stage85` — integration status.
`GET /api/operations/deployment-preflight` — local deployment readiness checks.
`POST /api/evaluation/reasoning` accepts `cases` and `outputs`, where each output entry contains `question` and `output` (`claims`, `evidence_ids`, `unsupported_claims`).

## Important limitations
- The evaluator remains a supplied-rubric evaluator, not proof of general reasoning or truth.
- The admission limit is process-local; multi-process or multi-host deployments need shared admission/rate control.
- Startup checks configuration but do not provision storage or create a verified backup.
- A valid absolute database path does not prove the underlying volume is durable; operators must mount and test persistent storage.
- Docker build, live HTTP smoke tests, TLS, migrations, backup/restore and load testing remain external release-gate tasks.
- Stage 83 uses threads; hard cancellation requires cooperative cancellation tokens or process isolation.

## Acceptance criteria
All Stage 85 unit tests pass; prior repository tests remain green; application compiles. Production startup must reject invalid auth, CORS, debug and database path settings.
