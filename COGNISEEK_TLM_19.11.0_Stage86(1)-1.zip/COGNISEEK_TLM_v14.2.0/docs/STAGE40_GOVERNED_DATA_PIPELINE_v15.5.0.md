# Stage 40 — Governed Training Data Pipeline (v15.5.0)

## Implemented
- In-memory ingestion of provenance-bearing text records.
- Required record ID, non-empty text, source provenance and explicit approved
  license/authorization status.
- Rejection report with stable reason codes; no silent acceptance of unknown
  licensing status.
- Duplicate record-ID detection and normalized-content deduplication.
- Deterministic, seed-controlled, record-level train/validation/test splitting.
- Tokenizer training on the training split only to avoid validation/test leakage.
- Encoding with BOS/EOS boundaries.
- Bounded next-token context/target example batching.
- Deterministic epoch-specific shuffle.
- Dataset manifest with split membership, text hashes, counts, rejections,
  tokenizer vocabulary size and manifest SHA-256.
- JSONL split export and JSONL ingestion.

## Governance contract
Accepted license statuses: public_domain, cc0, cc_by, licensed, user_provided,
internal_authorized. This is an allowlist gate, not a legal determination. The
operator remains responsible for verifying actual rights, consent, privacy,
retention and permitted use. No web scraping or external dataset is performed.

## Leakage controls
Splitting is performed at the record level before tokenizer fitting and before
next-token examples are generated. Tokenizer merges are learned exclusively from
the training records. Validation and test documents are not used to fit merges.

## Limitations
This is a deterministic local reference pipeline. It does not yet provide
streaming ingestion, distributed sharding, PII detection, semantic deduplication,
dataset licensing verification, quality classifiers, large-scale storage or
training orchestration. JSONL exports contain source text and should be stored
with appropriate access controls.
