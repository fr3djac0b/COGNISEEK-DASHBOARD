# Stage 38 — Incremental KV Cache (v15.3.0)

## Implemented
- Per-layer key and value caches for stacked GQA inference.
- One-token incremental forward pass; cached prior K/V are reused.
- Prefill path that builds cache from a prompt.
- Cache reset and per-layer cache state.
- Context overflow policy: rebuild the retained window so RoPE positions
  and output match the model's bounded full-context forward path.
- Greedy cached generation.
- Cached-versus-full logits equivalence tests across ordinary and overflow cases.

## Important details
The cache stores projected, rotary-position-encoded keys and projected values.
For each new token, the model computes only the new token's projections at each
layer and attends over the retained KV history. The implementation is inference
only; training continues to use the normal differentiable full-sequence path.

## Limitations
- Scalar-autodiff/Python reference implementation, not optimized GPU kernels.
- Context overflow rebuilds the retained cache instead of using a ring buffer;
  this preserves exact bounded-window/RoPE semantics but costs a recomputation
  at overflow boundaries.
- No cache quantization, paging, batching across requests or speculative decoding.
- No production throughput claims.
