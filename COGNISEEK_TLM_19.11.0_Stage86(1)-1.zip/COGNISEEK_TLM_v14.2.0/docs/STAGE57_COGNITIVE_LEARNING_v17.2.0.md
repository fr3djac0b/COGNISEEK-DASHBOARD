# Stage 57 — Controlled Cognitive Learning Bridge (v17.2.0)

## Purpose
Connect Stage 56's evaluated experience records to a controlled learning-candidate
workflow. This is a governance bridge, not online learning or foundation-model training.

## Pipeline
Stage 54 experience -> Stage 56 evaluation -> Stage 57 candidate -> human review ->
controlled trial -> trial evidence record -> separate future release decision.

## Eligibility gates
- Source must be a Stage 54 `experience` event in the requested project.
- Stage 56 lifecycle must be `active`.
- A matching Stage 56 evaluation must exist for the same event and project.
- Evaluation outcome must be `useful` or `partially_useful`.
- Candidate evidence references must be a subset of those recorded in the evaluation.
- Each evaluation may create at most one candidate.

## Review and trial
Candidates begin `pending_review`. Explicit review can reject, request evidence, or
approve a controlled trial. Approval does not inject the lesson into live reasoning.
Trials require context, evaluator and evidence references. Outcomes are append-only
records and do not automatically adopt or discard a candidate.

## Safety boundaries
- No Stage 54/55/56 source files are modified.
- No memory is deleted or rewritten.
- No unverified experience is promoted to verified fact.
- No prompt injection, live reasoning integration, or model-weight update occurs.
- Reviewer identity is recorded as supplied text, not authenticated.
- Evidence references are provenance pointers, not independently validated evidence.

## Main API
`CognitiveLearningBridge(memory, adaptive_retriever, evaluation_engine, database)`
- `propose(...)`
- `review(...)`
- `record_trial(...)`
- `get_candidate(...)`
- `list_candidates(...)`

## Limitations
This stage creates a reviewable candidate-learning ledger only. Production integration,
authenticated reviewer identity, independent evidence validation, held-out evaluation,
and any model training remain future work.
