# M-RBAM implementation contract (v0.6.0)

## Scope
This is a software reference implementation for a proposed research framework. It is not a diagnostic instrument, treatment rule, or clinical decision support system.

## Measurement layer
- `delta_a = a_post - a_pre` only if both scores are present and within 0–10.
- `u = evidence_direction * delta_a` only if `delta_a` exists and direction is exactly -1 or +1.
- Missing values stay null. They are never coerced to zero.
- Actual evidence is referenced by `evidence_record_id`; research interpretation is recorded separately in `evidence_direction` and `evidence_coding_reason`.

## Versioned classification profiles

### `strict_alignment_v0.2` (default)
Provisional alignment boundaries: score 0–3 aligned when D=-1 and discordant when D=+1; score 7–10 aligned when D=+1 and discordant when D=-1; scores 4–6 are borderline. These are illustrative research boundaries only.

- F1: aligned before and after.
- F2: discordant before, aligned after, and `meaningful_realignment=true`.
- F3: discordant before and after, with `material_discordance=true`, adequate communication, and comprehension.
- UC: interpretable pattern not covered by complete F1–F3 rules, including borderline cases.
- NA: invalid/missing appraisal measurements or failed evidence/interpretability/comprehension gate.

### `directional_v0.1` (experimental; not interchangeable)
- F1 when valid U > 0: concordant directional update.
- F2 when valid U = 0: no measured directional appraisal update; this does not prove no psychological updating occurred.
- F3 when valid U < 0: discordant directional update.
- F4 when appraisal measurements are valid but evidence direction is indeterminate.
- NA when a required appraisal measurement is missing or invalid.

## Longitudinal records
QAAT stores Delta_A; UAT stores U; CAR stores the categorical form. They remain separate, ordered by episode timestamps where supplied, and do not imply causality. `prior_episode_count` records available history at the time of the episode.

## Required pre-study work
A research team must prespecify the exact appraisal question and scale anchors, translation/comprehension procedure, evidence coding rules, duplicate/conflict handling, threshold justification, meaningful realignment and material discordance criteria, missing-data plan, SAP, sample-size rationale, validation strategy and governance. Obtain required institutional approvals before recruitment.
