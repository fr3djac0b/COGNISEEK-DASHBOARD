# Stage 39 — KV Cache Reliability, Isolation and Observability (v15.4.0)

## Implemented
- Cache state export/import with model-weight fingerprint validation.
- Strict validation of cache format, context size, KV width, token IDs,
  layer counts, sequence lengths, row widths and finite numeric values.
- Cache session isolation: every session owns independent token/KV arrays.
- Cache invalidation when model weights change.
- Metrics: tokens processed, cached reads, KV writes, rebuild count and
  overflow rebuild count.
- Approximate KV payload memory accounting (float64 payload only; excludes
  Python container/object overhead).
- Restore continuity test: next-token logits after cache restoration match
  uninterrupted session inference.

## Scope and limitations
Cache state is a Python data structure intended for trusted local checkpointing;
it is not an authenticated or encrypted interchange format. Model fingerprint
is a consistency check, not a security signature. Session isolation is process
memory isolation, not a multi-tenant authorization layer. Metrics count logical
KV row reads/writes and estimate numeric payload bytes, not wall-clock speed.
