# Stage 47 — Evaluation and Safety (v16.2.0)

## Scope
Standalone, additive evaluation utilities. Existing inference, training, RAG, memory, reasoning, tool, and M-RBAM modules are not modified or wired into this stage.

## Components
- `EvaluationSafetySuite.grounding`: dataset-relative supported-claim rate and evidence recall. Support labels must be supplied by evaluators.
- `retrieval_precision_recall`: precision and recall against labelled relevant IDs.
- `calibration`: Brier score and expected calibration error (ECE) from confidence/correctness observations.
- `memory_reliability`: provenance completeness, unverified count, and corrected-record count. Metadata is not proof of truth.
- `safety_coverage`: measures execution coverage of a supplied safety-case catalog.
- `default_adversarial_catalog`: seed scenarios for prompt injection, tool escalation, memory poisoning, discordance suppression, privacy, and confidence inflation. These cases are not executed model outcomes.
- `report`: emits a hash-protected evaluation summary and limitations.

## Metrics
Grounded claim rate = supported answer claims / answer claims. Evidence recall = retrieved/cited expected evidence IDs / expected evidence IDs. Retrieval precision = relevant retrieved IDs / retrieved IDs. Retrieval recall = relevant retrieved IDs / relevant IDs. Brier score = mean((confidence - outcome)^2). ECE = sum over bins of bin population fraction × absolute(accuracy - mean confidence).

## Boundaries
No automated semantic fact-checking, live model evaluation, automatic red-teaming, or model-weight changes are performed. Metrics depend on independently labelled evaluation data. Human review remains required for high-impact outputs.
