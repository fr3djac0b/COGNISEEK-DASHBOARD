# Stage 61 — Evidence Verification and Source Intelligence (v17.6.0)

## Purpose
Adds claim-level evidence mapping, explicit source-profile reviews, contradiction
preservation, declared-lineage counting, and evidence-sufficiency screening.

## Workflow
1. Register a normalized claim.
2. Attach acquired evidence with a direction: supports, contradicts, or neutral.
3. Record a source profile: primary/secondary/tertiary/unknown, identity status,
   author visibility, methodology visibility and conflict disclosure.
4. Assess claim-level support, contradiction, lineage diversity and unreviewed
   sources.
5. Return a decision: sufficient for human review, insufficient, contested, or
   indeterminate.

## Source profile score
A transparent heuristic score is computed from caller-supplied review fields:
verified identity (0.40), partially verified identity (0.20), known author
(0.20), methodology present (0.25), and conflicts disclosed (0.15). The score
is not a probability, truth score, or independently verified source rating.

## Sufficiency gate
A claim is marked `sufficient_for_review` only when it has at least the configured
number of declared source groups and supporting groups, every linked source has
a recorded profile review, and no linked evidence is marked as contradicting.
Any contradiction yields `contested`. No evidence yields `indeterminate`.

## Limitations
- Claim extraction, direction assignment and source review are caller-supplied.
- Source identity and declared lineage are not authenticated.
- A primary/secondary/tertiary label is a classification input, not a certification.
- Source-profile weights are heuristic and require empirical calibration.
- Sufficiency permits human review only; it is not an automated truth verdict.
- No external web retrieval, legal/medical decision, live reasoning activation,
  or model-weight update is performed.
