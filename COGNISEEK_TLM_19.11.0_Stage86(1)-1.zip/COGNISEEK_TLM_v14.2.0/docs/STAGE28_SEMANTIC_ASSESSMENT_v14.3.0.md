# Stage 28 — Structured Semantic Claim-Support Assessment (v14.3.0)

## Purpose
Stage 27 verified citation identity, project membership and reviewer-coded direction. Stage 28 adds a structured semantic-review workflow so a reviewer can assess whether each exact passage supports, contradicts, is neutral to, or is indeterminate for a target claim.

## Implementation
- `app/stage28_semantic_assessment.py`
- `build_review_packet(...)` creates a passage-specific review packet without inferring direction.
- `record_assessment(...)` records a reviewer decision and requires a complete rubric:
  directness, scope, polarity, temporality, modality, population, causality and completeness.
- Optional quoted spans must be exact substrings of the supplied passage.
- `summarize_assessments(...)` preserves mixed evidence and keeps INDETERMINATE distinct from NEUTRAL.
- `history(...)` returns append-only assessment records.
- No public route, external model/API call, or model-weight update is added.

## Interpretation
Directions are human reviewer assessments, not automated semantic conclusions. A recorded SUPPORTS label is an auditable review decision, not proof of entailment or truth. Source authenticity, source independence, methodological quality and factual accuracy remain separate verification tasks.

## Safety and boundaries
- The module does not infer direction from lexical overlap or similarity.
- INDETERMINATE requires at least one rubric dimension to be explicitly UNCLEAR.
- Mixed supporting and contradicting assessments remain MIXED_EVIDENCE.
- NEUTRAL and INDETERMINATE are never merged.
- This stage does not alter M-RBAM source code or its mathematical definitions.
