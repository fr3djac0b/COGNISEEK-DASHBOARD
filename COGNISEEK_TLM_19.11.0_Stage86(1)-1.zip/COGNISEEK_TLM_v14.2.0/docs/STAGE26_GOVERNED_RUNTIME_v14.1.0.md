# Stage 26 — Governed Runtime Integration and Review Provenance (v14.1.0)

## Objective
Connect the existing Stage 18 evidence-learning lifecycle to the established response-policy, answer-control and release-assessment services without creating an alternate public API or weakening route authorization.

## Implemented
- `app/stage26_governed_runtime.py` composes Stage 18 current-episode acquisition and evidence intelligence, response-policy preparation and append-only recording, answer-control assessment and recording, and the existing read-only release assessment.
- Integration runs are stored append-only and can be retrieved through project-scoped history.
- Optional review provenance records bind reviewer subject/role, draft SHA-256 and evidence-snapshot SHA-256 to a review decision and timestamp.
- Review provenance requires a trusted principal object that must be injected by upstream authentication middleware. It must never be accepted from an untrusted request body.
- Release remains closed. Answer-control decisions are explicitly advisory and do not technically block publication.

## Review provenance constraints
The `authenticated_by_middleware` marker is a trust-boundary assertion supplied by the trusted caller. This module cannot authenticate identities by itself. Production integration must pass a principal created by verified middleware and enforce reviewer roles server-side. A user-supplied JSON field is not proof of identity.

## Preserved boundaries
- No public HTTP route added.
- No neural weights updated.
- No answer release authorized.
- No M-RBAM source or equations modified.
- Existing Stage 18 and response-policy services remain responsible for acquisition and retrieval semantics.

## Limitations
- The existing answer-control service remains advisory, and grounding depends on reviewer-coded claim-to-passage links.
- Response-policy preparation can be unavailable if its existing retrieval store/dependencies are unavailable; this is recorded as a policy-unavailable state.
- Release assessment is read-only and does not run a full request-to-answer or deployment test.
- This stage does not provide authentication middleware, publisher authentication, semantic entailment proof, penetration testing or production deployment.
