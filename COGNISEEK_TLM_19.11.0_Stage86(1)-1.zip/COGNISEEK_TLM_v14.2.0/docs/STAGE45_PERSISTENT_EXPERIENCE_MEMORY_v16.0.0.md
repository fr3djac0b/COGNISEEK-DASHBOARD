# Stage 45 — Persistent Experience and Memory (v16.0.0)

## Additive-only boundary

This release adds a standalone SQLite-backed experience-memory component. It does not modify, replace, rename, delete, or wire into any pre-existing TLM/RBAM module. Existing inference behavior is unchanged. The memory module is opt-in and must be explicitly instantiated by a future integration stage.

## Capabilities

- Persist interaction episodes with question, answer, timestamp, source type/reference, evidence references, outcome, tags, and metadata.
- Store append-only corrections linked to an original episode; the original episode is not overwritten.
- Persist across process restarts using SQLite.
- Retrieve relevant episodes with fresh query-time lexical scoring.
- Apply configurable temporal decay (default half-life: 180 days) and optional outcome filtering.
- Return corrections alongside their parent episode.
- Export records as JSONL with content hashes for audit/backup.
- Mark every retrieved item `remembered_not_verified`; memory retrieval is not current fact verification.

## Retrieval model

For episode `i`, lexical relevance is BM25-style. The final score is:

`S_i = BM25(q, e_i) × 2^(-age_days_i / half_life_days) × outcome_factor_i`

The temporal multiplier reduces the influence of older memories but does not delete them. Outcome factors are ranking hints only. The labels `helpful`, `verified`, `unknown`, `unhelpful`, and `corrected` do not turn a stored answer into authoritative truth. `verified` is an outcome label supplied by the caller and still returns `remembered_not_verified` so a current request must independently appraise its evidence.

## API

```python
from app.stage45_persistent_experience_memory import (
    ExperienceEpisode, ExperienceCorrection, PersistentExperienceMemory
)

memory = PersistentExperienceMemory("data/cogniseek_experience.sqlite3")
memory.remember(ExperienceEpisode(
    episode_id="episode-001",
    question="What did we learn about sensor calibration?",
    answer="Use a traceable reference and record the result.",
    created_at="2026-10-30T12:00:00+00:00",
    source_type="conversation",
    source_ref="session:001",
    evidence_refs=("evidence:001",),
    outcome="unknown",
    tags=("sensor", "calibration"),
))
results = memory.retrieve("sensor calibration", top_k=5)
```

## Data governance and limitations

- This is local SQLite persistence; no cloud sync, encryption-at-rest, multi-user access control, or retention scheduler is included.
- The caller is responsible for consent, data minimization, access control, and safe database placement.
- Retrieval is lexical, not embedding-based semantic retrieval.
- The component does not call the internet, a language model, or external tools.
- No automatic memory ingestion or answer synthesis is wired into existing execution paths.
- Corrections are append-only, but semantic conflict resolution and automated correction validation are not included.
- Timestamps should be supplied in ISO-8601 form with timezone information for consistent temporal ranking.

## Files added

- `app/stage45_persistent_experience_memory.py`
- `tests/test_v16_0_stage45_persistent_experience_memory.py`
- `docs/STAGE45_PERSISTENT_EXPERIENCE_MEMORY_v16.0.0.md`
- `RELEASE_NOTES_v16.0.0.md`
- `TEST_RESULTS_v16.0.0.txt`
- `RELEASE_MANIFEST_v16.0.0.json`
