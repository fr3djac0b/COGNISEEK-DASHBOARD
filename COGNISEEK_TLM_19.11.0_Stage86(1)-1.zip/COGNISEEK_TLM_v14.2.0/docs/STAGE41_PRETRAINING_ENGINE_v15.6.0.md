# Stage 41 — Pretraining Engine (v15.6.0)

## Purpose

Stage 40 prepares authorized text records, creates deterministic train/validation/test splits, fits the tokenizer on training records only, and produces bounded next-token examples. Stage 41 consumes those encoded splits and runs reproducible training experiments against the existing `MultiLayerGQATLM`.

## Architecture

`DatasetPipeline.batches(train)` → mini-batch gradient accumulation → gradient clipping → Adam parameter update → epoch metrics → validation evaluation → run manifest. The validation and test splits are never passed to the optimizer.

## Training objective

For context tokens `x_1...x_t` and target token `x_(t+1)`, the model produces logits `z`. The next-token cross-entropy is:

`L = -log( exp(z_y) / sum_j exp(z_j) )`

For a mini-batch of `B` examples, gradients are accumulated and averaged:

`g = (1/B) sum_i grad_theta L_i`

Global-norm clipping applies scale `s = min(1, c / (||g||_2 + 1e-12))`, where `c` is `max_grad_norm`. The existing Adam optimizer then updates model parameters.

## Learning-rate schedule

The constant schedule uses `eta_e = eta_0`. The cosine schedule is:

`eta_e = eta_min + 0.5 * (eta_0 - eta_min) * (1 + cos(pi * e / (E - 1)))`

where `e` is the zero-based epoch index and `E` is the configured epoch count. A single-epoch run uses the base learning rate.

## Validation and early stopping

Validation loss is computed without backward passes or optimizer updates. The best validation loss and epoch are recorded. If `early_stopping_patience > 0`, training stops after that many consecutive epochs without an improvement greater than `min_delta`. The test split is available only through the evaluation method; it is not used for model selection.

## Run record

Each run manifest records the configuration, model dimensions, per-epoch train/validation losses, example counts, learning rates, optimizer step count, best validation epoch, early-stopping status, and SHA-256 digest. `save_run()` writes JSON locally.

## Verification

The Stage 41 focused suite covers configuration rejection, training updates, validation non-mutation, test evaluation, learning-rate schedules, early stopping, and manifest persistence. The Stage 37–41 targeted regression set is also run. The full historical suite is very large and did not complete within the available execution window; a legacy API duplicate-detection test also fails on an untouched clean v15.5.0 baseline. Therefore no full-suite green claim is made for this release.

## Boundaries and next work

This CPU reference engine is intentionally small and uses the project’s scalar autodiff implementation. It is not suitable for large corpora or production pretraining throughput. It does not yet persist optimizer moments for exact resume, select and restore best model checkpoints, support mixed precision, distribute work across devices, or provide robust experiment tracking. Those belong in subsequent work.
