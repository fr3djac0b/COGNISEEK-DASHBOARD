# Stage 58 — Learning Validation and Adaptive Reasoning Evaluation (v17.3.0)

## Purpose
Stage 58 evaluates Stage57-approved learning candidates through paired baseline-versus-treatment trials. The candidate lesson is tested in a controlled evaluation context; it is not automatically inserted into live reasoning.

## Comparison
For each scenario i:
- delta_i = treatment_score_i - baseline_score_i
- mean_uplift = sum(delta_i) / n

Scores are bounded from 0 to 1 and compare the same named metric within a scenario. Evidence references must be a subset of the candidate's recorded evidence references.

## Conservative screening
- Fewer than 3 paired scenarios: `insufficient_trials`.
- Any negative paired delta: `do_not_adopt`.
- Mean uplift below the configured threshold (default 0.05): `do_not_adopt`.
- At least 3 pairs, no losses, and mean uplift at/above threshold: `candidate_for_human_review`.

This is an engineering screen, not a statistical significance test or proof of causality.

## Human gate
A candidate can be recorded as approved for next-release review only if it passes screening. This still does not enable live reasoning, update model weights, or automatically adopt the lesson.

## API
`LearningValidationEngine(learning_bridge, database, min_pairs=3, min_uplift=0.05)`
- `record_pair(...)`
- `assess(...)`
- `review_assessment(...)`

## Limitations
No randomization, blinded evaluation, confidence intervals, multiple-comparison correction, or authenticated evaluator identity are implemented. Scores and evidence references are recorded as supplied. Production integration remains future work.
