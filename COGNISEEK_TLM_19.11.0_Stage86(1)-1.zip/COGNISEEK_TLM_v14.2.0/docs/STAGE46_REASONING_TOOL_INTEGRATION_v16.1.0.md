# Stage 46 — Reasoning and Tool Integration (v16.1.0)

## Preservation policy
This release is additive. It adds a standalone orchestration module and does not edit, replace, rename, or delete any v16.0.0 file. Existing inference paths remain unchanged.

## Added capability
- Fresh evidence-provider call for each request.
- Separate memory-provider results, explicitly labelled `remembered_not_verified`.
- Lightweight discordance flagging that preserves opposing evidence IDs and never silently resolves them.
- Explicit allowlist for tools registered by trusted application code.
- Argument allowlists and required-argument checks.
- Approval gate for tools configured to require approval.
- Auditable trace and deterministic SHA-256 digest for the orchestration result.

## Security boundary
No arbitrary code execution, shell execution, automatic network access, or implicit tool discovery is provided. Tool handlers are supplied by the integrating application. A tool requiring approval returns `approval_required` unless the caller explicitly marks the call approved.

## Integration boundary
This is a standalone, opt-in layer. It does not modify existing model inference, Stage 44 RAG, Stage 45 memory, or protected M-RBAM components. Integrators can inject Stage 44 and Stage 45 adapters through the provider callables.

## Limitations
Conflict detection is intentionally heuristic and is not a semantic entailment model. The orchestrator collects evidence and tool outputs; it does not itself generate natural-language answers or guarantee factual correctness. No live web connector is bundled.
