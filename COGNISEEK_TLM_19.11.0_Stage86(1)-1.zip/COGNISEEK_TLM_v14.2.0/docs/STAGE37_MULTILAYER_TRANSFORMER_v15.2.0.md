# Stage 37 — Multi-Layer Transformer Architecture (v15.2.0)

## Implemented
- Configurable stack of decoder blocks, each with independent Q/K/V/O and SwiGLU weights.
- Grouped-query attention retained in every layer.
- Shared token embedding and vocabulary projection across the stack.
- Parameter registration across embeddings, every decoder layer and output projection.
- Reverse-mode gradient flow and Adam training through the entire stack.
- Bounded context window: forward and next-token training contexts are truncated
  to the configured maximum context length.
- Greedy autoregressive generation with context-window enforcement.
- Architecture-aware model state export/import with complete prevalidation.

## Shape definitions
For hidden width d, query heads Hq, KV heads Hkv, head width dh=d/Hq:
- Q and output projection: d × d
- K and V projection: d × (Hkv × dh)
- SwiGLU gate/up: d × intermediate_width
- SwiGLU down: intermediate_width × d
- Decoder depth: configurable `num_layers`

Constraints: d divisible by Hq; Hq divisible by Hkv; dh even for RoPE;
positive vocabulary, intermediate width, layer count and context length.

## Explicit limitations
- This is a small scalar-autodiff CPU reference implementation.
- The context window is enforced by truncating token history; there is no KV cache
  yet. KV caching is reserved for a subsequent inference-optimization stage.
- No vectorized/GPU kernels, distributed training, data-parallelism or large
  corpus evaluation.
- Greedy decoding only; no sampling, beam search or stop-token policy.
- A configurable stack is implemented, but no production-scale language
  capability is claimed.

Stage 35's TinyTLM and Stage 36's GroupedQueryTLM remain available as baselines.
No M-RBAM source or mathematical definitions are changed.
