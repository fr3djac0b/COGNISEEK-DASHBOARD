# Stage 56 — Memory Evaluation, Correction and Consolidation (v17.1.0)

## Objective
Add an auditable evaluation loop around Stage 54 episodic memories and Stage 55 adaptive retrieval. Evaluate whether a memory helped in a particular episode; record correction candidates with explicit provenance; and propose consolidation without silently changing source records.

## Architecture
- `MemoryEvaluationEngine.evaluate()` appends an outcome assessment (`useful`, `partially_useful`, `not_useful`, `incorrect`, `outdated`, `unresolved`) with evaluator, episode, evidence references, notes and timestamp.
- Evaluation outcomes are also translated into Stage 55 feedback labels so future ranking can respond to experience. This is a relevance/usefulness signal, not a truth label.
- Lifecycle state is derived conservatively: `active`, `caution`, `review_required`, or `superseded`. Negative or mixed feedback requests review; it does not erase a memory.
- `submit_correction()` creates a new Stage 54 `correction` event, requires evidence references and reviewer identity, and records a Stage 55 `supersedes` relation. The old event remains intact and marked superseded in the Stage 56 lifecycle ledger.
- `propose_consolidation()` creates a pending proposal for 2–20 source memories. `review_consolidation()` records a human decision. Even approval only authorizes a separate manual operation; this stage does not merge or delete records.

## Data integrity principles
1. Append-only evaluation history.
2. Preserve original memory content and provenance.
3. No automatic promotion to `verified_fact`.
4. No automatic model-weight update or fine-tuning.
5. Project-scoped lookup and lifecycle records.
6. Explicit reviewer identity for corrections and consolidation decisions.
7. Relevance and usefulness are not factual truth.

## Limitations
- Reviewer identity is recorded as a supplied string, not authenticated identity; production authorization remains required.
- Evidence references are recorded but their contents/support are not independently validated by this stage.
- Lifecycle state is a transparent heuristic, not a calibrated confidence estimate.
- Consolidation remains proposal-only; no canonical merge format is implemented.
- SQLite project scoping is not a production multi-tenant security boundary.
- No neural weights are trained or changed.
