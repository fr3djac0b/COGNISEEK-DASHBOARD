# Stage 54 — Episodic Memory and Experience Learning (v16.9.0)

## Objective
Add a persistent, typed episodic memory layer. A conversation episode is distinct from
the events and lessons recorded within it.

## Memory taxonomy
- `observation`: recorded input or observation; not independently verified.
- `inference`: a derived interpretation; not verified by being stored.
- `verified_fact`: accepted only with both a verifier identifier and evidence references.
  The label records an attestation event; it is not a universal guarantee of truth.
- `correction`: a new event linked to the event it supersedes. The old event remains.
- `experience`: an explicitly recorded, reviewed lesson linked to an episode.

## Retrieval
`search()` ranks candidate memories using token overlap (F1-style harmonic mean) with a
small recency tie-breaker. This is lexical retrieval, not a learned semantic embedding.
Results retain type, source, evidence references, timestamps, confidence, and supersession
links. Every result warns that relevance is not proof of factual accuracy.

## Persistence and isolation
SQLite stores episodes and memory events. Project-scoped queries prevent accidental
cross-project retrieval within this API. This is not a substitute for production
multi-tenant authorization or encryption at rest.

## Learning boundary
This stage stores and retrieves structured experiences. It does not fine-tune model weights,
update parameters, autonomously decide that an answer is true, or automatically turn every
response into an experience. A review or explicit recording action is required.

## Stage 53 integration
`ingest_rag_result(result)` imports a Stage 53 RAG response into this memory layer.
It creates a new episode, records the user query as an observation, and records the
generated answer as an inference with retrieved chunk references. It never promotes
the generated answer to `verified_fact` or `experience`. A reviewed lesson must be
added explicitly through `record_experience()`.
