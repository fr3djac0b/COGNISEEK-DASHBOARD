# COGNISEEK TLM v18.0.0 — Stage 65: Semantic Evidence Direction

Baseline: v17.8.0 (immutable).

## Scope

Produces conservative direction proposals and exposes lexical evidence; it does not perform NLI or certify entailment.

## Files
- `app/stage65_semantic_evidence_direction.py`
- `tests/test_v18_0_0_stage65_semantic_evidence_direction.py`

## Validation boundary
This stage is additive. Its focused tests validate the documented deterministic behaviour only; they do not establish production readiness, model quality, factual accuracy or autonomous intelligence.
