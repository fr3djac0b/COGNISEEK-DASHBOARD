# Stage 60 — Evidence Acquisition and E2 Retrieval Adapter (v17.5.0)

## Purpose
Add a provider-neutral evidence intake boundary for E2. The module records source
provenance, content hashes, canonical URLs, declared lineage groups, retrieval
timestamps and acquisition queries. The E2 adapter invokes a caller-supplied
search provider and stores its results in the registry.

## Workflow
1. The application supplies an E1 evidence-ID list.
2. The adapter validates that every E1 ID exists in the selected project.
3. A configured provider is called with the E2 query and requested result limit.
4. Returned records are validated and registered.
5. Exact content duplicates and canonical-URL duplicates are flagged.
6. New records are separated into same-lineage and different-declared-lineage
   candidates relative to E1.
7. Retrieval age can be assessed independently from publication age.

## Record contract
Each provider result is a mapping with `title`, `content`, `source_uri`, and
`publisher`. Optional fields: `source_group`, `published_at`, `retrieved_at`,
`source_type`, and `metadata`. Timestamps are Unix seconds. Source group is
declared by the provider/caller and is not authenticated.

## Important limitations
- This module does not browse the internet by itself. A real retrieval provider
  must be configured by the host application.
- It does not verify source identity, publisher authenticity, factual accuracy,
  publication dates, or source independence.
- A distinct URL or publisher label does not establish independent evidence.
- Exact content and canonical-URL matching are practical duplicate heuristics;
  paraphrases and syndicated copies may evade detection.
- No automatic evidence promotion, model-weight update, or live reasoning
  activation occurs.
- Provider security, network policy, rate limits, retries, concurrency, and
  production load tests remain host-application responsibilities.
