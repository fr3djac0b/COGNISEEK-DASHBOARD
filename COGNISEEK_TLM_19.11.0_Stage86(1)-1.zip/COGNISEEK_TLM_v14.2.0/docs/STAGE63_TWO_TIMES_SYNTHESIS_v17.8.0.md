# Stage 63 — Two-Times Evidence Synthesis Integration (v17.8.0)

## Purpose
Connects the Stage 59 E1/E2 appraisal record to Stage 60 evidence registration,
Stage 61 claim verification and Stage 62 evidence synthesis.

## E1 workflow
- Validate that E1 evidence references exist in the selected project.
- Require those references to be linked to the supplied Stage 61 claims.
- Create the immutable Stage 59 E1 snapshot.
- Save a Stage 62 synthesis snapshot for every episode claim.

## E2 workflow
- Validate E2 evidence references against the same project.
- Require E2 evidence to be mapped to the episode's Stage 61 claims.
- Record E2 through Stage 59 without modifying E1.
- Save updated Stage 62 synthesis snapshots for every claim.

## Comparison gate
- `blocked_unresolved_contradiction`
- `blocked_insufficient_or_indeterminate`
- `human_review_required_contextualized_conflict`
- `blocked_missing_e2_synthesis`
- `eligible_for_human_review`

The gate combines Stage 59's E1/E2 comparison with Stage 62 synthesis statuses.
It is a review-routing control, not a truth or factual correctness score.

## Finalization controls
A `revise_with_e2` decision is blocked when the E2 synthesis gate is unresolved
or insufficient. A `retain_e1` decision is blocked while contradictions remain
unresolved. `withhold` remains available for unresolved cases. Final decisions
remain Stage 59 audit records.

## Limitations
- This is an orchestration layer; it does not generate E1/E2 answers or retrieve
  evidence from the network.
- Evidence IDs must already exist in Stage 60 and be linked to claims in Stage 61.
- Claim direction, source reviews and conflict explanations remain supplied
  inputs; no semantic interpretation of source documents is performed.
- Declared source groups do not prove source independence.
- Human review remains mandatory; no automatic truth verdict or model-weight
  update occurs.
