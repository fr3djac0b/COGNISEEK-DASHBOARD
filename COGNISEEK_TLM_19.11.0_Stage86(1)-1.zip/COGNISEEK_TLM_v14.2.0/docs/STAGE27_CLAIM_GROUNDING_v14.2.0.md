# Stage 27 — Claim-Level Evidence Grounding and Citation Verification (v14.2.0)

## Purpose
Validate that each structured factual claim is linked to reviewer-confirmed evidence for the same exact claim text, that each citation resolves to a passage in the same project, and that draft citation markers match the declared evidence references.

## Implementation
- `app/stage27_claim_grounding.py` adds `verify_claims`, `verify_draft`, `history` and `initialize`.
- Uses the existing append-only reviewer-confirmed links in `app/evidence_linking.py`.
- Resolves cited chunk IDs against the project-scoped `document_chunks` and `documents` records.
- Captures source metadata, reviewer direction, passage hashes, claim/evidence snapshot hashes and draft hashes.
- Distinguishes supporting, contradicting, mixed, neutral/insufficient and indeterminate evidence.
- Detects missing, undeclared, unlinked, cross-project and repeated citation markers.
- Persists append-only verification runs.

## Citation format
Drafts use `[evidence:CHUNK_ID]`, where `CHUNK_ID` must be a reviewer-linked chunk for the exact claim text and same project. Structured claim objects contain `claim_id`, `text` and a list of `citations`.

## Strict limitations
This is deterministic reference/provenance validation, not semantic entailment. A passage marked SUPPORTS by a reviewer may not actually entail the full wording of the claim. The module does not infer claims from prose, authenticate reviewers, establish publisher identity, certify source independence, or prove truth. It does not rewrite a draft, authorize publication, or update model weights.

## Integration
Callable service module; no public route is added. Stage 26 can pass the returned `claim_ledger` into existing `answer_control.assess`. An answer-control decision remains advisory. Production callers must obtain review links and principal identity through trusted existing workflows.
