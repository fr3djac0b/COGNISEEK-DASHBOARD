# COGNISEEK TLM v4.4.0
## Adaptive Evidence Acquisition Decision Planning

### Added
- `app/adaptive_acquisition.py`: deterministic, auditable next-step planner.
- Decision actions:
  - `ACQUIRE_EVIDENCE`
  - `SEEK_CORROBORATION`
  - `RECHECK_SOURCE`
  - `REVIEW_EXISTING_EVIDENCE`
  - `ABSTAIN_PENDING_REVIEW`
- Uses existing acquisition assessment outputs: candidate passage count, prior success/failure
  counts, stale snapshot count, source-host hints and configured exact HTTPS allowlist.
- External acquisition authorization is explicit and disabled by default.
- Append-only decision-plan history, project scoped.
- APIs:
  - `POST /api/acquisition/decision-plan`
  - `GET /api/acquisition/decision-plans`
- Health/version updated to 4.4.0.

### Governance
- Planner does not run external search or fetch.
- Passage count and host diversity are not evidence sufficiency or source independence.
- No evidence direction is inferred.
- No publisher/source authenticity or truth determination.
- Candidate evidence still requires human review.
- Existing URL fetch security controls remain in force.
- No model training, parameter updates or deployment.

### Validation
- Automated tests: 246 passed, 0 failed.
- Python compileall: PASS.
- ZIP integrity: PASS.
- Validation used isolated temporary SQLite database; no production database was used.
