# COGNISEEK TLM v1.4.0 — Adaptive Memory and Temporal Reasoning

## Added
- Optional semantic retrieval of prior episodes using the configured embedding provider.
- Separate SQLite episode-embedding table keyed by project, episode and embedding model.
- Hybrid semantic/lexical retrieval when both signals are available; lexical fallback otherwise.
- Temporal metadata: age in days, recency score, and stale-review warning.
- Memory audit records showing retrieval method, lexical overlap, semantic score, age, outcomes and evidence references.
- Prior outcome notes and corrections are explicitly included in the historical context supplied to the model.
- Structural episode comparison endpoint.
- Explicitly reviewed episodic, semantic and procedural memory item store with provenance.

## Preserved boundaries
- Similarity is not truth, relevance is not evidence direction, and age is not proof of falsity.
- Memory type labels are explicit reviewer classifications, not automatic model conclusions.
- Original episode and appraisal history remain append-only.
- Feedback and outcomes do not update model weights.
- No autonomous training, no authentication/per-user isolation, and no verified source independence.

## Testing
See `TEST_RESULTS_v1.4.0.txt`. Automated tests use local databases and mocked providers; they do not demonstrate live provider availability or deployment.
