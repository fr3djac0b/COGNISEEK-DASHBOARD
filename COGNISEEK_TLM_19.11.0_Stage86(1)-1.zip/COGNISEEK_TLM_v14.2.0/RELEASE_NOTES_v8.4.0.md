# COGNISEEK TLM v8.4.0 — Experience-to-Reasoning Integration

## Purpose
Connect reliability-ranked historical experience to the current episode as provisional expectations, then compare those expectations with caller-supplied current observations.

## What it does
- Converts each selected historical experience summary into a labelled provisional expectation.
- Accepts current observations with explicit reviewer/caller-supplied direction: SUPPORTS, CONTRADICTS, NEUTRAL, INDETERMINATE, or UNAPPRAISED.
- Uses lexical overlap only to find possible comparison pairs.
- A contradiction triggers independent verification.
- Indeterminate or unappraised observations trigger evidence qualification.
- No matched observation means no concordance is inferred.

## API
`POST /api/cognitive-runtime/learning/experience-reasoning`

Example body:
```json
{
  "selected_experiences": [],
  "current_observations": [
    {
      "observation_id": "obs-001",
      "description": "pump pressure is unstable",
      "reviewed_direction": "CONTRADICTS"
    }
  ]
}
```

The episode application endpoint also accepts `current_observations` and returns `experience_reasoning`.

## Safeguards
- Historical experience is not current evidence or a verified prediction.
- Direction is never inferred by this module; caller-supplied appraisals only.
- Lexical overlap is not semantic equivalence.
- Supporting direction does not prove the historical experience.
- Conflicts trigger verification, not automatic preference for memory or current evidence.
- No model-weight updates, automatic truth labels, or external actions.

## Validation
See `TEST_RESULTS_v8.4.0.txt`.
