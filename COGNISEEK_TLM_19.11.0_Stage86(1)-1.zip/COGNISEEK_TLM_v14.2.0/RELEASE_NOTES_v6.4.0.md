# COGNISEEK TLM v6.4.0 — Evidence Conflict and Sufficiency Diagnostics

## Added
- Claim-level diagnostics for reviewed passage appraisals.
- Explicit counts of supporting, contradicting, and F4 appraisals.
- Detection of support/contradiction conflict for the same normalized claim text.
- Coverage gaps for retrieved passages that have no appraisal record.
- Reviewer-direction disagreement is retained and surfaced.
- A new read-only endpoint:
  `GET /api/cognitive-runtime/reports/{report_id}/evidence-diagnostics`

## Interpretation rules
- +1 is a reviewer-recorded supporting direction.
- -1 is a reviewer-recorded contradicting direction.
- 0 is an explicit F4 determination: no interpretable direction.
- No appraisal record means not yet reviewed; it is not F4.
- Passage count and distinct passage references are not treated as independent-source count.
- The diagnostic never selects a winner or declares evidence sufficient.

## Statuses
- `INSUFFICIENT_REVIEW_COVERAGE`
- `REVIEW_COVERAGE_INCOMPLETE`
- `CONFLICT_REQUIRES_RESOLUTION`
- `APPRAISALS_RECORDED_SUFFICIENCY_NOT_ESTABLISHED`

## Boundaries
This is a transparent diagnostic layer, not a statistical synthesis, source-authenticity verifier, source-dependency estimator, or approval gate. It does not release answers or train model weights.

## Validation
- Full clean-database regression: 395 passed, 0 failed.
- New v6.4 and v6.3 appraisal tests: 12 passed.
- Python compileall: passed.
- ZIP integrity: passed.
