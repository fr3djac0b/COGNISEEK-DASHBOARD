# COGNISEEK TLM v3.4.0 — Evidence Acquisition Intelligence

## Added
- `app/acquisition_intelligence.py`: claim-focused assessment of the currently stored project corpus and acquisition log.
- Searches stored passages for candidate material and records exact chunk/document provenance.
- Reports evidence coverage signals, acquisition successes/failures, older acquisition snapshots, missing publication-date metadata and source-host hints.
- Produces a bounded set of candidate search terms and explicit reviewer next steps.
- Append-only assessment snapshots preserve what the corpus looked like when the assessment was made.
- `POST /api/acquisition/assess`
- `GET /api/acquisition/assessments`

## Acquisition actions
- `ACQUIRE_EVIDENCE`: no matching stored passages were returned.
- `SEEK_CORROBORATION`: fewer than three candidate passages were returned.
- `REVIEW_EXISTING_EVIDENCE`: candidate passages exist and need reviewer assessment.

These are workflow recommendations, not claim verdicts. They do not automatically fetch URLs. The existing `/api/acquisition/fetch` remains user-directed and requires exact HTTPS allowlisted domains configured by the server operator.

## Boundaries
- Retrieval relevance is not support or contradiction.
- Candidate passage count is not evidential sufficiency or independent-source count.
- Source host diversity does not prove independence.
- Missing publication dates prevent recency assessment; they are not assumed current.
- Acquisition log entries show retrieval attempts, not source authenticity or claim truth.
- No automatic web search, URL crawling, model training, weight updates, or deployment.
