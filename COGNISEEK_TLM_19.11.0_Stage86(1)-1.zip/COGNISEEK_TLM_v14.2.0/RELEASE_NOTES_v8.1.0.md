# COGNISEEK TLM v8.1.0 — Episode-Aware Experience Application

## What changed
- Adds a controlled application step for previously consolidated contextual experiences.
- Each application is attached to a project and caller-supplied episode ID.
- Current evidence references are stored separately from historical experience IDs.
- Only experiences already consolidated in v8.0 are retrievable for application.
- Adds append-only reviewer assessments: `IMPROVED`, `NO_OBSERVED_DIFFERENCE`, `WORSENED`, `INDETERMINATE`.
- Application history can be retrieved by project and optionally by episode.

## New endpoints
- `POST /api/cognitive-runtime/learning/experience-applications`
- `POST /api/cognitive-runtime/learning/experience-applications/review`
- `GET /api/cognitive-runtime/learning/experience-applications?project=default&episode_id=...&limit=100`

## Important boundaries
- Similarity retrieval uses simple lexical matching; it is not semantic understanding or calibrated relevance.
- The episode ID and current evidence references are supplied by the caller and are not independently authenticated.
- A reviewer assessment is not a causal estimate. It does not prove experience caused an improvement.
- Historical experience does not set evidence direction, override current evidence, or automatically authorize an answer/action.
- No model weights are updated and no model training is performed.

## Verification
- Full clean-database regression suite: 541 passed, 0 failed.
- New v8.1 tests: 8 passed.
- Python compilation: passed.
- ZIP integrity: passed.
- No live external acquisition or model training was performed.
