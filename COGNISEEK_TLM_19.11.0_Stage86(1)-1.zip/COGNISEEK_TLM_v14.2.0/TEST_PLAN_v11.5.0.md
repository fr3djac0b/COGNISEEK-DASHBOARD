# v11.5.0 Test Plan

1. Run focused deployment-readiness tests in an isolated temporary directory.
2. Verify missing OIDC configuration blocks readiness.
3. Verify non-HTTPS JWKS configuration blocks readiness.
4. Verify missing database parent directory blocks readiness.
5. Verify a fully configured local preflight reports review readiness without claiming certification.
6. Verify model-provider configuration remains optional.
7. Verify preflight does not create a database file.
8. Run Python compile checks.
9. Import the FastAPI application and count registered routes.
10. Run the full regression suite with a fresh isolated SQLite database.
11. Verify M-RBAM source is byte-for-byte unchanged from v11.4.0.
12. Verify ZIP archive integrity.
