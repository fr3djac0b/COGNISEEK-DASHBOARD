# COGNISEEK TLM v0.6.1 — deployment notes

## Render

This repository is prepared for a Render Docker web service. Connect the repository in the Render dashboard and deploy `render.yaml` or create a Docker web service using `Dockerfile`.

Set `MODEL_NAME` and `OPENAI_API_KEY` only if you want to connect a compatible model. Never commit secrets to Git.

## Important before public use

- The current application has no authentication or per-user authorization. Do not enter personal, health, or other sensitive participant information into a public deployment.
- The default SQLite path may be ephemeral on a free host. Configure a persistent disk mounted at `/var/data` before relying on durable production records; this repository's basic free-service blueprint does not provision a persistent disk.
- Run the included tests before deployment. A passing synthetic test suite is not clinical validation.
- The application is a research prototype, not a diagnostic or treatment system.


## v9.9 security baseline
Set `COGNISEEK_API_KEY` to a random value of at least 32 characters to require bearer authentication on `/api/*`. Configure `COGNISEEK_RATE_LIMIT_PER_MINUTE` (default 1000) and `COGNISEEK_MAX_REQUEST_BYTES` (default 1048576). The in-process limiter is not shared across workers. Use TLS, reverse-proxy body limits and a shared edge rate limiter. This release does not yet provide user accounts or per-project authorization.
