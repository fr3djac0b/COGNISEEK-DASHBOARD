# COGNISEEK TLM v8.8.0 — Governed Learning Feedback Loop

## Purpose
Connect retrieval and v8.7 policy evaluation to a controlled, episode-scoped
experience application. The module records why each candidate was included as
context or withheld from routine reuse.

## New module
`app/governed_experience_feedback_loop.py`

## API
- `POST /api/cognitive-runtime/learning/governed-experience-application`
- `GET /api/cognitive-runtime/learning/governed-experience-decisions?project=default&episode_id=...&limit=100`

The POST request uses the existing `ExperienceApplicationIn` request schema:
project, episode_id, query_text, current_evidence_refs, limit, application_note,
and optionally current_observations where supported by the model.

## Controls
- Accepted-correction restrictions and repeated-unhelpful patterns are withheld
  from routine contextual reuse.
- Verification-required patterns can appear only as explicitly provisional
  context and are flagged for fresh verification before reliance.
- Other eligible experiences remain context-only and require current evidence.
- Current evidence references are stored separately from historical experience.
- Append-only per-candidate policy/disposition history is recorded.

## Guardrails
This release does not authenticate evidence references, verify claims, update
model weights, mutate consolidated memory, release answers, or authorize actions.
Reviewer-entered outcomes remain descriptive rather than causal.
