# COGNISEEK TLM v14.9.0 — Stage 34

Connects Stage 33 scalar reverse-mode autodiff to differentiable matrix multiplication,
residual addition, RMSNorm, RoPE, causal attention, SiLU/SwiGLU and a composed decoder
block. Tests verify gradient flow through the block and finite-difference agreement.

Reference implementation only; no model-scale training loop, full multi-head/GQA,
embeddings, vocabulary projection, checkpoints or trained weights.
