# COGNISEEK TLM v2.3.0

## Evidence Conflict and Dependency Diagnostics

- Added `app/conflict_analysis.py`.
- Added `POST /api/claims/evidence-conflicts`.
- Added `GET /api/claims/evidence-conflicts/history`.
- Detects mixed reviewer-confirmed `SUPPORTS` and `CONTRADICTS` directions.
- Detects conflicting reviewer directions attached to the same passage.
- Counts distinct passages separately from review events.
- Keeps `NEUTRAL` and `INDETERMINATE` separate from directional evidence.
- Surfaces possible dependency clusters using same-document identity, exact source URI, and source-group hints.
- Flags stale, missing, and unparseable publication dates and missing scope/limitations.
- Saves append-only diagnostic snapshots.

## Explicit boundaries

- No automatic winner selection or truth adjudication.
- No source-independence certification.
- Dependency clusters are diagnostic hints, not proof of dependence.
- Staleness is a review prompt, not automatic rejection.
- Reviewer directions remain human-supplied.
- Legacy evidence relations are not joined to document/chunk links because their identifier domains do not match.
