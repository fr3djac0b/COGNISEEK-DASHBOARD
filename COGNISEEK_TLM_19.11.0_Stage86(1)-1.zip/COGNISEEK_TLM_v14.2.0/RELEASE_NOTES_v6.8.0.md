# COGNISEEK TLM v6.8.0 — Temporal Knowledge Reconciliation

## Purpose
Adds a time-aware assertion ledger. A fact can have a valid-time interval (when it is claimed to be true) and a recorded-time timestamp (when COGNISEEK stored it). New claims are compared with earlier claims without automatically overwriting or accepting either one.

## Added
- Append-only `cognitive_temporal_assertions` table.
- Append-only `cognitive_temporal_events` reconciliation table.
- `POST /api/cognitive-runtime/temporal/assertions` to record a time-bounded assertion.
- `POST /api/cognitive-runtime/temporal/reconcile` to record a reviewer decision.
- `GET /api/cognitive-runtime/temporal/knowledge` to inspect the time-aware knowledge view, optionally `?as_of=<ISO-8601 timestamp>`.
- Overlap detection for assertions sharing the same subject and predicate but differing in value.
- Reconciliation actions: `SUPERSEDE`, `RETAIN_BOTH`, `MARK_DISPUTED`, `RETRACT`.
- Timezone-aware ISO-8601 validation; valid-to must be after valid-from.

## Temporal model
- Valid time: when the assertion is said to apply.
- Recorded time: when the assertion was stored by the system.
- Overlapping different values are flagged as candidate conflicts.
- A later assertion does not automatically supersede an earlier assertion.
- Reviewer decisions are append-only events; original assertions are retained.
- As-of views filter by valid time and preserve unresolved disagreements.

## Guardrails
- Caller-supplied valid times and source references are not independently verified.
- Overlap detection does not determine which claim is true.
- Reconciliation events do not rewrite original assertions.
- Reviewer identity and rationale are caller-supplied; this prototype does not authenticate reviewer credentials.
- This ledger does not automatically update model weights or silently modify prior episodes.
- No automatic truth, source quality, or release permission is inferred.

## Validation
- Full regression suite: 438 passed.
- New v6.8 tests: 13 passed (included in full regression).
- Python compileall: PASS.
- ZIP integrity: PASS.
- Isolated temporary SQLite database used; no production/user database modified.
- No live external acquisition performed.
