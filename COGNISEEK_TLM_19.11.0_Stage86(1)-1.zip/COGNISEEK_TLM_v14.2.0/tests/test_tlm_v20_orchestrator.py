import pytest
from fastapi.testclient import TestClient

def test_claim_splitter_extracts_candidate_sentences_not_truth():
    from app.orchestrator import split_candidate_claims
    items = split_candidate_claims("Claim one is supported by evidence. Claim two remains uncertain.")
    assert len(items) == 2
    assert items[0]["claim_index"] == 0
    assert items[1]["review_required"] is True

def test_orchestrator_abstains_when_no_claim_has_interpretable_evidence(tmp_path):
    from app.orchestrator import orchestrate
    result = orchestrate(str(tmp_path/"orch.sqlite3"), "p", "Question?",
        "The first claim has a factual assertion. The second claim is another factual assertion.")
    assert result["overall_response_action"] == "ABSTAIN"
    assert all(x["status"] == "INSUFFICIENT_EVIDENCE" for x in result["claims"])
    assert "No unqualified ANSWER" in result["overall_policy"]

def test_orchestrator_preserves_per_claim_mixed_and_f4_states(tmp_path):
    from app.orchestrator import orchestrate
    result = orchestrate(str(tmp_path/"orch.sqlite3"), "p", "Question?",
        "First claim has evidence. Second claim has no direction.",
        [
            {"claim_index":0,"evidence":[
                {"evidence_id":"a","direction":"SUPPORTS"},
                {"evidence_id":"b","direction":"CONTRADICTS"}]},
            {"claim_index":1,"evidence":[
                {"evidence_id":"c","direction":"NEUTRAL"},
                {"evidence_id":"d","direction":"INDETERMINATE"}]}
        ])
    assert result["claims"][0]["status"] == "MIXED_EVIDENCE"
    assert result["claims"][1]["status"] == "NO_INTERPRETABLE_EVIDENCE"
    assert result["claims"][1]["f4_compatibility"] is True
    assert result["overall_response_action"] == "QUALIFY"

def test_orchestrator_allows_review_supported_claim_but_never_unqualified_answer(tmp_path):
    from app.orchestrator import orchestrate
    result = orchestrate(str(tmp_path/"orch.sqlite3"), "p", "Question?",
        "The intervention reduced the measured outcome.",
        [{"claim_index":0,"evidence":[
            {"evidence_id":"a","direction":"SUPPORTS"},
            {"evidence_id":"b","direction":"SUPPORTS"}]}])
    assert result["claims"][0]["status"] == "SUPPORTED_FOR_REVIEW"
    assert result["overall_response_action"] == "QUALIFY"
    assert result["assembly"]["qualified_answer"].startswith("[SUPPORTED_FOR_REVIEW]")

def test_orchestrator_rejects_out_of_range_claim_index(tmp_path):
    from app.orchestrator import orchestrate
    with pytest.raises(ValueError, match="outside"):
        orchestrate(str(tmp_path/"orch.sqlite3"), "p", "Question?",
            "A factual claim is made here.", [{"claim_index":9,"evidence":[]}])

def test_orchestrator_persists_and_isolates_projects(tmp_path):
    from app.orchestrator import orchestrate, list_orchestrations
    db = str(tmp_path/"orch.sqlite3")
    one = orchestrate(db, "alpha", "Q1", "A factual claim is present.")
    assert list_orchestrations(db,"alpha")[0]["orchestration_id"] == one["orchestration_id"]
    assert list_orchestrations(db,"beta") == []

def test_orchestration_api_and_health_version(monkeypatch, tmp_path):
    import app.main as main
    from app.trace import Store
    db = str(tmp_path/"api.sqlite3")
    monkeypatch.setattr(main,"DB_PATH",db)
    monkeypatch.setattr(main,"store",Store(db))
    client=TestClient(main.app)
    health=client.get("/health")
    assert health.status_code==200
    assert health.json()["version"]=="10.4.0"
    response=client.post("/api/answer/orchestrate",json={
        "project":"demo","user_request":"Does the intervention work?",
        "draft_answer":"The intervention reduced the measured outcome.",
        "claim_reviews":[{"claim_index":0,"evidence":[
            {"evidence_id":"r1","direction":"SUPPORTS"},
            {"evidence_id":"r2","direction":"SUPPORTS"}]}]
    })
    assert response.status_code==200,response.text
    assert response.json()["result"]["overall_response_action"]=="QUALIFY"
    assert response.json()["stored_append_only"] is True
    listing=client.get("/api/answer/orchestrations?project=demo")
    assert listing.status_code==200
    assert len(listing.json()["items"])==1
