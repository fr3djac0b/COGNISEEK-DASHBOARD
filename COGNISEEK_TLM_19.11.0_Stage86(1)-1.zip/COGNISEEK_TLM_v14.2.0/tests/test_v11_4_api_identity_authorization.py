import json
import sqlite3
import pytest

from app import api_identity_authorization as auth
from app import identity_provider


class Principal:
    subject = "user-123"
    issuer = "https://issuer.example"
    audience = "cogniseek-api"
    roles = ("OPERATOR", "VIEWER")
    projects = ("project-a",)
    def public_dict(self):
        return {"subject": self.subject, "roles": list(self.roles),
                "projects": list(self.projects), "authenticated": True}


def test_signed_membership_and_role_are_required(monkeypatch, tmp_path):
    db = str(tmp_path / "auth.sqlite")
    monkeypatch.setattr(identity_provider, "verify_bearer_token",
                        lambda token, project: Principal())
    result = auth.authorize(db, "project-a", "signed-token",
                            ("ADMIN", "OPERATOR"), "/sensitive")
    assert result["authenticated"] is True
    assert result["subject"] == "user-123"
    assert result["role"] == "OPERATOR"
    assert result["authorization_event_id"]


def test_missing_role_is_denied_and_audited(monkeypatch, tmp_path):
    db = str(tmp_path / "auth.sqlite")
    monkeypatch.setattr(identity_provider, "verify_bearer_token",
                        lambda token, project: Principal())
    with pytest.raises(PermissionError, match="role_not_authorized"):
        auth.authorize(db, "project-a", "token", ("ADMIN",), "/admin")
    events = auth.history(db, "project-a")["items"]
    assert len(events) == 1
    assert events[0]["decision"] == "DENY"
    assert events[0]["reason"] == "required_role_missing"


def test_project_membership_is_enforced_by_identity_provider(monkeypatch, tmp_path):
    db = str(tmp_path / "auth.sqlite")
    def verify(token, project):
        if project != "project-a":
            raise identity_provider.IdentityVerificationError("project_scope_denied")
        return Principal()
    monkeypatch.setattr(identity_provider, "verify_bearer_token", verify)
    with pytest.raises(PermissionError, match="authentication_required"):
        auth.authorize(db, "project-b", "token", ("VIEWER",), "/read")
    assert auth.history(db, "project-b")["items"][0]["decision"] == "DENY"


def test_misconfigured_identity_provider_fails_closed(monkeypatch, tmp_path):
    db = str(tmp_path / "auth.sqlite")
    monkeypatch.setattr(identity_provider, "verify_bearer_token",
                        lambda *a: (_ for _ in ()).throw(
                            identity_provider.IdentityConfigurationError("missing OIDC config")))
    with pytest.raises(PermissionError, match="identity_provider_misconfigured"):
        auth.authorize(db, "p", "token", ("VIEWER",), "/read")


def test_no_bearer_token_fails_closed(monkeypatch, tmp_path):
    db = str(tmp_path / "auth.sqlite")
    monkeypatch.setattr(identity_provider, "verify_bearer_token",
                        lambda token, project: (_ for _ in ()).throw(
                            identity_provider.IdentityVerificationError("bearer_token_required")))
    with pytest.raises(PermissionError, match="authentication_required"):
        auth.authorize(db, "p", None, ("VIEWER",), "/read")


def test_authorization_history_is_project_scoped(monkeypatch, tmp_path):
    db = str(tmp_path / "auth.sqlite")
    monkeypatch.setattr(identity_provider, "verify_bearer_token",
                        lambda token, project: Principal())
    auth.authorize(db, "project-a", "token", ("VIEWER",), "/read")
    assert len(auth.history(db, "project-a")["items"]) == 1
    assert auth.history(db, "project-b")["items"] == []


def test_invalid_role_requirement_rejected(tmp_path):
    db = str(tmp_path / "auth.sqlite")
    with pytest.raises(ValueError, match="invalid_required_roles"):
        auth.authorize(db, "p", "token", ("ROOT",), "/read")


def test_auth_audit_is_append_only(tmp_path):
    db = str(tmp_path / "auth.sqlite")
    auth.initialize(db)
    with sqlite3.connect(db) as conn:
        count = conn.execute("SELECT COUNT(*) FROM api_identity_authorization_events").fetchone()[0]
    assert count == 0
    # The table has no update/delete path in this module; events are inserted only.
    columns = [x[1] for x in sqlite3.connect(db).execute(
        "PRAGMA table_info(api_identity_authorization_events)").fetchall()]
    assert "event_json" in columns


def test_admin_role_can_satisfy_lower_privilege_gate(monkeypatch, tmp_path):
    db = str(tmp_path / "auth.sqlite")
    class AdminPrincipal(Principal):
        roles = ("ADMIN",)
    monkeypatch.setattr(identity_provider, "verify_bearer_token",
                        lambda token, project: AdminPrincipal())
    result = auth.authorize(db, "project-a", "token", ("ADMIN", "OPERATOR"), "/operator")
    assert result["role"] == "ADMIN"
