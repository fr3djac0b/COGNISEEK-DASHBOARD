import unittest
from app.stage82_security_hardening import RuntimeSecurity,SecurityHardeningError
class T(unittest.TestCase):
 def test_production_missing_controls_fail(self): self.assertFalse(RuntimeSecurity({'APP_ENV':'production'}).validate()['valid'])
 def test_valid_production_config(self):
  e={'APP_ENV':'production','APP_AUTH_TOKEN':'x'*40,'CORS_ORIGINS':'https://app.example','DATABASE_PATH':'/var/data/db.sqlite','DEBUG':'false'}; self.assertTrue(RuntimeSecurity(e).validate()['valid'])
 def test_path_traversal_blocked(self):
  with self.assertRaises(SecurityHardeningError): RuntimeSecurity.safe_project_path('/safe','../../etc/passwd')
