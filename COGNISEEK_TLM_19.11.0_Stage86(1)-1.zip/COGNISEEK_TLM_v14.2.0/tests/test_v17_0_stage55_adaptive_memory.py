import tempfile, unittest
from pathlib import Path
from app.stage54_episodic_memory import EpisodicMemory
from app.stage55_adaptive_memory import AdaptiveMemoryRetriever, AdaptiveMemoryError, cosine

def fake_embed(texts):
    vocab={"cat":[1.,0.,0.],"kitten":[.99,.01,0.],"feline":[.98,.02,0.],
           "car":[0.,1.,0.],"vehicle":[.01,.99,0.],"engine":[.02,.98,0.],
           "evidence":[0.,0.,1.],"source":[.01,0.,.99]}
    out=[]
    for text in texts:
        v=[0.,0.,0.]
        for word in text.lower().split():
            x=vocab.get(word,[.1,.1,.1]); v=[a+b for a,b in zip(v,x)]
        out.append(v if any(v) else [1.,1.,1.])
    return out

class Stage55Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Path(self.tmp.name)/"episodic.sqlite"
        self.mem=EpisodicMemory(self.db)
        self.episode=self.mem.record_episode(query="test episode")
        self.cat=self.mem.record_event(memory_type="experience",content="cat kitten feline animal",
            episode_id=self.episode,project="p")
        self.car=self.mem.record_event(memory_type="experience",content="car vehicle engine transport",
            episode_id=self.episode,project="p")
        self.r=AdaptiveMemoryRetriever(self.mem,Path(self.tmp.name)/"adaptive.sqlite",fake_embed)
        self.r.index_event(self.cat,project="p"); self.r.index_event(self.car,project="p")
    def tearDown(self): self.tmp.cleanup()
    def test_semantic_retrieval_finds_synonym(self):
        results=self.r.search("kitten",project="p")
        self.assertEqual(results[0]["event_id"],self.cat)
        self.assertIsNotNone(results[0]["semantic_cosine"])
    def test_lexical_fallback_without_embedder(self):
        r=AdaptiveMemoryRetriever(self.mem,Path(self.tmp.name)/"lex.sqlite")
        results=r.search("engine",project="p")
        self.assertEqual(results[0]["event_id"],self.car)
        self.assertIsNone(results[0]["semantic_cosine"])
    def test_feedback_changes_ranking_and_is_audit_record(self):
        fid=self.r.record_feedback(self.cat,"useful",project="p",notes="helped answer")
        self.assertTrue(fid)
        result=self.r.search("kitten",project="p")[0]
        self.assertEqual(result["feedback_counts"]["useful"],1)
        self.assertGreater(result["feedback_score"],0)
    def test_outdated_feedback_adds_caution(self):
        self.r.record_feedback(self.cat,"outdated",project="p")
        result=self.r.search("kitten",project="p")[0]
        self.assertIn("user_marked_outdated",result["cautions"])
    def test_contradiction_relation_is_visible(self):
        self.r.record_relation(self.cat,self.car,"contradicts",project="p")
        result=self.r.search("kitten",project="p")[0]
        self.assertIn("linked_contradictory_memory",result["cautions"])
    def test_duplicate_detection(self):
        duplicate=self.mem.record_event(memory_type="experience",content="cat kitten feline animal",
            episode_id=self.episode,project="p")
        self.r.index_event(duplicate,project="p")
        pairs=self.r.detect_duplicates(project="p",threshold=.99)
        self.assertTrue(any({x["event_id"],x["candidate_event_id"]}=={self.cat,duplicate} for x in pairs))
    def test_project_isolation(self):
        self.assertEqual(self.r.search("kitten",project="other"),[])
        with self.assertRaisesRegex(AdaptiveMemoryError,"memory_event_not_found"):
            self.r.index_event(self.cat,project="other")
    def test_index_project(self):
        report=self.r.index_project(project="p")
        self.assertEqual(report["indexed_events"],2)
    def test_cosine_validation(self):
        with self.assertRaises(AdaptiveMemoryError): cosine([1],[1,2])
    def test_query_and_feedback_validation(self):
        with self.assertRaises(AdaptiveMemoryError): self.r.search(" ")
        with self.assertRaisesRegex(AdaptiveMemoryError,"unsupported_feedback_label"):
            self.r.record_feedback(self.cat,"love",project="p")
    def test_reverse_contradiction_link_is_visible(self):
        self.r.record_relation(self.cat,self.car,"contradicts",project="p")
        result=self.r.search("engine",project="p")[0]
        self.assertIn("linked_contradictory_memory",result["cautions"])
    def test_duplicate_scan_limit_is_bounded(self):
        with self.assertRaisesRegex(AdaptiveMemoryError,"duplicate_limit_must_be_1_to_5000"):
            self.r.detect_duplicates(project="p",limit=0)
    def test_semantic_only_candidate_requires_minimum_similarity(self):
        # The car record is indexed but has no lexical overlap with this query.
        result=self.r.search("kitten",project="p")
        self.assertTrue(all(x["event_id"] != self.car for x in result))
    def test_stage54_rag_ingestion_flows_into_stage55(self):
        imported=self.mem.ingest_rag_result({"query":"How do cats communicate?","answer":"Cats communicate through vocalization and body language.","sources":[{"chunk_id":"source-1"}]},project="p")
        self.r.index_event(imported["observation_event_id"],project="p")
        result=self.r.search("cats communicate",project="p")
        self.assertTrue(any(x["event_id"]==imported["observation_event_id"] for x in result))
        self.assertTrue(any(x["event_id"]==imported["inference_event_id"] for x in result))
    def test_memory_type_filter_is_validated(self):
        with self.assertRaisesRegex(AdaptiveMemoryError,"unsupported_memory_type_filter"):
            self.r.search("kitten",project="p",memory_types=["imaginary"])
    def test_memory_relevance_is_not_truth(self):
        result=self.r.search("kitten",project="p")[0]
        self.assertIn("do not establish truth",result["retrieval_warning"])
        self.assertEqual(result["truth_status"],"not_verified")

if __name__=="__main__": unittest.main()
