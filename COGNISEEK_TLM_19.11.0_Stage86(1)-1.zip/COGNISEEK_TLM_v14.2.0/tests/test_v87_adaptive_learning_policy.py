import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from test_v86_cross_episode_learning_evaluation import setup_db, seed_candidate, add_app
from app import adaptive_learning_policy as policy

def test_insufficient_history_is_cautious(tmp_path):
    db=setup_db("policy1.db",tmp_path); seed_candidate(db)
    result=policy.evaluate_candidate(db,"p","c1")
    assert result["policy_action"]=="CAUTIOUS_CONTEXTUAL_REUSE"
    assert result["controls"]["current_evidence_required"] is True

def test_repeated_worsening_excludes_routine_reuse(tmp_path):
    db=setup_db("policy2.db",tmp_path); seed_candidate(db)
    for i in range(3): add_app(db,"c1",f"e{i}","WORSENED",["ev"])
    result=policy.evaluate_candidate(db,"p","c1")
    assert result["policy_action"]=="EXCLUDE_FROM_ROUTINE_REUSE"
    assert result["advisory_reuse_tier"]==0

def test_policy_does_not_mutate_experience_records(tmp_path):
    import sqlite3
    db=setup_db("policy3.db",tmp_path); seed_candidate(db)
    before=sqlite3.connect(db).execute("SELECT COUNT(*) FROM contextual_experience_reviews").fetchone()[0]
    policy.evaluate_candidate(db,"p","c1")
    after=sqlite3.connect(db).execute("SELECT COUNT(*) FROM contextual_experience_reviews").fetchone()[0]
    assert before==after

def test_unknown_candidate_rejected(tmp_path):
    db=setup_db("policy4.db",tmp_path)
    try:
        policy.evaluate_candidate(db,"p","missing")
        assert False
    except ValueError as exc:
        assert str(exc)=="consolidated_candidate_not_found_in_project"

def test_project_report_groups_policy_actions(tmp_path):
    db=setup_db("policy5.db",tmp_path); seed_candidate(db)
    report=policy.project_policy(db,"p")
    assert report["candidate_count"]==1
    assert sum(report["policy_action_counts"].values())==1
