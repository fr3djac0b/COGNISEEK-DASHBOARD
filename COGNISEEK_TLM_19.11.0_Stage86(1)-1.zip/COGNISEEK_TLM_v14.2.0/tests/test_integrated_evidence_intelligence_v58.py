import sqlite3, pytest
from app import structured_findings as sf
from app import integrated_evidence_intelligence as ie

def setup(tmp_path):
    db=str(tmp_path/"integrated.sqlite")
    with sqlite3.connect(db) as c:
        c.execute("CREATE TABLE document_chunks(chunk_id TEXT PRIMARY KEY, project TEXT, document_id TEXT, text TEXT)")
    passage="In this study, the intervention reduced the primary outcome."
    with sqlite3.connect(db) as c:
        c.execute("INSERT INTO document_chunks VALUES(?,?,?,?)",("ch-1","proj","doc-1",passage))
    sf.initialize(db)
    excerpt=passage[15:57]
    f=sf.create_candidate(db,"proj","ch-1",{
        "intervention":"intervention","comparator":"control","outcome":"primary outcome",
        "effect_measure":"RR","effect_estimate":0.75,"ci_lower":0.60,"ci_upper":0.92,
        "confidence_level":95,"population":"adults","follow_up_period":"12 weeks","units":"ratio",
        "directionality":"benefit"
    },excerpt,15,57)
    sf.review_candidate(db,"proj",f["finding_id"],"reviewer-a","APPROVE","Matches passage")
    sf.review_candidate(db,"proj",f["finding_id"],"reviewer-b","APPROVE","Matches passage")
    return db,f["finding_id"]

def test_integrated_workflow_runs_all_stages_and_is_retrievable(tmp_path):
    db,fid=setup(tmp_path)
    result=ie.run_workflow(db,"proj",[fid],"What does the study report?")
    assert result["workflow_status"] in {"COMPLETED","WARNING"}
    assert result["references"]["statistical_report_id"]
    assert result["references"]["comparability_report_id"]
    assert result["references"]["synthesis_report_id"]
    assert result["references"]["response_id"]
    assert result["references"]["audit_id"]
    assert result["references"]["validation_report_id"]
    assert [x["stage"] for x in result["stages"]][-1]=="END_TO_END_VALIDATION"
    assert "intervention reduced" in result["response_text"]
    assert ie.get_workflow(db,"proj",result["workflow_id"])["workflow_id"]==result["workflow_id"]

def test_workflow_project_scope_and_append_only_history(tmp_path):
    db,fid=setup(tmp_path)
    first=ie.run_workflow(db,"proj",[fid],run_governance_audit=False)
    second=ie.run_workflow(db,"proj",[fid],run_governance_audit=False)
    assert len(ie.list_workflows(db,"proj")["items"])==2
    with pytest.raises(ValueError,match="not_found_in_project"):
        ie.get_workflow(db,"other",first["workflow_id"])

def test_duplicate_ids_rejected(tmp_path):
    db,fid=setup(tmp_path)
    with pytest.raises(ValueError,match="duplicate_finding_ids"):
        ie.run_workflow(db,"proj",[fid,fid])

def test_unreviewed_finding_is_preserved_as_warning_not_support(tmp_path):
    db,fid=setup(tmp_path)
    with sqlite3.connect(db) as c:
        c.execute("DELETE FROM finding_reviews WHERE finding_id=?",(fid,))
    result=ie.run_workflow(db,"proj",[fid],run_governance_audit=False)
    assert result["response_text"] is not None
    assert result["workflow_status"] in {"WARNING","BLOCKED"}
