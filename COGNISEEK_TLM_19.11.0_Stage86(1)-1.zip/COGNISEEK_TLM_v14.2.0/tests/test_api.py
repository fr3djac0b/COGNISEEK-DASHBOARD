import pytest
import os
from fastapi.testclient import TestClient

# The module is imported after the isolated database path is set by the test runner.
from app.main import app
client = TestClient(app)

def test_health_and_static_assets():
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["version"] == "10.4.0"
    assert health.json()["trained_foundation_model"] is False
    assert client.get("/").status_code == 200
    assert client.get("/static/app.js").status_code == 200
    assert client.get("/static/style.css").status_code == 200

def test_evidence_persists_and_duplicate_is_flagged(monkeypatch):
    from app import main as _main; monkeypatch.setattr(_main, '_require_api_principal', lambda *args, **kwargs: {})
    payload = {"project":"test-project","claim":"Pump pressure stable","source_name":"sensor-A","status":"supports"}
    first = client.post("/api/evidence", json=payload)
    second = client.post("/api/evidence", json=payload)
    assert first.status_code == second.status_code == 200
    assert first.json()["duplicate_detected"] is False
    assert second.json()["duplicate_detected"] is True
    items = client.get("/api/evidence", params={"project":"test-project"}).json()["items"]
    assert len(items) == 2  # retained for audit, but marked as duplicate

def test_conflict_review_does_not_choose_a_winner(monkeypatch):
    from app import main as _main; monkeypatch.setattr(_main, '_require_api_principal', lambda *args, **kwargs: {})
    base = {"project":"conflict-project","claim":"Door is open","source_name":"source-1"}
    client.post("/api/evidence", json={**base,"status":"supports"})
    client.post("/api/evidence", json={**base,"source_name":"source-2","status":"contradicts"})
    result = client.post("/api/claims/review", json={"project":"conflict-project","claim_query":"door is open"}).json()
    assert result["state"] == "conflict"
    assert len(result["records"]) == 2

def test_missing_claim_is_insufficient():
    result = client.post("/api/claims/review", json={"project":"empty-project","claim_query":"no matching evidence"}).json()
    assert result["state"] == "insufficient"

def test_chat_saves_trace_and_trajectory_in_demo_mode():
    result = client.post("/api/chat", json={"project":"chat-project","message":"Explain the evidence"})
    assert result.status_code == 200
    body = result.json()
    assert body["mode"] == "demo"
    assert [x["stage"] for x in body["events"]] == ["observe","retrieve_memory","appraise","verify","update","respond","learn"]
    assert client.get("/api/trajectory", params={"project":"chat-project"}).json()["items"]
    assert client.get("/api/traces", params={"project":"chat-project"}).json()["items"]

def test_sse_stream_emits_meta_answer_and_done():
    response = client.post("/api/chat/stream", json={"project":"stream-project","message":"hello"})
    assert response.status_code == 200
    assert "text/event-stream" in response.headers["content-type"]
    assert "event: meta" in response.text and "event: done" in response.text and "COGNISEEK" in response.text

def test_input_validation_rejects_blank_claim_and_long_project():
    assert client.post("/api/evidence", json={"project":"p","claim":" ","source_name":"source"}).status_code == 422
    assert client.post("/api/chat", json={"project":"x"*121,"message":"hello"}).status_code == 422


def test_feedback_is_persisted_and_summary_does_not_claim_training():
    chat = client.post("/api/chat", json={"project":"feedback-project","message":"test interaction"}).json()
    trace_id = chat["trace_id"]
    response = client.post("/api/feedback", json={
        "project":"feedback-project", "trace_id":trace_id,
        "feedback_type":"correction", "note":"The answer missed a condition.",
        "correction":"Include the missing condition.",
    })
    assert response.status_code == 200
    assert response.json()["model_parameters_updated"] is False
    item = response.json()["item"]
    assert item["trace_id"] == trace_id
    listed = client.get("/api/feedback", params={"project":"feedback-project"}).json()["items"]
    assert listed[0]["feedback_id"] == item["feedback_id"]
    summary = client.get("/api/learning/summary", params={"project":"feedback-project"}).json()
    assert summary["total_feedback"] == 1
    assert summary["linked_feedback"] == 1
    assert summary["by_type"] == {"correction": 1}
    assert summary["model_parameters_updated"] is False


def test_feedback_rejects_unknown_trace_and_invalid_type():
    missing = client.post("/api/feedback", json={
        "project":"feedback-project", "trace_id":"not-a-real-trace",
        "feedback_type":"disagree", "note":"Check this.",
    })
    assert missing.status_code == 404
    invalid = client.post("/api/feedback", json={
        "project":"feedback-project", "feedback_type":"train-model",
    })
    assert invalid.status_code == 422


def test_mrbam_strict_protocol_keeps_coverage_gap_as_uc():
    response = client.post('/api/m-rbam/episodes', json={
        'project':'mrbam-test', 'participant_id':'synthetic-1', 'episode_id':'S4',
        'a_pre':2, 'a_post':8, 'evidence_direction':-1,
        'protocol_version':'strict_alignment_v0.2', 'interpretability':True,
        'evidence_valid':True, 'comprehension':True,
        'evidence_coding_reason':'Synthetic example only'
    })
    assert response.status_code == 200
    result = response.json()['result']
    assert result['delta_a'] == 6
    assert result['u'] == -6
    assert result['response_form'] == 'UC'
    assert response.json()['clinical_decision'] is False


def test_mrbam_directional_profile_f1_f4_and_missing_scores():
    base = {'project':'mrbam-directional-test','protocol_version':'directional_v0.1',
            'a_pre':4,'a_post':4,'evidence_direction':1}
    f2 = client.post('/api/m-rbam/episodes', json=base)
    assert f2.status_code == 200 and f2.json()['result']['response_form'] == 'F2'
    f4 = client.post('/api/m-rbam/episodes', json={**base,'episode_id':'indeterminate','evidence_direction':None})
    assert f4.status_code == 200 and f4.json()['result']['response_form'] == 'F4'
    na = client.post('/api/m-rbam/episodes', json={**base,'episode_id':'missing','a_post':None})
    assert na.status_code == 200
    assert na.json()['result']['response_form'] == 'NA'
    assert na.json()['result']['delta_a'] is None


def test_mrbam_trajectory_keeps_three_series_separate():
    client.post('/api/m-rbam/episodes', json={
        'project':'mrbam-trajectory-test','participant_id':'p1','episode_id':'one',
        'episode_datetime':'20.6.11-01T10:00:00','a_pre':2,'a_post':8,'evidence_direction':1,
        'protocol_version':'directional_v0.1'
    })
    client.post('/api/m-rbam/episodes', json={
        'project':'mrbam-trajectory-test','participant_id':'p1','episode_id':'two',
        'episode_datetime':'20.6.12-01T10:00:00','a_pre':5,'a_post':None,'evidence_direction':1,
        'protocol_version':'directional_v0.1'
    })
    trajectory = client.get('/api/m-rbam/trajectory', params={'project':'mrbam-trajectory-test','participant_id':'p1'}).json()
    assert trajectory['QAAT'] == [6, None]
    assert trajectory['UAT'] == [6, None]
    assert trajectory['CAR'] == ['F1', 'NA']


def test_mrbam_protocol_versions_are_explicit():
    data = client.get('/api/m-rbam/protocols').json()
    assert data['default_protocol'] == 'strict_alignment_v0.2'
    assert len(data['available_protocols']) == 2


def test_v07_evidence_provenance_and_source_grouping(monkeypatch):
    from app import main as _main; monkeypatch.setattr(_main, '_require_api_principal', lambda *args, **kwargs: {})
    base = {"project":"prov-project", "claim":"Water sample has elevated iron", "source_name":"Report A",
            "status":"supports", "source_uri":"https://example.test/a", "publisher":"Lab Authority",
            "author":"Research Unit", "published_at":"2026-01-01", "source_group":"same-study",
            "method":"ICP-MS", "scope":"One sampling site", "limitations":"Single time point"}
    first = client.post("/api/evidence", json=base)
    second = client.post("/api/evidence", json={**base, "source_name":"Report A copy"})
    assert first.status_code == second.status_code == 200
    assert second.json()["duplicate_detected"] is False  # source name differs: not an exact duplicate
    report = client.get("/api/evidence/qualification", params={"project":"prov-project"}).json()
    assert report["record_count"] == 2
    assert report["distinct_source_groups"] == 1
    assert "not verified independence" in report["notice"]


def test_v07_evidence_relations_are_project_scoped_and_auditable(monkeypatch):
    from app import main as _main; monkeypatch.setattr(_main, '_require_api_principal', lambda *args, **kwargs: {})
    a = client.post("/api/evidence", json={"project":"rel-project","claim":"Claim A","source_name":"Source A"}).json()["item"]
    b = client.post("/api/evidence", json={"project":"rel-project","claim":"Claim B","source_name":"Source B"}).json()["item"]
    response = client.post("/api/evidence/relations", json={"project":"rel-project", "from_evidence_id":a["id"],
        "to_evidence_id":b["id"], "relation_type":"derived_from", "note":"B cites A"})
    assert response.status_code == 200
    assert response.json()["automatically_verified"] is False
    items = client.get("/api/evidence/relations", params={"project":"rel-project","evidence_id":a["id"]}).json()["items"]
    assert len(items) == 1 and items[0]["relation_type"] == "derived_from"


def test_v07_rejects_cross_project_relation(monkeypatch):
    from app import main as _main; monkeypatch.setattr(_main, '_require_api_principal', lambda *args, **kwargs: {})
    a = client.post("/api/evidence", json={"project":"p-one","claim":"A","source_name":"S"}).json()["item"]
    b = client.post("/api/evidence", json={"project":"p-two","claim":"B","source_name":"S"}).json()["item"]
    response = client.post("/api/evidence/relations", json={"project":"p-one", "from_evidence_id":a["id"],
        "to_evidence_id":b["id"], "relation_type":"contradicts"})
    assert response.status_code == 422


def test_v08_document_ingestion_duplicate_and_retrieval():
    payload={"project":"docs-project","title":"Malaria report","text":"Plasmodium falciparum causes malaria. The parasite has a complex life cycle involving mosquito and human hosts.\n\nDiagnosis requires appropriate laboratory evidence.","source_name":"User supplied report","publisher":"Example Institute","source_group":"study-1"}
    first=client.post("/api/documents",json=payload)
    assert first.status_code==200 and first.json()["chunk_count"]>=1
    duplicate=client.post("/api/documents",json=payload)
    assert duplicate.status_code==200 and duplicate.json()["duplicate_detected"] is True
    docs=client.get("/api/documents",params={"project":"docs-project"}).json()["items"]
    assert len(docs)==1
    found=client.get("/api/retrieval/search",params={"project":"docs-project","q":"Plasmodium falciparum malaria"}).json()
    assert found["results"] and "Plasmodium" in found["results"][0]["text"]
    assert "not truth" in found["notice"]

def test_v08_document_projects_are_isolated():
    client.post("/api/documents",json={"project":"doc-a","title":"A","text":"Unique evidence about basalt formations.","source_name":"A"})
    result=client.get("/api/retrieval/search",params={"project":"doc-b","q":"basalt formations"}).json()
    assert result["results"]==[]

def test_v08_rejects_blank_document_text():
    response=client.post("/api/documents",json={"project":"p","title":"Blank","text":" ","source_name":"s"})
    assert response.status_code==422


@pytest.fixture(autouse=True)
def _legacy_episode_learning_authorization_test_bypass(monkeypatch, request):
    protected_legacy_tests = {
        "test_v08_document_ingestion_duplicate_and_retrieval",
        "test_mrbam_trajectory_keeps_three_series_separate",
    }
    if request.function.__name__ in protected_legacy_tests:
        from app import main as _main
        monkeypatch.setattr(_main, "_require_api_principal", lambda *args, **kwargs: {})
