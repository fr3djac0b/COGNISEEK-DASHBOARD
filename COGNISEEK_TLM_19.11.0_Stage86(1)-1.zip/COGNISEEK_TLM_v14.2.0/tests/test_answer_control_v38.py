import json
import sqlite3
from app import answer_control

def review(*statuses):
    return {"run_id":"ground-1","claim_ledger":[
        {"appraisal":{"status":s}} for s in statuses
    ]}

def test_all_supported_is_qualified_not_truth(tmp_path):
    db=str(tmp_path/"test.sqlite3")
    result=answer_control.assess("p","Claim.",review("SUPPORTED_FOR_REVIEW"),
                                 {"mode":"REVIEWED_DIRECTIONAL_EVIDENCE_AVAILABLE"})
    assert result["decision"]=="RELEASE_QUALIFIED"
    assert result["source_separation"]["truth_verified"] is False
    answer_control.record(db,result)
    assert answer_control.history(db,"p")["items"][0]["decision"]=="RELEASE_QUALIFIED"

def test_contradiction_withholds(tmp_path):
    result=answer_control.assess("p","Claim.",review("CONTRADICTED_FOR_REVIEW"))
    assert result["decision"]=="WITHHOLD_UNSUPPORTED"

def test_mixed_evidence_requires_review():
    result=answer_control.assess("p","Claim.",review("MIXED_EVIDENCE"))
    assert result["decision"]=="REVIEW_REQUIRED"

def test_f4_indeterminate_preserved():
    result=answer_control.assess("p","Claim.",review("NO_INTERPRETABLE_EVIDENCE"))
    assert result["decision"]=="REVIEW_REQUIRED"
    assert any("F4-compatible" in x for x in result["rationale"])

def test_insufficient_evidence_requires_review():
    result=answer_control.assess("p","Claim.",review("INSUFFICIENT_EVIDENCE"))
    assert result["decision"]=="REVIEW_REQUIRED"

def test_neutral_is_not_treated_as_support():
    result=answer_control.assess("p","Claim.",review("NEUTRAL"))
    assert result["decision"]=="REVIEW_REQUIRED"

def test_missing_grounding_review_requires_review():
    result=answer_control.assess("p","Claim.",None)
    assert result["decision"]=="REVIEW_REQUIRED"

def test_policy_conflict_overrides_qualified_release():
    result=answer_control.assess("p","Claim.",review("SUPPORTED_FOR_REVIEW"),
        {"mode":"MIXED_OR_CONFLICTING_REVIEWED_EVIDENCE"})
    assert result["decision"]=="REVIEW_REQUIRED"

def test_project_scoped_append_only_history(tmp_path):
    db=str(tmp_path/"test.sqlite3")
    a=answer_control.assess("p1","A.",review("SUPPORTED_FOR_REVIEW"))
    b=answer_control.assess("p2","B.",review("CONTRADICTED_FOR_REVIEW"))
    answer_control.record(db,a); answer_control.record(db,b)
    assert len(answer_control.history(db,"p1")["items"])==1
    assert len(answer_control.history(db,"p2")["items"])==1
    with sqlite3.connect(db) as conn:
        assert conn.execute("select count(*) from answer_control_decisions").fetchone()[0]==2

def test_blank_inputs_rejected():
    import pytest
    with pytest.raises(ValueError): answer_control.assess("","A.",review("SUPPORTED_FOR_REVIEW"))
    with pytest.raises(ValueError): answer_control.assess("p","",review("SUPPORTED_FOR_REVIEW"))
