import pytest
from app.evidence_sufficiency import assess_sufficiency

def test_empty_evidence_is_no_evidence():
    out=assess_sufficiency([],{"independence_conclusion":"NOT_ESTABLISHED"})
    assert out["status"]=="NO_EVIDENCE"

def test_conflicts_block_reviewable_status():
    out=assess_sufficiency([{"id":"a"}],{"independence_conclusion":"ESTABLISHED","verified_independent_source_count":3},
                           {"conflict_count":1})
    assert out["status"]=="CONFLICTING_EVIDENCE_REQUIRES_REVIEW"

def test_unknown_independence_is_not_counted_as_sufficient():
    out=assess_sufficiency([{"id":"a"},{"id":"b"}],{"independence_conclusion":"NOT_ESTABLISHED","verified_independent_source_count":0})
    assert out["status"]=="INDEPENDENCE_NOT_ESTABLISHED"
    assert out["confidence_score"] is None
    assert out["truth_certified"] is False

def test_required_count_validation():
    with pytest.raises(ValueError): assess_sufficiency([],{},required_independent_sources=0)


def test_calibration_uses_observed_outcomes_and_does_not_train():
    from app.evidence_sufficiency import evaluate_calibration
    out=evaluate_calibration([{"probability":0.9,"outcome":1},{"probability":0.2,"outcome":0}])
    assert out["status"]=="RETROSPECTIVE_CALIBRATION_EVALUATED"
    assert out["brier_score"]==pytest.approx(0.025)
    assert out["model_parameters_updated"] is False

def test_calibration_rejects_invalid_probability():
    from app.evidence_sufficiency import evaluate_calibration
    with pytest.raises(ValueError):
        evaluate_calibration([{"probability":1.2,"outcome":1}])

def test_empty_calibration_history_is_not_a_score():
    from app.evidence_sufficiency import evaluate_calibration
    out=evaluate_calibration([])
    assert out["status"]=="NO_CALIBRATION_DATA"
    assert out["brier_score"] is None
