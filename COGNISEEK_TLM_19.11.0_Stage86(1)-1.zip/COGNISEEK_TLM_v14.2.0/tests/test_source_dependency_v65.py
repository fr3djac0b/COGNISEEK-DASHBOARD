
import pytest
from app import unified_cognitive_runtime as rt

@pytest.fixture
def db(tmp_path):
    path=str(tmp_path/"lineage.sqlite3")
    rt.initialize(path)
    return path

def make_report(db):
    return rt.submit_request(db,"p","Compare evidence",
      evidence=[{"reference":"chunk:a","summary":"A","direction":0},
                {"reference":"chunk:b","summary":"B","direction":0},
                {"reference":"chunk:c","summary":"C","direction":0}])

def declare(db,r,ref,**kwargs):
    return rt.declare_source_lineage(db,"p",r["report_id"],ref,
      declared_by="reviewer",rationale="Documented provenance review",**kwargs)

def test_unknown_lineage_is_not_independence(db):
    r=make_report(db)
    d=rt.source_dependency_diagnostics(db,"p",r["report_id"])
    assert d["diagnostics"]["independence"]=="NOT_ESTABLISHED"
    assert d["lineage_unknown_references"]==["chunk:a","chunk:b","chunk:c"]
    assert d["diagnostics"]["independent_source_count"] is None

def test_shared_declared_lineage_is_flagged(db):
    r=make_report(db)
    for ref in ("chunk:a","chunk:b"):
        declare(db,r,ref,relationship="SAME_SOURCE_REPUBLICATION",lineage_group="origin-1")
    d=rt.source_dependency_diagnostics(db,"p",r["report_id"])
    assert len(d["declared_shared_lineage_groups"])==1
    assert d["diagnostics"]["dependency_flags_present"] is True

def test_declared_derivation_is_preserved(db):
    r=make_report(db)
    declare(db,r,"chunk:b",relationship="DERIVED_FROM",derived_from=["chunk:a"])
    d=rt.source_dependency_diagnostics(db,"p",r["report_id"])
    assert d["declared_derivation_edges"][0]["derived_from"]==["chunk:a"]

def test_arbitrary_reference_rejected(db):
    r=make_report(db)
    with pytest.raises(ValueError,match="not_linked"):
        declare(db,r,"chunk:z",relationship="ORIGINAL_SOURCE")

def test_derived_from_requires_parent(db):
    r=make_report(db)
    with pytest.raises(ValueError,match="requires_parent"):
        declare(db,r,"chunk:a",relationship="DERIVED_FROM")

def test_invalid_relationship_rejected(db):
    r=make_report(db)
    with pytest.raises(ValueError,match="relationship_must"):
        declare(db,r,"chunk:a",relationship="INDEPENDENT")
