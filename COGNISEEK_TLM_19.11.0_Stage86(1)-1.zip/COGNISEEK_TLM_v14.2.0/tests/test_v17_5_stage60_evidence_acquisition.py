import tempfile, unittest, time
from pathlib import Path
from app.stage60_evidence_acquisition import EvidenceAcquisitionRegistry, E2RetrievalAdapter, EvidenceAcquisitionError

def rec(url="https://example.org/a?utm_source=x", content="Evidence text", group="publisher-a", **kw):
    d={"title":"A report","content":content,"source_uri":url,"publisher":"Publisher A",
       "source_group":group,"published_at":1700000000,"retrieved_at":1800000000}
    d.update(kw); return d

class Stage60Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.registry=EvidenceAcquisitionRegistry(Path(self.tmp.name)/"evidence.db")
    def tearDown(self): self.tmp.cleanup()
    def test_ingest_stores_provenance(self):
        x=self.registry.ingest(rec())
        self.assertEqual(x["status"],"stored")
        row=self.registry.get(x["evidence_id"])
        self.assertEqual(row["publisher"],"Publisher A")
        self.assertEqual(row["source_group"],"publisher-a")
        self.assertEqual(len(row["content_sha256"]),64)
    def test_tracking_parameters_removed(self):
        self.assertEqual(self.registry.canonicalize_uri("https://EXAMPLE.org/a?utm_source=x&b=2"),
                         "https://example.org/a?b=2")
    def test_fragment_removed(self):
        self.assertEqual(self.registry.canonicalize_uri("https://example.org/a#section"),
                         "https://example.org/a")
    def test_duplicate_canonical_url_detected(self):
        a=self.registry.ingest(rec())
        b=self.registry.ingest(rec(url="https://example.org/a?utm_campaign=other",content="Different text"))
        self.assertEqual(b["status"],"duplicate")
        self.assertEqual(a["evidence_id"],b["evidence_id"])
    def test_duplicate_content_detected_across_urls(self):
        a=self.registry.ingest(rec())
        b=self.registry.ingest(rec(url="https://other.org/copied",content="Evidence text",group="other"))
        self.assertEqual(b["status"],"duplicate")
        self.assertEqual(a["evidence_id"],b["evidence_id"])
    def test_same_content_hash_is_deterministic(self):
        a=self.registry.ingest(rec())
        self.assertEqual(a["content_sha256"],self.registry.get(a["evidence_id"])["content_sha256"])
    def test_project_isolation(self):
        a=self.registry.ingest(rec(),project="p")
        self.assertIsNone(self.registry.get(a["evidence_id"],project="q"))
    def test_reject_non_http_uri(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"source_uri_must_be_http_or_https"):
            self.registry.ingest(rec(url="file:///tmp/a"))
    def test_required_content(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"content_required"):
            self.registry.ingest({"title":"x","source_uri":"https://x.org","publisher":"x","content":" "})
    def test_timestamp_validation(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"published_at_must_be_unix_timestamp"):
            self.registry.ingest(rec(published_at="yesterday"))
    def test_metadata_mapping(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"metadata_must_be_mapping"):
            self.registry.ingest(rec(metadata="bad"))
    def test_list_project(self):
        self.registry.ingest(rec())
        self.registry.ingest(rec(url="https://example.org/b",content="Second"))
        self.assertEqual(len(self.registry.list_for_project()),2)
    def test_source_group_aggregation(self):
        a=self.registry.ingest(rec())
        b=self.registry.ingest(rec(url="https://example.org/b",content="Second",group="publisher-a"))
        groups=self.registry.source_groups([a["evidence_id"],b["evidence_id"]])
        self.assertEqual(len(groups["publisher-a"]),2)
    def test_unknown_source_group_id(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"evidence_not_found"):
            self.registry.source_groups(["missing"])
    def test_provider_required(self):
        adapter=E2RetrievalAdapter(self.registry)
        with self.assertRaisesRegex(EvidenceAcquisitionError,"search_provider_not_configured"):
            adapter.retrieve("query",e1_evidence_ids=[])
    def test_e2_retrieves_fresh_evidence(self):
        adapter=E2RetrievalAdapter(self.registry,lambda q,n:[rec(url="https://new.org/a",content="fresh")])
        out=adapter.retrieve("fresh query",e1_evidence_ids=[])
        self.assertEqual(out["stored_count"],1)
        self.assertEqual(len(out["e2_evidence_ids"]),1)
    def test_e2_marks_shared_lineage(self):
        e1=self.registry.ingest(rec())
        adapter=E2RetrievalAdapter(self.registry,lambda q,n:[rec(url="https://example.org/republished",content="Other text")])
        out=adapter.retrieve("q",e1_evidence_ids=[e1["evidence_id"]])
        self.assertEqual(len(out["same_lineage_candidates"]),1)
        self.assertEqual(out["independent_group_candidates"],[])
    def test_e2_marks_different_lineage_candidate(self):
        e1=self.registry.ingest(rec())
        adapter=E2RetrievalAdapter(self.registry,lambda q,n:[rec(url="https://new.org/a",content="Fresh",group="publisher-b")])
        out=adapter.retrieve("q",e1_evidence_ids=[e1["evidence_id"]])
        self.assertEqual(len(out["independent_group_candidates"]),1)
    def test_e2_deduplicates_against_e1(self):
        e1=self.registry.ingest(rec())
        adapter=E2RetrievalAdapter(self.registry,lambda q,n:[rec(url="https://copied.org/a",content="Evidence text",group="copy")])
        out=adapter.retrieve("q",e1_evidence_ids=[e1["evidence_id"]])
        self.assertEqual(out["duplicate_count"],1)
        self.assertEqual(out["e2_evidence_ids"],[])
    def test_e2_provider_error_is_explicit(self):
        def broken(q,n): raise RuntimeError("private detail")
        with self.assertRaisesRegex(EvidenceAcquisitionError,"provider_search_failed"):
            E2RetrievalAdapter(self.registry,broken).retrieve("q",e1_evidence_ids=[])
    def test_e2_does_not_fallback_to_e1(self):
        out=E2RetrievalAdapter(self.registry,lambda q,n:[]).retrieve("q",e1_evidence_ids=[])
        self.assertFalse(out["fallback_to_e1"])
        self.assertEqual(out["e2_evidence_ids"],[])
    def test_e2_limit_enforced(self):
        provider=lambda q,n:[rec(url=f"https://new.org/{i}",content=f"text {i}",group=f"g{i}") for i in range(5)]
        out=E2RetrievalAdapter(self.registry,provider).retrieve("q",e1_evidence_ids=[],limit=2)
        self.assertEqual(out["provider_result_count"],2)
    def test_invalid_limit(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"limit_must_be_between_1_and_100"):
            E2RetrievalAdapter(self.registry,lambda q,n:[]).retrieve("q",e1_evidence_ids=[],limit=0)
    def test_e1_refs_must_exist_before_provider(self):
        called=[]
        def provider(q,n): called.append(True); return []
        with self.assertRaisesRegex(EvidenceAcquisitionError,"e1_evidence_not_found"):
            E2RetrievalAdapter(self.registry,provider).retrieve("q",e1_evidence_ids=["missing"])
        self.assertEqual(called,[])
    def test_freshness(self):
        x=self.registry.ingest(rec(retrieved_at=1000))
        result=E2RetrievalAdapter(self.registry).freshness(x["evidence_id"],now=1100,max_age_seconds=200)
        self.assertTrue(result["fresh"])
        self.assertEqual(result["age_seconds"],100)
    def test_stale_retrieval(self):
        x=self.registry.ingest(rec(retrieved_at=1000))
        result=E2RetrievalAdapter(self.registry).freshness(x["evidence_id"],now=2000,max_age_seconds=100)
        self.assertFalse(result["fresh"])
    def test_freshness_unknown_id(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"evidence_not_found"):
            E2RetrievalAdapter(self.registry).freshness("missing")
    def test_e2_query_required(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"query_required"):
            E2RetrievalAdapter(self.registry,lambda q,n:[]).retrieve(" ",e1_evidence_ids=[])
    def test_provider_contract_rejects_none(self):
        with self.assertRaisesRegex(EvidenceAcquisitionError,"provider_returned_no_results"):
            E2RetrievalAdapter(self.registry,lambda q,n:None).retrieve("q",e1_evidence_ids=[])

if __name__=="__main__": unittest.main()
