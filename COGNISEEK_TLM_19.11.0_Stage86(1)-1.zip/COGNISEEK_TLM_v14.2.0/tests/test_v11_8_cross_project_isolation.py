"""Adversarial project-boundary tests for the v11.8.0 release."""
import json
import sqlite3

import pytest

from app import api_identity_authorization as identity_auth
from app import episode_review_completion as review
from app import identity_provider
from app import memory_lifecycle


class ProjectPrincipal:
    subject = "member-a"
    issuer = "https://issuer.example"
    audience = "cogniseek-api"
    roles = ("OPERATOR",)
    projects = ("project-a",)


def seed_integrated_run(db, project="project-a", run_id="run-a"):
    review.initialize(db)
    report_id = "report-" + project
    report = {
        "report_id": report_id,
        "episode_id": "episode-" + project,
        "evidence": {"items": [{"reference": "evidence:" + project}]},
        "retrieved_passages": [{"reference": "evidence:" + project}],
    }
    run = {
        "run_id": run_id,
        "project": project,
        "report_id": report_id,
        "episode_id": "episode-" + project,
        "current_episode_evidence": {"items": [{"evidence_id": "evidence:" + project}]},
    }
    with sqlite3.connect(db) as conn:
        conn.execute(
            "INSERT INTO cognitive_runtime_reports VALUES(?,?,?,?,?,?)",
            (report_id, project, "episode-" + project, "hash", json.dumps(report), 1.0),
        )
        conn.execute(
            "INSERT INTO integrated_request_runs VALUES(?,?,?,?,?,?,?)",
            (run_id, project, report_id, None, "DRAFT", json.dumps(run), 1.0),
        )


def test_identity_boundary_rejects_member_a_for_project_b(monkeypatch, tmp_path):
    db = str(tmp_path / "isolation.sqlite")
    monkeypatch.setattr(identity_provider, "verify_bearer_token",
                        lambda token, project: ProjectPrincipal())
    with pytest.raises(PermissionError, match="authentication_required"):
        identity_auth.authorize(db, "project-b", "signed-token",
                                ("OPERATOR",), "/sensitive")
    assert identity_auth.history(db, "project-b")["items"][0]["reason"] == "project_scope_denied"
    assert identity_auth.history(db, "project-a")["items"] == []


def test_memory_lifecycle_history_never_crosses_project_boundary(tmp_path):
    db = str(tmp_path / "memory.sqlite")
    memory_lifecycle.initialize(db)
    memory_lifecycle._record(db, "project-a", "A_EVENT", "a", "actor", None, {})
    memory_lifecycle._record(db, "project-b", "B_EVENT", "b", "actor", None, {})
    a = memory_lifecycle.history(db, "project-a")
    b = memory_lifecycle.history(db, "project-b")
    assert [x["event_type"] for x in a["items"]] == ["A_EVENT"]
    assert [x["event_type"] for x in b["items"]] == ["B_EVENT"]
    assert memory_lifecycle.history(db, "project-c")["items"] == []


def test_episode_review_cannot_resolve_foreign_project_run(tmp_path):
    db = str(tmp_path / "review.sqlite")
    seed_integrated_run(db, "project-a", "run-a")
    with pytest.raises(ValueError, match="not_found"):
        review.review_status(db, "project-b", "run-a")
    with pytest.raises(ValueError, match="not_found"):
        review.review_history(db, "project-b", "run-a")


def test_same_database_allows_each_project_to_see_only_its_own_run(tmp_path):
    db = str(tmp_path / "runs.sqlite")
    seed_integrated_run(db, "project-a", "run-a")
    seed_integrated_run(db, "project-b", "run-b")
    a = review.review_status(db, "project-a", "run-a")
    b = review.review_status(db, "project-b", "run-b")
    assert a["project"] == "project-a"
    assert b["project"] == "project-b"
    with pytest.raises(ValueError, match="not_found"):
        review.review_status(db, "project-a", "run-b")


def test_review_linkage_rejects_evidence_reference_from_other_project_run(tmp_path):
    db = str(tmp_path / "refs.sqlite")
    seed_integrated_run(db, "project-a", "run-a")
    with pytest.raises(ValueError, match="passage_reference_not_linked"):
        review.record_appraisal(
            db, "project-a", "run-a",
            reference="evidence:project-b",
            target_claim="claim", direction=1, reviewer="reviewer",
            rationale="cross-project reference probe", a_pre=2, a_post=5,
        )


def test_project_scope_is_part_of_identity_audit_query(monkeypatch, tmp_path):
    db = str(tmp_path / "audit.sqlite")
    monkeypatch.setattr(identity_provider, "verify_bearer_token",
                        lambda token, project: ProjectPrincipal())
    identity_auth.authorize(db, "project-a", "signed-token",
                            ("OPERATOR",), "/project-a")
    # History is deliberately scoped to its requested project, not a global event dump.
    assert len(identity_auth.history(db, "project-a")["items"]) == 1
    assert identity_auth.history(db, "project-b")["items"] == []
