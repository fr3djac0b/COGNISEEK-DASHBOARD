import tempfile, unittest
from pathlib import Path
from app.stage52_semantic_intelligence import SemanticIndex, SemanticIntelligenceError, cosine_similarity, evaluate_retrieval

# Deterministic test-only embedding provider; production embeddings come from a configured provider.
def fake_embed(texts):
    vocab={'cat':[1.,0.,0.],'kitten':[.98,.02,0.],'feline':[.95,.05,0.],'car':[0.,1.,0.],'vehicle':[0.,.98,.02],'engine':[0.,.95,.05],'ocean':[0.,0.,1.]}
    out=[]
    for text in texts:
        words=text.lower().split(); vec=[0.,0.,0.]
        for w in words:
            v=vocab.get(w,[.1,.1,.1]); vec=[a+b for a,b in zip(vec,v)]
        out.append(vec if any(vec) else [1.,1.,1.])
    return out

class Stage52Tests(unittest.TestCase):
    def test_cosine(self): self.assertAlmostEqual(cosine_similarity([1,0],[1,0]),1.0)
    def test_dimension_error(self):
        with self.assertRaises(SemanticIntelligenceError): cosine_similarity([1],[1,2])
    def test_persistent_add_and_search(self):
        with tempfile.TemporaryDirectory() as d:
            db=str(Path(d)/'idx.sqlite'); idx=SemanticIndex(db,fake_embed)
            a=idx.add_document(title='Cats',text='cat kitten feline',document_id='d1')
            self.assertEqual(a['chunks_indexed'],1)
            self.assertEqual(idx.semantic_search('kitten')[0]['document_id'],'d1')
            idx2=SemanticIndex(db,fake_embed)
            self.assertEqual(len(idx2.semantic_search('feline')),1)
    def test_lexical_search(self):
        with tempfile.TemporaryDirectory() as d:
            idx=SemanticIndex(str(Path(d)/'i.db'),fake_embed)
            idx.add_document(title='Engine',text='car engine vehicle',document_id='car')
            self.assertEqual(idx.lexical_search('engine')[0]['document_id'],'car')
    def test_hybrid_fuses_channels(self):
        with tempfile.TemporaryDirectory() as d:
            idx=SemanticIndex(str(Path(d)/'i.db'),fake_embed)
            idx.add_document(title='Cat',text='cat kitten',document_id='cat')
            r=idx.hybrid_search('kitten',limit=2)
            self.assertTrue(r); self.assertIn('semantic',r[0]['retrieval_channels'])
    def test_replacement_is_idempotent(self):
        with tempfile.TemporaryDirectory() as d:
            idx=SemanticIndex(str(Path(d)/'i.db'),fake_embed)
            idx.add_document(title='One',text='cat',document_id='same')
            idx.add_document(title='Two',text='car',document_id='same')
            self.assertEqual(len(idx._rows('default')),1)
            self.assertEqual(idx.semantic_search('car')[0]['title'],'Two')
    def test_evaluation_metrics(self):
        r=evaluate_retrieval([{'document_id':'a'},{'document_id':'b'}],{'b'},k=2)
        self.assertEqual(r['hits'],1); self.assertEqual(r['mrr_at_k'],.5)
    def test_invalid_embedder_count(self):
        with tempfile.TemporaryDirectory() as d:
            idx=SemanticIndex(str(Path(d)/'i.db'),lambda texts: [])
            with self.assertRaises(SemanticIntelligenceError): idx.add_document(title='x',text='y')
    def test_empty_query(self):
        with tempfile.TemporaryDirectory() as d:
            idx=SemanticIndex(str(Path(d)/'i.db'),fake_embed)
            with self.assertRaises(SemanticIntelligenceError): idx.semantic_search(' ')

if __name__=='__main__': unittest.main()
