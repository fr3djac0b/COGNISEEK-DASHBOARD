import os
import tempfile
import time
import unittest
from pathlib import Path
from app.stage82_security_hardening import RuntimeSecurity
from app.stage83_performance_scalability import BoundedWorkPool, CapacityError
from app.stage85_deployment_executor import deploy


class Stage851HardeningTests(unittest.TestCase):
    def base_env(self, path):
        return {"APP_ENV": "production", "APP_AUTH_TOKEN": "x" * 48,
                "CORS_ORIGINS": "https://example.org", "DEBUG": "false",
                "DATABASE_PATH": path}

    def test_rejects_empty_relative_and_ephemeral_paths(self):
        for path in ("", "   ", "db.sqlite", "/tmp/db.sqlite",
                     "/var/tmp/db.sqlite", "/dev/shm/db.sqlite",
                     "/run/db.sqlite", "/tmpfoo/db.sqlite",
                     "/temporary-data/db.sqlite"):
            with self.subTest(path=path):
                self.assertFalse(RuntimeSecurity(self.base_env(path)).validate()["valid"])

    def test_accepts_absolute_persistent_path(self):
        self.assertTrue(RuntimeSecurity(self.base_env("/var/data/cogniseek.sqlite3")).validate()["valid"])

    def test_timed_task_is_terminated_not_left_running(self):
        pool = BoundedWorkPool(workers=1, max_pending=0)
        try:
            started = time.monotonic()
            with self.assertRaisesRegex(CapacityError, "work_timeout_task_terminated"):
                pool.submit(time.sleep, 3, timeout=0.15)
            self.assertLess(time.monotonic() - started, 2.0)
            # Slot is returned after child termination.
            self.assertTrue(pool.try_acquire())
            pool.release()
        finally:
            pool.close()

    def test_untimed_task_still_returns_result(self):
        pool = BoundedWorkPool(workers=1, max_pending=0)
        try:
            self.assertEqual(pool.submit(pow, 2, 5), 32)
        finally:
            pool.close()

    def test_deployment_requires_explicit_opt_in(self):
        result = deploy(".", env_file="missing.env", data_dir="data", execute=False)
        self.assertFalse(result["executed"])
        self.assertEqual(result["reason"], "explicit_execute_true_required")


if __name__ == "__main__":
    unittest.main()
