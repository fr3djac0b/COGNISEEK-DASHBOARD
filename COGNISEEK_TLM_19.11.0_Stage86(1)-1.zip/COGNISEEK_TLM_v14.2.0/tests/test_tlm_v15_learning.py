import pytest
def test_directional_update_formula_and_f4(tmp_path):
    import pytest
    from app import learning
    db=str(tmp_path/"learning.sqlite3"); learning.initialize(db)
    f1=learning.create_appraisal(db,"p",2,8,1,[],"supporting evidence",True)
    assert f1["delta_a"]==6
    assert f1["update_alignment"]==6
    assert f1["response_form"]=="DIRECTIONAL_FORM_PENDING_SPECIFICATION"
    f2=learning.create_appraisal(db,"p",8,3,1,[],"appraisal moved opposite to supporting direction",True)
    assert f2["update_alignment"]==-5 and f2["response_form"]=="DIRECTIONAL_FORM_PENDING_SPECIFICATION"
    f3=learning.create_appraisal(db,"p",4,4,-1,[],"no change",True)
    assert f3["response_form"]=="DIRECTIONAL_FORM_PENDING_SPECIFICATION"
    f4=learning.create_appraisal(db,"p",5,7,0,[],"no interpretable evidence direction",False)
    assert f4["response_form"]=="F4"
    assert f4["update_alignment"] is None
    with pytest.raises(ValueError):
        learning.create_appraisal(db,"p",5,7,0,[],"incorrectly marked interpretable",True)

def test_directional_update_sign_symmetry(tmp_path):
    from app import learning
    db=str(tmp_path/"symmetry.sqlite3"); learning.initialize(db)
    positive=learning.create_appraisal(db,"p",2,7,1,[],"support",True)
    negative=learning.create_appraisal(db,"p",7,2,-1,[],"non-support",True)
    assert positive["update_alignment"]==negative["update_alignment"]==5
    assert positive["update_status"]==negative["update_status"]=="EVIDENCE_CONSISTENT_UPDATE"

def test_conflict_tracking_and_append_only_outcomes(tmp_path):
    from app import learning
    db=str(tmp_path/"conflict.sqlite3"); learning.initialize(db)
    first=learning.create_appraisal(db,"p",2,8,1,[],"first direction",True)
    second=learning.create_appraisal(db,"p",8,4,-1,[],"later direction",True,
        prior_appraisal_id=first["appraisal_id"])
    assert second["conflict_with_prior"] is True
    learning.add_outcome(db,"p",first["appraisal_id"],"inconclusive","needs more review","reviewer-a")
    assert len(learning.list_appraisals(db,"p"))==2
    assert len(learning.list_outcomes(db,"p",first["appraisal_id"]))==1

def test_learning_project_isolation_and_guardrails(tmp_path):
    import pytest
    from app import learning
    db=str(tmp_path/"isolation.sqlite3"); learning.initialize(db)
    first=learning.create_appraisal(db,"project-a",1,2,1,[],"note",True)
    with pytest.raises(ValueError):
        learning.create_appraisal(db,"project-b",2,3,-1,[],"wrong project prior",True,
            prior_appraisal_id=first["appraisal_id"])
    with pytest.raises(ValueError):
        learning.create_appraisal(db,"project-a",11,3,1,[],"out of bounds",True)
    with pytest.raises(ValueError):
        learning.create_appraisal(db,"project-a",1,2,2,[],"invalid direction",True)

def test_learning_evaluation_is_not_accuracy_claim(tmp_path):
    from app import learning
    db=str(tmp_path/"evaluation.sqlite3"); learning.initialize(db)
    app=learning.create_appraisal(db,"p",3,6,1,[],"test",True)
    summary=learning.evaluation_summary(db,"p")
    assert summary["appraisal_count"]==1
    assert summary["reviewed_appraisal_count"]==0
    learning.add_outcome(db,"p",app["appraisal_id"],"supported_after_review","reviewed","r1")
    summary=learning.evaluation_summary(db,"p")
    assert summary["coverage"]==1.0
    assert "not a model accuracy" in summary["notice"]

def test_learning_api_end_to_end(monkeypatch,tmp_path):
    from fastapi.testclient import TestClient
    import app.main as main
    from app.trace import Store
    db=str(tmp_path/"learning-api.sqlite3")
    monkeypatch.setattr(main,"DB_PATH",db)
    monkeypatch.setattr(main,"store",Store(db))
    client=TestClient(main.app)
    created=client.post("/api/learning/appraisals",json={
        "project":"api-p","a_pre":2,"a_post":8,"evidence_direction":1,
        "interpretability":True,"evidence_refs":[{"kind":"document","id":"doc-1"}],
        "rationale":"Evidence was coded as supporting after review."
    })
    assert created.status_code==200
    item=created.json()["item"]
    assert item["response_form"]=="DIRECTIONAL_FORM_PENDING_SPECIFICATION"
    f4=client.post("/api/learning/appraisals",json={
        "project":"api-p","a_pre":4,"a_post":6,"evidence_direction":0,
        "interpretability":False,"rationale":"No interpretable direction."
    })
    assert f4.status_code==200 and f4.json()["item"]["response_form"]=="F4"
    bad=client.post("/api/learning/appraisals",json={
        "project":"api-p","a_pre":4,"a_post":6,"evidence_direction":0,
        "interpretability":True
    })
    assert bad.status_code==422
    outcome=client.post("/api/learning/outcomes",json={
        "project":"api-p","appraisal_id":item["appraisal_id"],
        "outcome_type":"inconclusive","note":"Needs further evidence"
    })
    assert outcome.status_code==200
    summary=client.get("/api/learning/evaluation",params={"project":"api-p"}).json()
    assert summary["appraisal_count"]==2 and summary["reviewed_appraisal_count"]==1


@pytest.fixture(autouse=True)
def _legacy_authorization_bypass(monkeypatch, request):
    if request.function.__name__ in {'test_learning_api_end_to_end'}:
        from app import main as _main
        monkeypatch.setattr(_main, '_require_api_principal', lambda *args, **kwargs: {})
