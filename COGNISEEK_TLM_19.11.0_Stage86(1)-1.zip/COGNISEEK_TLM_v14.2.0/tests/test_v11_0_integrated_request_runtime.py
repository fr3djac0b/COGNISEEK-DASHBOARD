import json, sqlite3
import pytest
from app import integrated_request_runtime as engine

@pytest.mark.asyncio
async def test_integrated_request_creates_episode_and_keeps_memory_context_separate(tmp_path,monkeypatch):
    async def fake_submit(db,store,project,request,**kwargs):
        return {"report_id":"report-1","episode_id":"episode-1",
          "retrieved_memory_candidates":[{"episode_id":"old-1","user_input":"old context"}],
          "retrieved_passages":[{"reference":"chunk:current-1","summary":"Current passage text",
             "source_type":"document"}],
          "stages":{"source_acquisition":"NOT_REQUESTED","passage_retrieval":"COMPLETED"}}
    async def fake_generation(project,request,evidence,db,history=None):
        assert history[0]["episode_id"]=="old-1"
        assert evidence[0]["evidence_id"]=="chunk:current-1"
        return {"run_id":"generation-1","claims":[],"status":"NO_VALID_CLAIMS"}
    monkeypatch.setattr(engine.runtime_engine,"submit_research_request",fake_submit)
    monkeypatch.setattr(engine.generation_engine,"execute",fake_generation)
    db=str(tmp_path/"integrated.sqlite")
    result=await engine.execute(db,None,"p","Question?")
    assert result["status"]=="DRAFT_GENERATED_REQUIRES_REVIEW"
    assert result["historical_context"]["memory_is_current_evidence"] is False
    assert result["current_episode_evidence"]["items"][0]["direction"]=="UNAPPRAISED_INDETERMINATE"
    assert result["release"]["authorized"] is False
    assert result["controls"]["model_weights_updated"] is False
    assert engine.history(db,"p")["items"][0]["run_id"]==result["run_id"]
    assert engine.history(db,"other")["items"]==[]

@pytest.mark.asyncio
async def test_integrated_request_fails_closed_when_generation_unavailable(tmp_path,monkeypatch):
    async def fake_submit(db,store,project,request,**kwargs):
        return {"report_id":"r","episode_id":"e","retrieved_memory_candidates":[],
          "retrieved_passages":[],"stages":{"source_acquisition":"NOT_REQUESTED","passage_retrieval":"NO_MATCHES"}}
    async def fake_generation(*args,**kwargs):
        raise RuntimeError("generation_model_not_configured")
    monkeypatch.setattr(engine.runtime_engine,"submit_research_request",fake_submit)
    monkeypatch.setattr(engine.generation_engine,"execute",fake_generation)
    result=await engine.execute(str(tmp_path/"x.sqlite"),None,"p","Question")
    assert result["status"]=="EPISODE_CREATED_GENERATION_UNAVAILABLE"
    assert result["generation"] is None
    assert result["release"]["authorized"] is False

@pytest.mark.asyncio
async def test_generate_answer_false_skips_model(tmp_path,monkeypatch):
    async def fake_submit(db,store,project,request,**kwargs):
        return {"report_id":"r","episode_id":"e","retrieved_memory_candidates":[],
          "retrieved_passages":[],"stages":{"source_acquisition":"NOT_REQUESTED","passage_retrieval":"NO_MATCHES"}}
    async def should_not_run(*args,**kwargs):
        raise AssertionError("generation should be skipped")
    monkeypatch.setattr(engine.runtime_engine,"submit_research_request",fake_submit)
    monkeypatch.setattr(engine.generation_engine,"execute",should_not_run)
    result=await engine.execute(str(tmp_path/"x.sqlite"),None,"p","Question",generate_answer=False)
    assert result["status"]=="EPISODE_CREATED_GENERATION_SKIPPED"
    assert result["stages"]["answer_generation"]=="SKIPPED"

def test_project_scoped_detail(tmp_path):
    db=str(tmp_path/"integrated.sqlite")
    engine.initialize(db)
    with sqlite3.connect(db) as c:
        c.execute("INSERT INTO integrated_request_runs VALUES(?,?,?,?,?,?,?)",
          ("run","p","report",None,"TEST",json.dumps({"run_id":"run","project":"p"}),1.0))
    assert engine.get_run(db,"p","run")["run_id"]=="run"
    with pytest.raises(ValueError,match="not_found"):
        engine.get_run(db,"other","run")
