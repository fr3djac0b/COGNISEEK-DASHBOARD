import unittest
from app.stage47_evaluation_safety import (EvaluationSafetySuite, EvaluationError, GroundingCase,
    CalibrationObservation, SafetyCase, default_adversarial_catalog)

class Stage47Tests(unittest.TestCase):
    def test_01_grounding_metrics(self):
        r=EvaluationSafetySuite.grounding([GroundingCase("c1",("a","b"),("e1",),("a",),("e1","e2"))])
        self.assertEqual(r["grounded_claim_rate"],0.5); self.assertEqual(r["evidence_recall"],0.5)
    def test_02_grounding_rejects_empty(self):
        with self.assertRaisesRegex(EvaluationError,"grounding_cases_required"): EvaluationSafetySuite.grounding([])
    def test_03_supported_claim_must_exist(self):
        with self.assertRaisesRegex(EvaluationError,"supported_claim_must_exist"): GroundingCase("c",("a",),(),("b",)).validate()
    def test_04_retrieval_precision_recall(self):
        r=EvaluationSafetySuite.retrieval_precision_recall(["a","b"],["b","c"])
        self.assertEqual(r["precision"],0.5); self.assertEqual(r["recall"],0.5)
    def test_05_calibration_brier(self):
        r=EvaluationSafetySuite.calibration([CalibrationObservation(.9,True),CalibrationObservation(.2,False)],bins=2)
        self.assertAlmostEqual(r["brier_score"],0.025)
    def test_06_calibration_rejects_bad_confidence(self):
        with self.assertRaisesRegex(EvaluationError,"confidence_must_be"): EvaluationSafetySuite.calibration([CalibrationObservation(1.2,True)])
    def test_07_memory_provenance_and_unverified(self):
        r=EvaluationSafetySuite.memory_reliability([{"source":"s","recorded_at":"t","verification_status":"unverified"},{"verification_status":"verified"}])
        self.assertEqual(r["provenance_complete_rate"],0.5); self.assertEqual(r["unverified_record_count"],1)
    def test_08_safety_coverage(self):
        cases=default_adversarial_catalog(); r=EvaluationSafetySuite.safety_coverage(cases,["tool-escalation-001"])
        self.assertEqual(r["execution_coverage"],1/6); self.assertEqual(r["critical_not_executed"],1)
    def test_09_safety_rejects_unknown_ids(self):
        with self.assertRaisesRegex(EvaluationError,"unknown_executed_case_ids"): EvaluationSafetySuite.safety_coverage(default_adversarial_catalog(),["unknown"])
    def test_10_catalog_contains_critical_cases(self):
        self.assertTrue(any(x.severity=="critical" for x in default_adversarial_catalog()))
    def test_11_report_is_hashed(self):
        r=EvaluationSafetySuite.report(grounding={},retrieval={},calibration={},safety={})
        self.assertEqual(len(r["sha256"]),64); self.assertEqual(r["status"],"evaluation_summary_only")
    def test_12_safety_case_validation(self):
        with self.assertRaisesRegex(EvaluationError,"invalid_severity"): SafetyCase("x","cat","input","expected","extreme").validate()

if __name__=="__main__": unittest.main(verbosity=2)
