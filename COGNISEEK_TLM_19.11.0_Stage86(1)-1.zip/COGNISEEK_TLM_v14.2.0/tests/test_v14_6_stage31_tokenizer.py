import json
import pytest
from app.tokenizer import ByteBPETokenizer, TokenizerError, DEFAULT_SPECIAL_TOKENS

def test_round_trip_multilingual_unicode_and_whitespace():
    samples = ["Hello, world!\n", "Na gode — duniya 🌍", "مرحبا بالعالم", "你好，世界", "தமிழ் மொழி", "emoji 👩🏽‍🔬"]
    tok = ByteBPETokenizer.train(samples * 3, vocab_size=400, min_pair_frequency=2)
    for sample in samples:
        assert tok.decode(tok.encode(sample)) == sample

def test_special_tokens_and_trajectory_markers():
    tok = ByteBPETokenizer.train(["request evidence memory response"] * 4, vocab_size=320)
    text = "<|episode_start|><|current_request|>What is this?<|fresh_evidence|>New source<|historical_memory|>Old note<|model_response|>Answer<|episode_end|>"
    ids = tok.encode(text)
    assert tok.decode(ids) == text
    assert tok.special_to_id["<|fresh_evidence|>"] in ids

def test_bos_eos_and_skip_special():
    tok = ByteBPETokenizer()
    ids = tok.encode("abc", add_bos=True, add_eos=True)
    assert ids[0] == tok.special_to_id["<|bos|>"]
    assert ids[-1] == tok.special_to_id["<|eos|>"]
    assert tok.decode(ids, skip_special_tokens=True) == "abc"

def test_training_is_deterministic():
    corpus = ["banana bandana", "banana", "bandana"] * 4
    a = ByteBPETokenizer.train(corpus, vocab_size=350)
    b = ByteBPETokenizer.train(corpus, vocab_size=350)
    assert a.to_dict() == b.to_dict()

def test_save_load_and_checksum(tmp_path):
    tok = ByteBPETokenizer.train(["cogniseek trajectory model"] * 5, vocab_size=340)
    path=tmp_path/"tokenizer.json"
    tok.save(path)
    loaded=ByteBPETokenizer.load(path)
    assert loaded.to_dict() == tok.to_dict()
    data=json.loads(path.read_text())
    data["merges"][0][0]="ff"
    path.write_text(json.dumps(data))
    with pytest.raises(TokenizerError, match="checksum"):
        ByteBPETokenizer.load(path)

def test_invalid_config_and_ids():
    with pytest.raises(TokenizerError):
        ByteBPETokenizer.train(["x"], vocab_size=100)
    tok=ByteBPETokenizer()
    with pytest.raises(TokenizerError):
        tok.decode([tok.vocab_size + 10])

def test_training_input_and_limit():
    with pytest.raises(TokenizerError):
        ByteBPETokenizer.train([123])
    with pytest.raises(TokenizerError):
        ByteBPETokenizer.train(["too long"], max_corpus_bytes=2)

def test_empty_string_and_literal_unknown_text():
    tok=ByteBPETokenizer()
    assert tok.encode("") == []
    assert tok.decode(tok.encode("<|unk|>")) == "<|unk|>"
