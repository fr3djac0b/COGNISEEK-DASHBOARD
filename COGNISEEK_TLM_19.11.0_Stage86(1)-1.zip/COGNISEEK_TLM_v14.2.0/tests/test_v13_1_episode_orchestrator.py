import sqlite3
import pytest
from app.episode_orchestrator import start_episode, history

def test_each_request_creates_new_episode_and_marks_freshness(tmp_path):
    db=str(tmp_path/"episodes.db")
    a=start_episode(db,"p","hash-1",[{"fact":"old"}],True)
    b=start_episode(db,"p","hash-2",[],True)
    assert a["episode_id"]!=b["episode_id"]
    assert a["acquisition_decision"]=="FRESH_ACQUISITION_REQUIRED"
    assert len(history(db,"p"))==2

def test_historical_context_is_explicitly_context_only(tmp_path):
    db=str(tmp_path/"episodes.db")
    item=start_episode(db,"p","hash",[{"record":"historical"}],False)
    assert item["retrieval_decision"]=="RETRIEVE_RELEVANT_HISTORY_AS_CONTEXT"
    assert "not automatically treated as current evidence" in item["notice"]

def test_required_fields(tmp_path):
    with pytest.raises(ValueError): start_episode(str(tmp_path/"x.db"),"","")
