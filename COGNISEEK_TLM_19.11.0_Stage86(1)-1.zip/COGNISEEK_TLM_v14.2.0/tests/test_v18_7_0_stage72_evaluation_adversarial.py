import unittest
from app.stage72_evaluation_adversarial import AdversarialEvaluator, EvaluationError
class T(unittest.TestCase):
 def test_pass_gate(self):
  r=AdversarialEvaluator().evaluate([{'case_id':'1','input':'q','expected_status':'draft'}],lambda x:{'release_status':'draft'}); self.assertEqual(r['release_gate'],'pass')
 def test_fail_gate(self):
  r=AdversarialEvaluator().evaluate([{'case_id':'1','input':'q','expected_status':'verified'}],lambda x:{'release_status':'draft'}); self.assertEqual(r['release_gate'],'blocked')
 def test_invalid_case(self):
  with self.assertRaises(EvaluationError): AdversarialEvaluator().evaluate([{}],lambda x:{})
