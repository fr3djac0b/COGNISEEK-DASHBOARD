import json
import pytest
from app.dataset_pipeline import DatasetPipeline, DatasetError
from app.tokenizer import ByteBPETokenizer

def corpus(n=20):
    return [{"record_id":f"doc-{i}","text":f"COGNISEEK training sentence number {i}.",
             "source":f"curated-source-{i}","license_status":"user_provided",
             "metadata":{"topic":"demo"}} for i in range(n)]

def test_ingestion_validates_provenance_license_and_duplicates():
    rows=corpus(4)+[
        {"record_id":"bad","text":"hello","source":"x","license_status":"unknown"},
        {"record_id":"doc-0","text":"different","source":"x","license_status":"user_provided"},
        {"record_id":"dup-text","text":"  COGNISEEK   training sentence number 1. ","source":"x","license_status":"user_provided"}
    ]
    p=DatasetPipeline(); report=p.ingest(rows)
    assert report["accepted"]==4
    assert {x["reason"] for x in report["rejections"]}=={"license_status_not_approved","duplicate_record_id","duplicate_normalized_content"}

def test_split_is_deterministic_disjoint_and_complete():
    a=DatasetPipeline(seed=12); b=DatasetPipeline(seed=12)
    a.ingest(corpus()); b.ingest(corpus())
    sa=a.split(); sb=b.split()
    assert sa==sb
    all_ids=[x for values in sa.values() for x in values]
    assert len(all_ids)==20 and len(set(all_ids))==20
    assert all(sa[k] for k in ("train","validation","test"))

def test_split_changes_with_seed():
    a=DatasetPipeline(seed=1); b=DatasetPipeline(seed=2)
    a.ingest(corpus()); b.ingest(corpus())
    assert a.split()!=b.split()

def test_tokenizer_fits_training_split_only():
    p=DatasetPipeline(seed=3); p.ingest(corpus())
    p.split()
    tok=p.fit_tokenizer(vocab_size=300)
    assert isinstance(tok,ByteBPETokenizer)
    assert tok.vocab_size>=271

def test_encode_and_batches_produce_next_token_examples():
    p=DatasetPipeline(); p.ingest(corpus(8)); tok=p.fit_tokenizer(vocab_size=280)
    counts=p.encode(tok)
    assert counts["train"]+counts["validation"]+counts["test"]==8
    batches=list(p.batches("train",batch_size=3,max_context=4,shuffle=True,epoch=2))
    assert batches
    for batch in batches:
        assert len(batch["contexts"])<=3
        assert all(1<=len(x)<=4 for x in batch["contexts"])
        assert len(batch["contexts"])==len(batch["targets"])

def test_manifest_is_deterministic_and_hashes_source_text():
    p=DatasetPipeline(seed=4); p.ingest(corpus()); p.split()
    a=p.build_manifest(); b=p.build_manifest()
    assert a==b and len(a["manifest_sha256"])==64
    assert len(a["record_hashes"])==20

def test_jsonl_export_and_reload(tmp_path):
    p=DatasetPipeline(); p.ingest(corpus(9)); p.split()
    path=p.export_jsonl(tmp_path/"train.jsonl","train")
    q=DatasetPipeline.load_jsonl(path)
    assert len(q.records)==len(p.splits["train"])
    assert q.records[0].record_id==p.splits["train"][0].record_id

def test_jsonl_rejects_malformed_line(tmp_path):
    path=tmp_path/"bad.jsonl"; path.write_text('{"record_id":\n',encoding="utf-8")
    with pytest.raises(DatasetError,match="invalid_jsonl_line_1"):
        DatasetPipeline.load_jsonl(path)

def test_pipeline_rejects_invalid_splits_and_small_corpus():
    with pytest.raises(DatasetError): DatasetPipeline(train_ratio=.8,validation_ratio=.2,test_ratio=.2)
    p=DatasetPipeline(); p.ingest(corpus(2))
    with pytest.raises(DatasetError): p.split()

def test_pipeline_rejects_invalid_batch_arguments():
    p=DatasetPipeline(); p.ingest(corpus()); p.split()
    with pytest.raises(DatasetError): list(p.batches("train",batch_size=0))
    with pytest.raises(DatasetError): list(p.batches("unknown"))
