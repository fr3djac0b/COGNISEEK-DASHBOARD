import math
import pytest
from app.multilayer_tlm import MultiLayerGQATLM
from app.cached_inference import CachedDecoderSession, KVCache
from app.tiny_tlm import TrainingError

def model():
    return MultiLayerGQATLM(15,hidden_size=8,intermediate_size=12,
        query_heads=4,kv_heads=2,num_layers=2,max_context=5,seed=42)

def close(a,b,tol=1e-9):
    assert len(a)==len(b)
    assert all(abs(x.data-y.data)<tol for x,y in zip(a,b))

def test_cached_prefill_matches_full_forward_logits():
    m=model(); session=CachedDecoderSession(m)
    ids=[1,2,3,4]
    close(session.prefill(ids),m.logits(ids))
    assert session.cache.length==4
    assert all(len(x)==4 for x in session.cache.keys)

def test_incremental_step_matches_full_forward_each_token():
    m=model(); session=CachedDecoderSession(m)
    prefix=[1,2]
    session.prefill(prefix)
    for token in [3,4,5]:
        logits=session.step(token)
        prefix.append(token)
        close(logits,m.logits(prefix))

def test_context_overflow_rebuild_matches_sliding_full_window():
    m=model(); session=CachedDecoderSession(m)
    ids=[1,2,3,4,5]
    session.prefill(ids)
    for token in [6,7,8]:
        cached=session.step(token); ids.append(token)
        close(cached,m.logits(ids[-m.max_context:]))
        assert session.cache.length<=m.max_context

def test_cached_generation_preserves_prompt_and_count():
    m=model(); session=CachedDecoderSession(m)
    out=session.generate([1,2,3],max_new_tokens=4)
    assert out[:3]==[1,2,3] and len(out)==7
    assert session.cache.length<=m.max_context

def test_cache_reset_clears_every_layer():
    m=model(); session=CachedDecoderSession(m)
    session.prefill([1,2,3])
    session.reset()
    assert session.cache.length==0
    assert all(not rows for rows in session.cache.keys)
    assert all(not rows for rows in session.cache.values)

def test_cache_rejects_invalid_tokens_and_empty_prompt():
    m=model(); session=CachedDecoderSession(m)
    with pytest.raises(TrainingError): session.prefill([])
    with pytest.raises(TrainingError): session.step(99)
    with pytest.raises(TrainingError): session.generate([1],-1)

def test_single_token_context_window_overflow():
    m=MultiLayerGQATLM(8,hidden_size=4,intermediate_size=6,
        query_heads=2,kv_heads=1,num_layers=1,max_context=1)
    session=CachedDecoderSession(m)
    session.prefill([1])
    close(session.step(2),m.logits([2]))
    assert session.cache.token_ids==[2]
