import tempfile,unittest
from app.stage68_persistent_experience_memory import PersistentExperienceMemory, ExperienceMemoryError
class T(unittest.TestCase):
 def test_roundtrip(self):
  with tempfile.TemporaryDirectory() as d:
   m=PersistentExperienceMemory(d+'/m.db'); x=m.record(question='q',answer='a',evidence=['e'],project='p'); self.assertEqual(m.get(x['experience_id'],project='p')['evidence'],['e'])
 def test_project_isolation(self):
  with tempfile.TemporaryDirectory() as d:
   m=PersistentExperienceMemory(d+'/m.db'); x=m.record(question='q',answer='a',project='p'); self.assertIsNone(m.get(x['experience_id'],project='other'))
 def test_validation(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ExperienceMemoryError): PersistentExperienceMemory(d+'/m.db').record(question='',answer='a')
