import sqlite3
from contextlib import contextmanager
import pytest
from app import stage27_claim_grounding as s27

class Store:
    def __init__(self,path): self.path=path
    @contextmanager
    def connection(self):
        c=sqlite3.connect(self.path); c.row_factory=sqlite3.Row
        try: yield c
        finally: c.close()

def setup(tmp_path):
    db=str(tmp_path/"cog.db")
    with sqlite3.connect(db) as c:
        c.execute("""CREATE TABLE documents(document_id TEXT PRIMARY KEY,project TEXT,title TEXT,
          source_name TEXT,source_uri TEXT,publisher TEXT,author TEXT,published_at TEXT,
          source_group TEXT,method TEXT,scope TEXT,limitations TEXT)""")
        c.execute("""CREATE TABLE document_chunks(chunk_id TEXT PRIMARY KEY,document_id TEXT,
          project TEXT,chunk_index INTEGER,text TEXT)""")
        c.execute("insert into documents values(?,?,?,?,?,?,?,?,?,?,?,?)",
          ("d1","p","Report 1","Source 1","https://source.test/1","Publisher","Author","2026-01-01","g1","method","scope","limits"))
        c.execute("insert into document_chunks values(?,?,?,?,?)",("c1","d1","p",0,"Passage text supporting the claim."))
        c.execute("insert into documents values(?,?,?,?,?,?,?,?,?,?,?,?)",
          ("d2","p","Report 2","Source 2","https://source.test/2","Publisher 2","Author 2","2026-01-02","g2","method","scope","limits"))
        c.execute("insert into document_chunks values(?,?,?,?,?)",("c2","d2","p",0,"Passage text contradicting the claim."))
        c.execute("insert into documents values(?,?,?,?,?,?,?,?,?,?,?,?)",
          ("d3","other","Other project","Other","https://other.test","Other","","","","","",""))
        c.execute("insert into document_chunks values(?,?,?,?,?)",("cx","d3","other",0,"Other project passage."))
    return db,Store(db)

def test_stage27_validates_exact_claim_and_reviewer_citation(tmp_path):
    db,store=setup(tmp_path)
    from app.evidence_linking import confirm_link
    confirm_link(db,store,"p","The sample contains iron.","c1","SUPPORTS","reviewer","reviewed")
    result=s27.verify_claims(db,store,"p",[{"claim_id":"cl1","text":"The sample contains iron.","citations":["c1"]}])
    row=result["claim_ledger"][0]
    assert row["appraisal"]["status"]=="SUPPORTED_FOR_REVIEW"
    assert row["matched_evidence"][0]["passage_text"]=="Passage text supporting the claim."
    assert result["controls"]["truth_certified"] is False

def test_stage27_rejects_unlinked_and_cross_project_citations(tmp_path):
    db,store=setup(tmp_path)
    result=s27.verify_claims(db,store,"p",[{"claim_id":"cl1","text":"Claim text","citations":["cx","unknown"]}])
    assert result["claim_ledger"][0]["appraisal"]["status"]=="CITATION_INVALID_OR_INCOMPLETE"
    assert len(result["claim_ledger"][0]["matched_evidence"])==0

def test_stage27_preserves_mixed_evidence(tmp_path):
    db,store=setup(tmp_path)
    from app.evidence_linking import confirm_link
    confirm_link(db,store,"p","Door is open.","c1","SUPPORTS","r1","supports")
    confirm_link(db,store,"p","Door is open.","c2","CONTRADICTS","r2","contradicts")
    result=s27.verify_claims(db,store,"p",[{"claim_id":"door","text":"Door is open.","citations":["c1","c2"]}])
    assert result["claim_ledger"][0]["appraisal"]["status"]=="MIXED_EVIDENCE"

def test_stage27_requires_citation_token_in_draft(tmp_path):
    db,store=setup(tmp_path)
    from app.evidence_linking import confirm_link
    confirm_link(db,store,"p","Claim one.","c1","SUPPORTS","r","ok")
    claims=[{"claim_id":"c1","text":"Claim one.","citations":["c1"]}]
    bad=s27.verify_draft(db,store,"p","Claim one.",claims)
    assert bad["draft_citation_integrity"]=="FAIL"
    good=s27.verify_draft(db,store,"p","Claim one. [evidence:c1]",claims)
    assert good["draft_citation_integrity"]=="PASS"

def test_stage27_citation_must_appear_once_and_claim_ids_unique(tmp_path):
    db,store=setup(tmp_path)
    from app.evidence_linking import confirm_link
    confirm_link(db,store,"p","Claim one.","c1","SUPPORTS","r","ok")
    claims=[{"claim_id":"c1","text":"Claim one.","citations":["c1"]}]
    r=s27.verify_draft(db,store,"p","Claim one. [evidence:c1] [evidence:c1]",claims)
    assert r["draft_citation_integrity"]=="FAIL"
    with pytest.raises(ValueError):
        s27.verify_claims(db,store,"p",[{"claim_id":"x","text":"a"},{"claim_id":"x","text":"b"}])

def test_stage27_persists_project_scoped_history(tmp_path):
    db,store=setup(tmp_path)
    s27.verify_claims(db,store,"p",[{"claim_id":"x","text":"unlinked claim","citations":[]}])
    assert len(s27.history(db,"p")["items"])==1
    assert s27.history(db,"other")["items"]==[]
