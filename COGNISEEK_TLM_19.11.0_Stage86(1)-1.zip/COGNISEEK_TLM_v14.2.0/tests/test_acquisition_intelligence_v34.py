import sqlite3
from app import acquisition_intelligence as ai

class FakeStore:
    def __init__(self, rows): self.rows=rows
    def search_chunks(self, project, query, limit): return self.rows[:limit]

def test_no_passages_recommends_acquisition_and_persists(tmp_path):
    db=str(tmp_path/"a.db")
    out=ai.assess(db,FakeStore([]),"p","What causes condition X?",allowlisted_domains=[])
    assert out["action"]=="ACQUIRE_EVIDENCE"
    assert out["candidate_search_terms"]
    assert ai.history(db,"p")["items"][0]["assessment_id"]==out["assessment_id"]

def test_small_candidate_set_recommends_corroboration(tmp_path):
    db=str(tmp_path/"a.db")
    rows=[{"chunk_id":"c1","document_id":"d1","text":"some passage","source_name":"source-a"}]
    out=ai.assess(db,FakeStore(rows),"p","claim",allowlisted_domains=["example.org"])
    assert out["action"]=="SEEK_CORROBORATION"
    assert out["retrieval"]["candidate_passage_count"]==1
    assert any("independence" in x for x in out["reasons"])

def test_multiple_candidates_only_recommend_review_not_support(tmp_path):
    db=str(tmp_path/"a.db")
    rows=[{"chunk_id":f"c{i}","document_id":f"d{i}","text":"candidate","source_name":f"source-{i}","published_at":None} for i in range(3)]
    out=ai.assess(db,FakeStore(rows),"p","claim",allowlisted_domains=["a.org"])
    assert out["action"]=="REVIEW_EXISTING_EVIDENCE"
    assert "direction" in out["retrieval"]["ranking_is_not_evidence"]

def test_history_is_project_scoped_and_append_only(tmp_path):
    db=str(tmp_path/"a.db")
    store=FakeStore([])
    ai.assess(db,store,"p","claim one")
    ai.assess(db,store,"p","claim two")
    ai.assess(db,store,"other","claim three")
    assert len(ai.history(db,"p")["items"])==2
    with sqlite3.connect(db) as c:
        assert c.execute("select count(*) from acquisition_assessments").fetchone()[0]==3

def test_blank_claim_rejected(tmp_path):
    import pytest
    with pytest.raises(ValueError):
        ai.assess(str(tmp_path/"a.db"),FakeStore([]),"p"," ")
