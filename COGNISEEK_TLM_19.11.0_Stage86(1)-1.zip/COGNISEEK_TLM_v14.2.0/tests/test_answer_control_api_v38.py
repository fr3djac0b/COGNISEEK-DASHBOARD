from fastapi.testclient import TestClient
from app import main
from app.trace import Store

def test_control_api_and_history(monkeypatch, tmp_path):
    db=str(tmp_path/"control.sqlite3")
    monkeypatch.setattr(main,"DB_PATH",db)
    monkeypatch.setattr(main,"store",Store(db))
    client=TestClient(main.app)
    response=client.post("/api/answer/control",json={
        "project":"control-project","draft":"An unreviewed factual claim."
    })
    assert response.status_code==200, response.text
    payload=response.json()
    assert payload["answer_control_decision"]["decision"]=="REVIEW_REQUIRED"
    assert payload["answer_control_decision"]["source_separation"]["truth_verified"] is False
    history=client.get("/api/answer/control/history?project=control-project")
    assert history.status_code==200
    assert len(history.json()["items"])==1
