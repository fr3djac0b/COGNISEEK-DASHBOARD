import pytest
from app import learning
from app import controlled_learning as cl

def linked(db):
    cl.initialize(db)
    learning.initialize(db)
    a=learning.create_appraisal(db,"p",4,7,1,[{"id":"ev1"}],"reviewed evidence",True,"ep1")
    o=learning.add_outcome(db,"p",a["appraisal_id"],"supported_after_review","follow-up reviewed","reviewer-A")
    return a,o

def test_build_example_preserves_provenance_and_is_project_scoped(tmp_path):
    db=str(tmp_path/"db.sqlite"); a,o=linked(db)
    x=cl.build_example(db,"p","ep1",a["appraisal_id"],o["outcome_id"],"episodic",
                       "question","reviewed response","curator","follow-up outcome")
    assert x["label_state"]=="PROVISIONAL_REVIEWED_FEEDBACK"
    assert x["provenance"]["outcome_id"]==o["outcome_id"]
    assert cl.examples(db,"p")["count"]==1
    with pytest.raises(ValueError): cl.build_example(db,"other","ep1",a["appraisal_id"],o["outcome_id"],
                       "episodic","q","t","r","basis")

def test_duplicate_outcome_cannot_be_reused(tmp_path):
    db=str(tmp_path/"db.sqlite"); a,o=linked(db)
    args=(db,"p","ep1",a["appraisal_id"],o["outcome_id"],"semantic","q","t","r","basis")
    cl.build_example(*args)
    with pytest.raises(ValueError): cl.build_example(*args)

def test_experiment_passes_and_requires_explicit_approval(tmp_path):
    db=str(tmp_path/"db.sqlite"); cl.initialize(db)
    rows=[{"case_id":str(i),"baseline_probability":.6,"candidate_probability":.8,"outcome":1} for i in range(25)]
    e=cl.create_experiment(db,"p","gold","candidate-A",rows,min_samples=20)
    assert e["gate_status"]=="PASS"
    with pytest.raises(ValueError): cl.promote(db,"p",e["experiment_id"],"missing")
    r=cl.review(db,"p",e["experiment_id"],"APPROVE","reviewer","independent review")
    p=cl.promote(db,"p",e["experiment_id"],r["review_id"])
    assert p["status"]=="APPROVED_FOR_SEPARATE_IMPLEMENTATION_NOT_DEPLOYED"

def test_regression_and_small_sample_block_approval(tmp_path):
    db=str(tmp_path/"db.sqlite"); cl.initialize(db)
    rows=[{"case_id":str(i),"baseline_probability":.1,"candidate_probability":.9,"outcome":0} for i in range(4)]
    e=cl.create_experiment(db,"p","tiny","bad",rows,min_samples=5)
    assert e["gate_status"]=="INSUFFICIENT_SAMPLE"
    with pytest.raises(ValueError): cl.review(db,"p",e["experiment_id"],"APPROVE","r","because")

def test_candidate_regression_fails_gate(tmp_path):
    db=str(tmp_path/"db.sqlite"); cl.initialize(db)
    rows=[{"case_id":str(i),"baseline_probability":.1,"candidate_probability":.9,"outcome":0} for i in range(25)]
    e=cl.create_experiment(db,"p","gold","bad",rows,min_samples=20)
    assert e["gate_status"]=="FAIL_REGRESSION"

def test_invalid_duplicate_case_ids_rejected(tmp_path):
    db=str(tmp_path/"db.sqlite"); cl.initialize(db)
    rows=[{"case_id":"x","baseline_probability":.2,"candidate_probability":.3,"outcome":1}]*2
    with pytest.raises(ValueError): cl.create_experiment(db,"p","d","c",rows)

def test_review_reject_is_recorded_without_promotion(tmp_path):
    db=str(tmp_path/"db.sqlite"); cl.initialize(db)
    rows=[{"case_id":str(i),"baseline_probability":.6,"candidate_probability":.8,"outcome":1} for i in range(3)]
    e=cl.create_experiment(db,"p","d","c",rows,min_samples=2)
    r=cl.review(db,"p",e["experiment_id"],"REJECT","r","not approved")
    with pytest.raises(ValueError): cl.promote(db,"p",e["experiment_id"],r["review_id"])

def test_invalid_probability_rejected(tmp_path):
    db=str(tmp_path/"db.sqlite"); cl.initialize(db)
    rows=[{"case_id":"x","baseline_probability":1.2,"candidate_probability":.3,"outcome":1}]
    with pytest.raises(ValueError): cl.create_experiment(db,"p","d","c",rows)
