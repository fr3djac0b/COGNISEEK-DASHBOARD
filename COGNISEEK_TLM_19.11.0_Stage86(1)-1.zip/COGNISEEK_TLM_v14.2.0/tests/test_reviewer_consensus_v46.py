import sqlite3, pytest
from app import claim_verification as cv, reviewer_consensus as rc

def seed(db):
    with sqlite3.connect(db) as c:
        c.execute("CREATE TABLE documents(document_id TEXT PRIMARY KEY,project TEXT,title TEXT,source_name TEXT,source_uri TEXT)")
        c.execute("CREATE TABLE document_chunks(chunk_id TEXT PRIMARY KEY,document_id TEXT,project TEXT,chunk_index INTEGER,text TEXT)")
        c.execute("INSERT INTO documents VALUES('d','p','Doc','Source','https://example.org')")
        c.execute("INSERT INTO document_chunks VALUES('c','d','p',0,'A source passage for testing consensus.')")

def add(db,reviewer,state,candidate="c",claim="Target claim"):
    return cv.record_review(db,"p",claim,candidate,state,reviewer,"Recorded rationale.")

def test_unanimous_distinct_reviewers_create_consensus(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    add(db,"A","REVIEWED_SUPPORTS"); add(db,"B","REVIEWED_SUPPORTS")
    report=rc.build_report(db,"p","Target claim")
    assert report["status"]=="REVIEWER_CONSENSUS"
    assert report["consensus_direction"]=="SUPPORTS"
    assert report["counts"]["distinct_reviewers"]==2
    assert report["controls"]["truth_determined"] is False

def test_majority_does_not_override_minority(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    for reviewer,state in [("A","REVIEWED_SUPPORTS"),("B","REVIEWED_SUPPORTS"),("C","REVIEWED_CONTRADICTS")]:
        add(db,reviewer,state)
    report=rc.build_report(db,"p","Target claim",2)
    assert report["status"]=="UNRESOLVED_REVIEWER_DISAGREEMENT"
    assert report["consensus_direction"] is None
    assert report["counts"]["directions"]=={"SUPPORTS":2,"CONTRADICTS":1}

def test_repeated_review_by_same_person_does_not_inflate_votes(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    add(db,"A","REVIEWED_SUPPORTS"); add(db,"A","REVIEWED_SUPPORTS")
    report=rc.build_report(db,"p","Target claim")
    assert report["counts"]["review_events"]==2
    assert report["counts"]["distinct_reviewers"]==1
    assert report["status"]=="INSUFFICIENT_DIRECTIONAL_REVIEWS"

def test_same_reviewer_changed_assessment_is_visible_and_latest_used(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    add(db,"A","REVIEWED_SUPPORTS"); add(db,"A","REVIEWED_CONTRADICTS")
    add(db,"B","REVIEWED_CONTRADICTS")
    report=rc.build_report(db,"p","Target claim")
    assert report["status"]=="REVIEWER_CONSENSUS"
    assert report["consensus_direction"]=="CONTRADICTS"
    assert len(report["reviewers_with_changed_assessments"])==1
    assert len(report["preserved_review_event_ids"])==3

def test_neutral_and_indeterminate_remain_distinct(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    add(db,"A","REVIEWED_NEUTRAL"); add(db,"B","REVIEWED_INDETERMINATE")
    report=rc.build_report(db,"p","Target claim")
    assert report["status"]=="UNRESOLVED_REVIEWER_DISAGREEMENT"
    assert report["counts"]["directions"]=={"NEUTRAL":1,"INDETERMINATE":1}

def test_relevance_only_is_not_direction(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    add(db,"A","REVIEWED_RELEVANT"); add(db,"B","REVIEWED_NOT_RELEVANT")
    report=rc.build_report(db,"p","Target claim")
    assert report["status"]=="INSUFFICIENT_DIRECTIONAL_REVIEWS"
    assert report["consensus_direction"] is None

def test_report_history_is_append_only_and_project_scoped(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    add(db,"A","REVIEWED_SUPPORTS"); add(db,"B","REVIEWED_SUPPORTS")
    first=rc.build_report(db,"p","Target claim")
    second=rc.build_report(db,"p","Target claim")
    assert first["report_id"]!=second["report_id"]
    assert len(rc.history(db,"p")["items"])==2
    assert len(rc.history(db,"other")["items"])==0

def test_invalid_minimum_rejected(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    with pytest.raises(ValueError,match="min_reviewers_out_of_range"):
        rc.build_report(db,"p","Target claim",1)
