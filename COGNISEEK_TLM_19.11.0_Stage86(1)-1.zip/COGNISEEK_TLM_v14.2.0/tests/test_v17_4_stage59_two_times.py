import tempfile, unittest, sqlite3
from pathlib import Path
from app.stage59_two_times import TwoTimesEngine, TwoTimesError

class Stage59Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=Path(self.tmp.name)/'two.db'
        self.engine=TwoTimesEngine(self.db)
        self.e1=self.engine.create_e1(question='Is claim supported?',answer='Initial answer',conclusion='supported',confidence=.6,quality_score=.60,evidence_refs=['src-a','src-b'],assumptions=['source is current'],project='p')
        self.id=self.e1['episode_id']
    def tearDown(self): self.tmp.cleanup()
    def e2(self, refs=('src-c','src-d'), conclusion='supported', quality=.8):
        return self.engine.record_e2(self.id,answer='Second answer',conclusion=conclusion,confidence=.8,quality_score=quality,evidence_refs=refs,self_challenge='What evidence could disprove the initial conclusion?',project='p')
    def test_freezes_e1_and_returns_hash(self):
        self.assertTrue(self.e1['immutable']); self.assertEqual(len(self.e1['snapshot_hash']),64)
    def test_e1_database_update_blocked(self):
        with self.assertRaisesRegex(sqlite3.IntegrityError,'e1_snapshot_immutable'):
            with self.engine._db() as c: c.execute("UPDATE e1_snapshots SET answer='changed' WHERE episode_id=?",(self.id,))
    def test_e1_database_delete_blocked(self):
        with self.assertRaisesRegex(sqlite3.IntegrityError,'e1_snapshot_immutable'):
            with self.engine._db() as c: c.execute("DELETE FROM e1_snapshots WHERE episode_id=?",(self.id,))
    def test_e2_requires_e1(self):
        with self.assertRaisesRegex(TwoTimesError,'e1_episode_not_found'):
            self.engine.record_e2('missing',answer='a',conclusion='c',confidence=.5,quality_score=.5,evidence_refs=['x'],self_challenge='challenge')
    def test_e2_once_only(self):
        self.e2()
        with self.assertRaisesRegex(TwoTimesError,'e2_already_recorded'): self.e2()
    def test_e2_does_not_mutate_e1(self):
        before=self.engine.get_e1(self.id,project='p'); self.e2(); after=self.engine.get_e1(self.id,project='p')
        self.assertEqual(before,after)
    def test_overlap_and_independence_proxy(self):
        self.e2(refs=('src-b','src-c'))
        x=self.engine.compare(self.id,project='p')
        self.assertAlmostEqual(x['evidence_overlap_ratio'],1/3,places=6)
        self.assertAlmostEqual(x['evidence_independence_proxy'],2/3,places=6)
    def test_distinct_refs_not_proof_of_independence(self):
        self.e2(); self.assertIn('proxy',self.engine.compare(self.id,project='p')['independence_warning'])
    def test_quality_increment(self):
        self.e2(quality=.75); self.assertAlmostEqual(self.engine.compare(self.id,project='p')['incremental_quality_value'],.15)
    def test_no_quality_gain_is_visible(self):
        self.e2(quality=.60); self.assertFalse(self.engine.compare(self.id,project='p')['e2_improved_quality'])
    def test_agreement_is_not_proof(self):
        self.e2(); self.assertTrue(self.engine.compare(self.id,project='p')['agreement_is_not_proof'])
    def test_disagreement_preserved(self):
        self.e2(conclusion='not supported'); self.assertFalse(self.engine.compare(self.id,project='p')['conclusions_agree'])
    def test_falsification_record(self):
        r=self.engine.record_falsification(self.id,hypothesis='Could source bias explain result?',method='independent source review',result='weakened',evidence_refs=['src-z'],project='p')
        self.assertTrue(r['recorded']); self.e2(); self.assertEqual(self.engine.compare(self.id,project='p')['falsification_test_count'],1)
    def test_invalid_falsification_result(self):
        with self.assertRaisesRegex(TwoTimesError,'unsupported_falsification_result'):
            self.engine.record_falsification(self.id,hypothesis='h',method='m',result='true',project='p')
    def test_finalize_requires_both_episodes(self):
        with self.assertRaisesRegex(TwoTimesError,'e2_not_recorded'): self.engine.finalize(self.id,'retain_e1',rationale='r',project='p')
    def test_finalize_once(self):
        self.e2(); self.engine.finalize(self.id,'retain_e1',rationale='E2 did not refute E1',project='p')
        with self.assertRaisesRegex(TwoTimesError,'episode_already_finalized'): self.engine.finalize(self.id,'qualify',rationale='again',project='p')
    def test_invalid_decision(self):
        with self.assertRaisesRegex(TwoTimesError,'unsupported_final_decision'): self.engine.finalize(self.id,'auto_learn',rationale='r',project='p')
    def test_invalid_scores(self):
        with self.assertRaisesRegex(TwoTimesError,'confidence_must_be_between_0_and_1'):
            self.engine.create_e1(question='q',answer='a',conclusion='c',confidence=True,quality_score=.5,evidence_refs=['x'])
    def test_project_scope(self):
        with self.assertRaisesRegex(TwoTimesError,'e1_episode_not_found'):
            self.engine.record_e2(self.id,answer='a',conclusion='c',confidence=.5,quality_score=.5,evidence_refs=['x'],self_challenge='c',project='other')
    def test_missing_evidence_rejected(self):
        with self.assertRaisesRegex(TwoTimesError,'e2_requires_evidence_refs'):
            self.engine.record_e2(self.id,answer='a',conclusion='c',confidence=.5,quality_score=.5,evidence_refs=[],self_challenge='c',project='p')
    def test_final_decision_includes_comparison(self):
        self.e2(); result=self.engine.finalize(self.id,'qualify',rationale='Evidence remains mixed',project='p')
        self.assertEqual(result['comparison']['episode_id'],self.id)
        self.assertFalse(result['live_reasoning_enabled'])

if __name__=='__main__': unittest.main()
