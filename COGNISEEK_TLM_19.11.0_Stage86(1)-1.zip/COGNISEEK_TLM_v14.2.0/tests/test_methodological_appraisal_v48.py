import sqlite3, pytest
from app import methodological_appraisal as ma

def seed(db):
    with sqlite3.connect(db) as c:
        c.execute("CREATE TABLE documents(document_id TEXT PRIMARY KEY, project TEXT)")
        c.execute("""CREATE TABLE document_chunks(chunk_id TEXT PRIMARY KEY, document_id TEXT,
          project TEXT, chunk_index INTEGER, text TEXT)""")
        c.execute("INSERT INTO documents VALUES('d1','p')")
        c.execute("INSERT INTO document_chunks VALUES('c1','d1','p',0,'passage')")
        c.execute("INSERT INTO documents VALUES('d2','other')")
        c.execute("INSERT INTO document_chunks VALUES('c2','d2','other',0,'other passage')")

def submit(db, **kw):
    base=dict(project="p",candidate_id="c1",target_claim="Claim A",
      reviewer="reviewer-1",rationale="Reviewed the methods section.",
      study_design="Randomized controlled trial",design_description_status="DESCRIBED",
      design_fit_assessment="APPROPRIATE_REVIEWER_ASSESSED",population="Adults",
      sample_size="n=120",measurement_methods="Validated assay",
      bias_risks="Selection bias",limitations="Single site",
      replication_status="NOT_REPORTED",claim_scope_relation="DIRECTLY_ADDRESSES")
    base.update(kw)
    return ma.create_appraisal(db,**base)

def test_stores_descriptive_fields_and_reviewer_assessment_separately(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    a=submit(db)
    assert a["study_design"]=="Randomized controlled trial"
    assert a["design_description_status"]=="DESCRIBED"
    assert a["design_fit_assessment"]=="APPROPRIATE_REVIEWER_ASSESSED"
    assert a["sample_size"]=="n=120"

def test_unknown_or_cross_project_candidate_rejected(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    with pytest.raises(ValueError,match="candidate_not_found"):
        submit(db,candidate_id="c2")

@pytest.mark.parametrize("field,value,error",[
 ("replication_status","PROVEN","invalid_replication_status"),
 ("claim_scope_relation","SUPPORTS","invalid_claim_scope_relation"),
 ("design_fit_assessment","GOOD","invalid_design_fit_assessment"),
 ("design_description_status","YES","invalid_design_description_status")])
def test_invalid_categories_rejected(tmp_path,field,value,error):
    db=str(tmp_path/"db.sqlite"); seed(db)
    with pytest.raises(ValueError,match=error):
        submit(db,**{field:value})

def test_reviewer_and_rationale_required(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    with pytest.raises(ValueError,match="reviewer_identity_required"):
        submit(db,reviewer=" ")
    with pytest.raises(ValueError,match="appraisal_rationale_required"):
        submit(db,rationale=" ")

def test_claim_scope_is_not_evidence_direction_and_report_has_no_quality_score(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    submit(db,claim_scope_relation="DIRECTLY_ADDRESSES")
    report=ma.analyze(db,"p","Claim A")
    assert report["controls"]["evidence_direction_assigned"] is False
    assert report["controls"]["aggregate_quality_score"] is None
    assert report["candidates"]["c1"]["claim_scope_relations"]==["DIRECTLY_ADDRESSES"]

def test_conflicting_reviews_preserved_not_collapsed(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    submit(db,reviewer="r1",claim_scope_relation="DIRECTLY_ADDRESSES")
    submit(db,reviewer="r2",claim_scope_relation="DOES_NOT_ADDRESS")
    report=ma.analyze(db,"p","Claim A")
    candidate=report["candidates"]["c1"]
    assert candidate["reviewer_disagreement"] is True
    assert candidate["claim_scope_relations"]==["DIRECTLY_ADDRESSES","DOES_NOT_ADDRESS"]
    assert len(ma.history(db,"p","Claim A","c1"))==2

def test_latest_per_reviewer_used_for_summary_but_prior_events_retained(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    submit(db,reviewer="r1",claim_scope_relation="DIRECTLY_ADDRESSES")
    submit(db,reviewer="r1",claim_scope_relation="PARTIALLY_ADDRESSES")
    report=ma.analyze(db,"p","Claim A")
    assert report["latest_reviewer_candidate_assessment_count"]==1
    assert report["candidates"]["c1"]["claim_scope_relations"]==["PARTIALLY_ADDRESSES"]
    assert len(ma.history(db,"p","Claim A","c1"))==2

def test_repeated_analysis_reports_append_only_and_project_scoped(tmp_path):
    db=str(tmp_path/"db.sqlite"); seed(db)
    submit(db)
    ma.analyze(db,"p","Claim A")
    ma.analyze(db,"p","Claim A")
    assert len(ma.report_history(db,"p"))==2
    assert ma.history(db,"other")==[]
