import json, sqlite3, pytest
from app.trace import Store
from app import episode_evidence_verification as verification
from app import episode_corroboration_assessment as engine

def setup(db):
    Store(str(db))
    verification.initialize(str(db))
    orch={"orchestration_id":"orch1","project":"p1","cycle_id":"cy1","episode_id":"ep1","plan_id":"plan1"}
    with sqlite3.connect(db) as c:
        c.execute("INSERT INTO episode_acquisition_orchestrations VALUES(?,?,?,?,?,?,?)",
          ("orch1","p1","cy1","assess1","plan1",json.dumps(orch),1.0))
        c.execute("INSERT INTO adaptive_acquisition_runs VALUES(?,?,?,?,?,?,?)",
          ("plan1","p1","plan1","PLANNED","claim",json.dumps({"plan_id":"plan1","project":"p1","status":"PLANNED"}),1.0))
        docs=[
          ("doc1","p1","Study A","Source A","https://a.example/paper","Shared Publisher","Author A","2025","group-a","RCT","Adults","Limitations A","hash-a",1.0),
          ("doc2","p1","Study B","Source B","https://b.example/paper","Shared Publisher","Author B","2025","group-b","RCT","Adults","Limitations B","hash-b",1.0)]
        c.executemany("INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",docs)
        c.executemany("INSERT INTO document_chunks VALUES(?,?,?,?,?,?)",[
          ("chunk1","doc1","p1",0,"A sufficiently long passage describing trial results for the target claim.",1.0),
          ("chunk2","doc2","p1",0,"Another sufficiently long passage describing trial results for the target claim.",1.0)])
        c.executemany("INSERT INTO claim_candidates VALUES(?,?,?,?,?,?,?,?,?,?)",[
          ("cand1","p1","doc1","chunk1","Candidate sentence one is long enough for review.","A sufficiently long passage describing trial results for the target claim.",0,72,"CANDIDATE_REQUIRES_REVIEW",1.0),
          ("cand2","p1","doc2","chunk2","Candidate sentence two is long enough for review.","Another sufficiently long passage describing trial results for the target claim.",0,78,"CANDIDATE_REQUIRES_REVIEW",1.0), 
          ("cand3","p1","doc2","chunk2","Candidate sentence three is long enough for review.","Another sufficiently long passage describing trial results for the target claim.",0,78,"CANDIDATE_REQUIRES_REVIEW",1.0)])
    for cid,direction in [("cand1","SUPPORTS"),("cand2","CONTRADICTS")]:
        verification.create_review(str(db),"p1","orch1",cid,"Target claim","{}".format(direction),
          "reviewer","reviewed", "VALID","APPROVED")

def test_episode_linked_assessment_separates_direction_and_dependency(tmp_path):
    db=tmp_path/"v94.db"; setup(db)
    report=engine.assess(str(db),"p1","orch1","Target claim",["cand1","cand2"])
    assert report["reviewer_direction_counts"]["SUPPORTS"]==1
    assert report["reviewer_direction_counts"]["CONTRADICTS"]==1
    assert report["controls"]["no_majority_vote"] is True
    assert report["origin_assessment"]["independent_sources_established"] is False
    assert report["origin_assessment"]["shared_publisher_context"]

def test_requires_approved_valid_episode_review(tmp_path):
    db=tmp_path/"v94.db"; setup(db)
    verification.create_review(str(db),"p1","orch1","cand3","Target claim","SUPPORTS",
      "reviewer","marked stale","STALE","APPROVED")
    with pytest.raises(ValueError,match="candidate_requires_episode_linked_verification_review"):
        engine.assess(str(db),"p1","orch1","Other claim",["cand1"])
    with pytest.raises(ValueError,match="candidate_requires_approved_valid_review"):
        engine.assess(str(db),"p1","orch1","Target claim",["cand1","cand2","cand3"])

def test_project_and_orchestration_scope(tmp_path):
    db=tmp_path/"v94.db"; setup(db)
    with pytest.raises(ValueError,match="not_found_in_project"):
        engine.assess(str(db),"p2","orch1","Target claim",["cand1"])

def test_dependency_declaration_is_detected_without_certifying_independence(tmp_path):
    db=tmp_path/"v94.db"; setup(db)
    from app import evidence_dependency
    evidence_dependency.declare_relation(str(db),"p1","chunk1","chunk2","SHARES_DATASET","reviewer","Both use the same dataset")
    report=engine.assess(str(db),"p1","orch1","Target claim",["cand1","cand2"])
    assert report["origin_assessment"]["potential_shared_origin_detected"] is True
    assert report["origin_assessment"]["independent_sources_established"] is False
    assert any(x["signal"]=="DECLARED_SHARES_DATASET" for x in report["dependency_diagnostics"]["dependency_groups"])

def test_append_only_assessment_history(tmp_path):
    db=tmp_path/"v94.db"; setup(db)
    one=engine.assess(str(db),"p1","orch1","Target claim",["cand1","cand2"])
    two=engine.assess(str(db),"p1","orch1","Target claim",["cand1","cand2"])
    hist=engine.history(str(db),"p1","orch1")
    assert one["assessment_id"]!=two["assessment_id"]
    assert len(hist["items"])==2
