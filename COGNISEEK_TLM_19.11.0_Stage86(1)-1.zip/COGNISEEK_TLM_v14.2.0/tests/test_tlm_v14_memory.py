def test_temporal_memory_flags_old_episode_without_discarding(tmp_path):
    import time
    from app import episodes
    db=str(tmp_path/"memory.sqlite3"); episodes.initialize(db)
    item=episodes.create_episode(db,"p","t1","Explain cellular immunity","old answer","demo",[],"unknown",False)
    with __import__("sqlite3").connect(db) as c:
        c.execute("UPDATE episodes SET created_at=? WHERE episode_id=?",(time.time()-220*86400,item["episode_id"]))
    found=episodes.retrieve_prior(db,"p","cellular immunity",5,stale_after_days=180)
    assert found and found[0]["stale_warning"] is True
    assert found[0]["temporal_status"]=="STALE_REVIEW_REQUIRED"

def test_semantic_episode_retrieval_and_project_isolation(tmp_path):
    from app import episodes
    db=str(tmp_path/"semantic-memory.sqlite3"); episodes.initialize(db)
    a=episodes.create_episode(db,"p1","t1","Explain cellular immunity","answer","demo",[],"unknown",False)
    episodes.store_embedding(db,"p1",a["episode_id"],"mock-model",[1.0,0.0])
    found=episodes.retrieve_prior(db,"p1","unrelated phrasing",5,min_overlap=0.9,
        query_vector=[0.99,0.01],embedding_model="mock-model")
    assert found and found[0]["retrieval_method"]=="semantic"
    assert episodes.retrieve_prior(db,"p2","unrelated phrasing",5,min_overlap=0.9,
        query_vector=[0.99,0.01],embedding_model="mock-model")==[]

def test_memory_type_requires_explicit_supported_classification(tmp_path):
    import pytest
    from app import episodes
    db=str(tmp_path/"types.sqlite3"); episodes.initialize(db)
    with pytest.raises(ValueError):
        episodes.add_reviewed_memory(db,"p","automatic","content",[])
    saved=episodes.add_reviewed_memory(db,"p","semantic","Reviewed proposition",
        [{"kind":"document","id":"doc-1"}],"human-reviewed")
    assert episodes.list_reviewed_memory(db,"p")[0]["memory_id"]==saved["memory_id"]

def test_episode_comparison_is_structural_not_truth_claim(tmp_path):
    import pytest
    from app import episodes
    db=str(tmp_path/"compare.sqlite3"); episodes.initialize(db)
    item=episodes.create_episode(db,"p","t1","Old question","Old answer","demo",[],"unknown",False)
    result=episodes.compare_episodes(db,"p",item["episode_id"],"New question",[])
    assert result["comparison_status"]=="STRUCTURAL_COMPARISON_ONLY"
    with pytest.raises(ValueError):
        episodes.compare_episodes(db,"other",item["episode_id"],"New question")

def test_api_memory_audit_and_reviewed_items(monkeypatch,tmp_path):
    from app import main as _main; monkeypatch.setattr(_main, '_require_api_principal', lambda *args, **kwargs: {})
    from fastapi.testclient import TestClient
    import app.main as main
    from app.trace import Store
    db=str(tmp_path/"api-v14.sqlite3")
    monkeypatch.setattr(main,"DB_PATH",db); monkeypatch.setattr(main,"store",Store(db))
    async def fake_answer(message,history,evidence): return "fresh answer"
    monkeypatch.setattr(main.model_client,"answer",fake_answer)
    client=TestClient(main.app)
    first=client.post("/api/chat",json={"project":"p","message":"Explain cellular immunity"}).json()
    second=client.post("/api/chat",json={"project":"p","message":"Explain cellular immunity again"}).json()
    assert second["memory_audit"]["retrieved_count"] >= 1
    saved=client.post("/api/memory/items",json={"project":"p","memory_type":"procedural",
        "content":"Reviewed workflow","provenance":[{"kind":"manual","id":"m1"}]})
    assert saved.status_code==200
    assert len(client.get("/api/memory/items",params={"project":"p"}).json()["items"])==1
    comparison=client.post("/api/episodes/compare",json={"project":"p",
        "prior_episode_id":first["episode"]["episode_id"],"current_text":"new observation"})
    assert comparison.status_code==200
    assert comparison.json()["comparison_status"]=="STRUCTURAL_COMPARISON_ONLY"
