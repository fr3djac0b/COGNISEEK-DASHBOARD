import tempfile, unittest
from pathlib import Path
from app.stage60_evidence_acquisition import EvidenceAcquisitionRegistry
from app.stage61_evidence_verification import EvidenceVerificationEngine, EvidenceVerificationError
from app.stage62_evidence_synthesis import EvidenceSynthesisEngine, EvidenceSynthesisError

class Stage62Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); p=Path(self.tmp.name)
        self.registry=EvidenceAcquisitionRegistry(p/"e.db")
        self.verify=EvidenceVerificationEngine(self.registry,p/"v.db",min_independent_groups=2,min_supporting_groups=2)
        self.synth=EvidenceSynthesisEngine(self.verify,p/"s.db")
        self.claim=self.verify.register_claim("Treatment reduces risk",project="p")["claim_id"]
    def tearDown(self): self.tmp.cleanup()
    def add(self,name,direction,group=None):
        group=group or name
        ev=self.registry.ingest({"title":name,"content":f"content {name}","source_uri":f"https://{name}.example/report",
            "publisher":name,"source_group":group,"published_at":1700000000,"retrieved_at":1800000000},project="p")
        eid=ev["evidence_id"]
        self.verify.review_source(eid,project="p",source_class="primary",identity_status="verified",
            author_known=True,methodology_present=True,conflicts_disclosed=True)
        self.verify.link_evidence(self.claim,eid,direction=direction,rationale="Finding relevant to claim",
            extractor="human",project="p")
        return eid
    def pair(self):
        return self.add("support","supports"),self.add("contradict","contradicts")
    def test_synthesis_preserves_both_sides(self):
        a,b=self.pair(); r=self.synth.synthesize(self.claim,project="p",save=False)
        self.assertEqual(len(r["supporting_evidence"]),1)
        self.assertEqual(len(r["contradicting_evidence"]),1)
        self.assertEqual(r["synthesis_status"],"contested_unresolved")
    def test_unreviewed_conflict_is_visible(self):
        self.pair()
        r=self.synth.synthesize(self.claim,project="p",save=False)
        self.assertEqual(r["unresolved_conflict_count"],1)
        self.assertEqual(r["contradiction_pairs"][0]["review_status"],"unreviewed")
    def test_review_explained_context(self):
        a,b=self.pair()
        out=self.synth.review_contradiction(self.claim,a,b,conflict_type="population",
            decision="explained_by_context",explanation="The studies examined different populations.",
            reviewer="reviewer-1",project="p")
        self.assertTrue(out["human_review_recorded"])
        r=self.synth.synthesize(self.claim,project="p",save=False)
        self.assertEqual(r["synthesis_status"],"contextualized_for_human_review")
        self.assertEqual(r["contextualized_conflict_count"],1)
    def test_remains_conflict(self):
        a,b=self.pair()
        self.synth.review_contradiction(self.claim,a,b,conflict_type="methodology",
            decision="remains_conflict",explanation="Methods remain incompatible.",
            reviewer="reviewer",project="p")
        self.assertEqual(self.synth.synthesize(self.claim,project="p",save=False)["synthesis_status"],"contested_unresolved")
    def test_request_more_evidence_keeps_conflict_open(self):
        a,b=self.pair()
        self.synth.review_contradiction(self.claim,a,b,conflict_type="provenance",
            decision="request_more_evidence",explanation="Need original study.",
            reviewer="reviewer",project="p")
        self.assertEqual(self.synth.synthesize(self.claim,project="p",save=False)["unresolved_conflict_count"],1)
    def test_not_true_conflict_recorded(self):
        a,b=self.pair()
        self.synth.review_contradiction(self.claim,a,b,conflict_type="timeframe",
            decision="not_a_true_conflict",explanation="They refer to separate periods.",
            reviewer="reviewer",project="p")
        r=self.synth.synthesize(self.claim,project="p",save=False)
        self.assertEqual(r["not_a_true_conflict_count"],1)
        self.assertEqual(r["synthesis_status"],"contextualized_for_human_review")
    def test_conflict_type_validation(self):
        a,b=self.pair()
        with self.assertRaisesRegex(EvidenceSynthesisError,"unsupported_conflict_type"):
            self.synth.review_contradiction(self.claim,a,b,conflict_type="fake",
                decision="remains_conflict",explanation="x",reviewer="r",project="p")
    def test_decision_validation(self):
        a,b=self.pair()
        with self.assertRaisesRegex(EvidenceSynthesisError,"unsupported_review_decision"):
            self.synth.review_contradiction(self.claim,a,b,conflict_type="scope",
                decision="auto_resolve",explanation="x",reviewer="r",project="p")
    def test_reviewer_required(self):
        a,b=self.pair()
        with self.assertRaisesRegex(EvidenceSynthesisError,"reviewer_required"):
            self.synth.review_contradiction(self.claim,a,b,conflict_type="scope",
                decision="remains_conflict",explanation="x",reviewer=" ",project="p")
    def test_explanation_required(self):
        a,b=self.pair()
        with self.assertRaisesRegex(EvidenceSynthesisError,"explanation_required"):
            self.synth.review_contradiction(self.claim,a,b,conflict_type="scope",
                decision="remains_conflict",explanation=" ",reviewer="r",project="p")
    def test_same_evidence_pair_rejected(self):
        a=self.add("support","supports")
        with self.assertRaisesRegex(EvidenceSynthesisError,"contradiction_requires_two_distinct_evidence_items"):
            self.synth.review_contradiction(self.claim,a,a,conflict_type="scope",
                decision="remains_conflict",explanation="x",reviewer="r",project="p")
    def test_pair_must_be_linked_to_claim(self):
        a,b=self.pair()
        with self.assertRaisesRegex(EvidenceSynthesisError,"claim_not_found"):
            self.synth.review_contradiction("missing",a,b,conflict_type="scope",
                decision="remains_conflict",explanation="x",reviewer="r",project="p")
    def test_duplicate_pair_review_rejected(self):
        a,b=self.pair()
        args=dict(conflict_type="scope",decision="remains_conflict",explanation="x",reviewer="r",project="p")
        self.synth.review_contradiction(self.claim,a,b,**args)
        with self.assertRaisesRegex(EvidenceSynthesisError,"contradiction_pair_already_reviewed"):
            self.synth.review_contradiction(self.claim,b,a,**args)
    def test_save_and_retrieve_snapshot(self):
        self.pair(); r=self.synth.synthesize(self.claim,project="p")
        saved=self.synth.get_synthesis(r["synthesis_id"],project="p")
        self.assertEqual(saved["content_hash"],r["content_hash"])
        self.assertEqual(saved["claim_id"],self.claim)
    def test_unknown_snapshot(self):
        self.assertIsNone(self.synth.get_synthesis("missing",project="p"))
    def test_indeterminate_claim(self):
        empty=self.verify.register_claim("No evidence",project="p")["claim_id"]
        r=self.synth.synthesize(empty,project="p",save=False)
        self.assertEqual(r["synthesis_status"],"indeterminate")
    def test_support_only_not_enough_evidence(self):
        self.add("one","supports")
        r=self.synth.synthesize(self.claim,project="p",save=False)
        self.assertEqual(r["synthesis_status"],"insufficient_evidence")
    def test_sufficient_support_ready_for_review(self):
        self.add("one","supports"); self.add("two","supports")
        r=self.synth.synthesize(self.claim,project="p",save=False)
        self.assertEqual(r["synthesis_status"],"evidence_ready_for_human_review")
    def test_neutral_evidence_preserved(self):
        self.add("neutral","neutral")
        r=self.synth.synthesize(self.claim,project="p",save=False)
        self.assertEqual(len(r["neutral_evidence"]),1)
    def test_project_scope_enforced(self):
        a,b=self.pair()
        with self.assertRaisesRegex(EvidenceVerificationError,"claim_not_found"):
            self.synth.synthesize(self.claim,project="other")
    def test_no_automatic_truth_verdict(self):
        self.pair()
        r=self.synth.synthesize(self.claim,project="p",save=False)
        self.assertFalse(r["automatic_truth_verdict"])
        self.assertTrue(r["human_review_required"])

if __name__=="__main__": unittest.main()
