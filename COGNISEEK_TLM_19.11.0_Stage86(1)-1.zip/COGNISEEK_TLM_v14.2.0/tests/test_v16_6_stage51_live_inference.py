import json
import tempfile
import unittest
from pathlib import Path

from app.checkpoint_manager import CheckpointManager
from app.multilayer_tlm import MultiLayerGQATLM
from app.stage51_live_inference import (
    InferenceConfig, LiveInferenceError, LiveInferenceRuntime,
)
from app.tokenizer import ByteBPETokenizer


class Stage51LiveInferenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.directory = Path(self.tmp.name)
        self.tokenizer = ByteBPETokenizer()
        self.model = MultiLayerGQATLM(
            vocab_size=self.tokenizer.vocab_size,
            hidden_size=4, intermediate_size=8, query_heads=2,
            kv_heads=1, num_layers=1, max_context=24, seed=19,
        )
        self.tokenizer_path = self.directory / "tokenizer.json"
        self.tokenizer.save(self.tokenizer_path)
        self.checkpoint_path = CheckpointManager(self.directory).save(
            "tiny-test-model", self.model, tag="test-fixture"
        )

    def tearDown(self):
        self.tmp.cleanup()

    def test_load_artifacts_and_generate(self):
        runtime = LiveInferenceRuntime.from_artifacts(
            self.checkpoint_path, self.tokenizer_path,
            InferenceConfig(max_new_tokens=3),
        )
        result = runtime.generate("hello", max_new_tokens=3)
        self.assertEqual(result["generated_tokens"], 3)
        self.assertEqual(len(result["token_ids"]), 3)
        self.assertEqual(result["decoding"], "greedy")

    def test_zero_token_generation(self):
        runtime = LiveInferenceRuntime.from_artifacts(
            self.checkpoint_path, self.tokenizer_path
        )
        self.assertEqual(runtime.generate("hello", 0)["generated_tokens"], 0)

    def test_missing_checkpoint_is_clear_error(self):
        with self.assertRaisesRegex(LiveInferenceError, "trained_checkpoint_not_found"):
            LiveInferenceRuntime.from_artifacts(
                self.directory / "missing.json", self.tokenizer_path
            )

    def test_missing_tokenizer_is_clear_error(self):
        with self.assertRaisesRegex(LiveInferenceError, "tokenizer_artifact_not_found"):
            LiveInferenceRuntime.from_artifacts(
                self.checkpoint_path, self.directory / "missing-tokenizer.json"
            )

    def test_empty_prompt_rejected(self):
        runtime = LiveInferenceRuntime.from_artifacts(
            self.checkpoint_path, self.tokenizer_path
        )
        with self.assertRaisesRegex(LiveInferenceError, "prompt_must_be_nonempty_text"):
            runtime.generate("  ")

    def test_invalid_generation_limit_rejected(self):
        runtime = LiveInferenceRuntime.from_artifacts(
            self.checkpoint_path, self.tokenizer_path
        )
        with self.assertRaisesRegex(LiveInferenceError, "max_new_tokens_must_be_nonnegative_integer"):
            runtime.generate("hello", True)

    def test_tokenizer_model_vocab_mismatch_rejected(self):
        other = ByteBPETokenizer.train(["different corpus"], vocab_size=272, min_pair_frequency=1)
        with self.assertRaisesRegex(LiveInferenceError, "tokenizer_model_vocabulary_mismatch"):
            LiveInferenceRuntime(self.model, other)

    def test_corrupt_tokenizer_rejected(self):
        bad = self.directory / "bad-tokenizer.json"
        bad.write_text(json.dumps({"format": "wrong"}), encoding="utf-8")
        with self.assertRaisesRegex(LiveInferenceError, "inference_artifact_load_failed"):
            LiveInferenceRuntime.from_artifacts(self.checkpoint_path, bad)

    def test_corrupt_checkpoint_rejected(self):
        bad = self.directory / "bad.checkpoint.json"
        bad.write_text('{"format":"wrong"}', encoding="utf-8")
        with self.assertRaisesRegex(LiveInferenceError, "inference_artifact_load_failed"):
            LiveInferenceRuntime.from_artifacts(bad, self.tokenizer_path)

    def test_prompt_truncation_respects_model_context(self):
        runtime = LiveInferenceRuntime.from_artifacts(
            self.checkpoint_path, self.tokenizer_path,
            InferenceConfig(max_new_tokens=1),
        )
        result = runtime.generate("x" * 100, 1)
        self.assertEqual(result["generated_tokens"], 1)


if __name__ == "__main__":
    unittest.main()
