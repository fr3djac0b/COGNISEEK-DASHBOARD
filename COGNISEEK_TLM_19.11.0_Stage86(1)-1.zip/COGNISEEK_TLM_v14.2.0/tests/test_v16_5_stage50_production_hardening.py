import unittest
from app.stage50_production_hardening import (
 HardeningError, validate_request_id, redact_sensitive_text, security_headers,
 InMemoryRateLimiter, HashChainAudit, safe_error_payload, readiness_summary,
)
class Stage50Tests(unittest.TestCase):
 def test_01_valid_request_id(self): self.assertEqual(validate_request_id("req-12345678"),"req-12345678")
 def test_02_reject_request_id_log_injection(self):
  with self.assertRaises(HardeningError): validate_request_id("abc\nforged")
 def test_03_redacts_credentials(self):
  s=redact_sensitive_text("api_key=secret123 Authorization Bearer abc.def")
  self.assertNotIn("secret123",s); self.assertNotIn("abc.def",s)
 def test_04_security_headers_default(self):
  h=security_headers(); self.assertEqual(h["X-Content-Type-Options"],"nosniff"); self.assertIn("Strict-Transport-Security",h)
 def test_05_security_headers_reject_invalid_frame_policy(self):
  with self.assertRaises(HardeningError): security_headers(frame_policy="ALLOW")
 def test_06_rate_limiter_allows_limit(self):
  now=[0.0]; r=InMemoryRateLimiter(limit=2,window_seconds=10,clock=lambda:now[0])
  self.assertTrue(r.check("client").allowed); self.assertTrue(r.check("client").allowed)
 def test_07_rate_limiter_blocks_excess(self):
  now=[0.0]; r=InMemoryRateLimiter(limit=1,window_seconds=10,clock=lambda:now[0])
  r.check("client"); d=r.check("client"); self.assertFalse(d.allowed); self.assertEqual(d.retry_after_seconds,10)
 def test_08_rate_limiter_expires_window(self):
  now=[0.0]; r=InMemoryRateLimiter(limit=1,window_seconds=10,clock=lambda:now[0]); r.check("client"); now[0]=11
  self.assertTrue(r.check("client").allowed)
 def test_09_audit_chain_verifies(self):
  a=HashChainAudit(); a.append("user.query","req-12345678",{"topic":"test"},timestamp=1); a.append("answer.saved","req-12345678",timestamp=2)
  self.assertTrue(a.verify()); self.assertEqual(len(a.records()),2)
 def test_10_audit_redacts_secret(self):
  a=HashChainAudit(); r=a.append("auth.checked","req-12345678",{"api_key":"secret"},timestamp=1)
  self.assertNotIn("secret",str(r.details)); self.assertTrue(a.verify())
 def test_11_safe_error_hides_internal_text(self):
  p=safe_error_payload("database_unavailable","req-12345678"); self.assertNotIn("traceback",str(p)); self.assertEqual(p["request_id"],"req-12345678")
 def test_12_readiness_reports_failed_checks(self):
  r=readiness_summary(config_valid=True,storage_ready=False,model_ready=True,dependencies_ready=True,secrets_configured=True)
  self.assertFalse(r["ready"]); self.assertEqual(r["failed_checks"],["storage"])
if __name__=="__main__": unittest.main(verbosity=2)
