import sqlite3
import pytest
from app import structured_findings as sf

def seed(db):
    with sqlite3.connect(db) as c:
        c.execute("""CREATE TABLE documents(document_id TEXT PRIMARY KEY,project TEXT,title TEXT,
          source_name TEXT,source_uri TEXT,publisher TEXT,author TEXT,published_at TEXT,
          source_group TEXT,method TEXT,scope TEXT,limitations TEXT,content_hash TEXT)""")
        c.execute("""CREATE TABLE document_chunks(chunk_id TEXT PRIMARY KEY,document_id TEXT,
          project TEXT,chunk_index INTEGER,text TEXT)""")
        c.execute("INSERT INTO documents VALUES('d1','p','Trial','J','u','P','A','2025','g','RCT','adults','limits','h')")
        passage="In adults, intervention reduced risk (RR 0.80, 95% CI 0.65 to 0.98) at 12 months."
        c.execute("INSERT INTO document_chunks VALUES('c1','d1','p',0,?)",(passage,))
        c.execute("INSERT INTO documents VALUES('d2','q','Other','J','u','P','A','2025','g','RCT','adults','limits','h2')")
        c.execute("INSERT INTO document_chunks VALUES('cq','d2','q',0,'Other passage')")

def candidate(db):
    passage="In adults, intervention reduced risk (RR 0.80, 95% CI 0.65 to 0.98) at 12 months."
    start=0; end=len(passage)
    return sf.create_candidate(db,"p","c1",{
      "intervention":"intervention","comparator":"usual care","outcome":"risk",
      "effect_measure":"RR","effect_estimate":0.80,"ci_lower":0.65,"ci_upper":0.98,
      "population":"adults","follow_up_period":"12 months"} ,passage,start,end)

def test_candidate_is_exact_passage_bound_and_unreviewed(tmp_path):
    db=str(tmp_path/"db"); seed(db)
    x=candidate(db)
    assert x["candidate_status"]=="CANDIDATE_REQUIRES_REVIEW"
    assert x["chunk_id"]=="c1" and x["document_id"]=="d1"

def test_cross_project_passage_rejected(tmp_path):
    db=str(tmp_path/"db"); seed(db)
    with pytest.raises(ValueError,match="passage_not_found"):
        sf.create_candidate(db,"p","cq",{"outcome":"x"},"Other passage",0,13)

def test_excerpt_mismatch_rejected(tmp_path):
    db=str(tmp_path/"db"); seed(db)
    with pytest.raises(ValueError,match="excerpt_offsets"):
        sf.create_candidate(db,"p","c1",{"outcome":"x"},"wrong",0,5)

@pytest.mark.parametrize("fields",[
 {"effect_measure":"RR","effect_estimate":0},
 {"p_value":1.2},{"sample_size":0},{"events":11,"denominator":10},
 {"ci_lower":2,"ci_upper":1},{"effect_estimate":2,"ci_lower":3,"ci_upper":4},
 {"effect_measure":"OR","ci_lower":-1}
])
def test_invalid_numeric_values_rejected(tmp_path,fields):
    db=str(tmp_path/"db"); seed(db)
    with pytest.raises(ValueError): sf.create_candidate(db,"p","c1",fields,"In adults",0,10)

def test_unknown_fields_rejected(tmp_path):
    db=str(tmp_path/"db"); seed(db)
    with pytest.raises(ValueError,match="unsupported_fields"):
        sf.create_candidate(db,"p","c1",{"truth_score":0.9},"In adults",0,10)

def test_reviews_append_and_candidates_not_compared_until_approved(tmp_path):
    db=str(tmp_path/"db"); seed(db); x=candidate(db); fid=x["finding_id"]
    before=sf.compare(db,"p",[fid])
    assert before["approved_finding_count"]==0
    sf.review_candidate(db,"p",fid,"reviewer-a","APPROVE","Checked against passage")
    after=sf.compare(db,"p",[fid])
    assert after["approved_finding_count"]==1
    assert after["comparison_strata"][0]["stratum"]["effect_measure"]=="RR"
    assert len(sf.list_reviews(db,"p")["items"])==1

def test_conflicting_latest_reviewer_actions_remain_unresolved(tmp_path):
    db=str(tmp_path/"db"); seed(db); fid=candidate(db)["finding_id"]
    sf.review_candidate(db,"p",fid,"r1","APPROVE","reviewed")
    sf.review_candidate(db,"p",fid,"r2","REJECT","not supported")
    result=sf.compare(db,"p",[fid])
    assert result["approved_finding_count"]==0
    assert result["items"][0]["review_status"]=="REVIEWER_DISAGREEMENT_OR_CORRECTION"

def test_correction_does_not_overwrite_candidate_or_review_history(tmp_path):
    db=str(tmp_path/"db"); seed(db); x=candidate(db); fid=x["finding_id"]
    corrected={"outcome":"risk","effect_measure":"RR","effect_estimate":0.82}
    sf.review_candidate(db,"p",fid,"r1","CORRECT","transcription correction",corrected)
    assert sf.get_candidate(db,"p",fid)["fields"]["effect_estimate"]==0.80
    assert len(sf.list_reviews(db,"p")["items"])==1
    assert sf.compare(db,"p",[fid])["items"][0]["fields"]["effect_estimate"]==0.82

def test_incompatible_metrics_remain_separate(tmp_path):
    db=str(tmp_path/"db"); seed(db)
    x=candidate(db); fid=x["finding_id"]
    sf.review_candidate(db,"p",fid,"r1","APPROVE","reviewed")
    # second finding uses same passage but a different effect measure, still same source identity
    passage="In adults, intervention reduced risk (RR 0.80, 95% CI 0.65 to 0.98) at 12 months."
    y=sf.create_candidate(db,"p","c1",{"outcome":"risk","effect_measure":"OR",
      "effect_estimate":0.7,"ci_lower":0.5,"ci_upper":0.9},passage,0,len(passage))
    sf.review_candidate(db,"p",y["finding_id"],"r1","APPROVE","reviewed")
    result=sf.compare(db,"p",[fid,y["finding_id"]])
    assert len(result["comparison_strata"])==2
    assert result["controls"]["pooled_effect_calculated"] is False
