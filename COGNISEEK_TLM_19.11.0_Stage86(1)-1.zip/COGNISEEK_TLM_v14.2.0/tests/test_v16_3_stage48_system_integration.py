import tempfile, unittest
from pathlib import Path
from app.rag_external_knowledge import KnowledgeBase, KnowledgeDocument
from app.stage45_persistent_experience_memory import PersistentExperienceMemory
from app.stage46_reasoning_tool_integration import ToolCall, ToolSpec
from app.stage48_system_integration import CogniseekSystem, SystemIntegrationError

class Stage48Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.kb=KnowledgeBase(chunk_chars=180,overlap_chars=20)
        self.kb.ingest([KnowledgeDocument(
            document_id="doc-1", text="The test system supports fresh evidence retrieval and preserves contradictory claims. "*3,
            source="local-test-corpus", source_type="test", observed_at="2026-10-31T00:00:00+00:00",
            license_status="user_provided", reliability=.9)])
        self.memory=PersistentExperienceMemory(Path(self.tmp.name)/"memory.sqlite")
        self.system=CogniseekSystem(knowledge_base=self.kb,memory=self.memory,top_k=3)
    def tearDown(self): self.tmp.cleanup()
    def test_01_fresh_evidence_package(self):
        p=self.system.begin_episode("fresh evidence retrieval")
        self.assertTrue(p.evidence); self.assertEqual(p.status,"evidence_collected")
    def test_02_retrieval_repeats_for_each_episode(self):
        a=self.system.begin_episode("fresh evidence")
        b=self.system.begin_episode("fresh evidence",request_id="episode-two")
        self.assertNotEqual(a.request_id,b.request_id); self.assertTrue(b.evidence)
    def test_03_memory_is_separate_from_evidence(self):
        p=self.system.begin_episode("fresh evidence")
        self.assertIsInstance(p.evidence,tuple); self.assertIsInstance(p.memories,tuple)
    def test_04_complete_episode_persists_answer(self):
        p=self.system.begin_episode("fresh evidence",request_id="persist-1")
        digest=self.system.complete_episode(p.request_id,"Reviewed answer",outcome="helpful")
        self.assertEqual(len(digest),64)
        found=self.memory.retrieve("fresh evidence",top_k=2)
        self.assertTrue(any(x.episode.episode_id=="persist-1" for x in found))
    def test_05_cannot_complete_unknown_episode(self):
        with self.assertRaisesRegex(SystemIntegrationError,"pending_episode_not_found"):
            self.system.complete_episode("missing","answer")
    def test_06_requires_answer_before_persisting(self):
        p=self.system.begin_episode("fresh evidence",request_id="blank-answer")
        with self.assertRaisesRegex(SystemIntegrationError,"answer_required"):
            self.system.complete_episode(p.request_id," ")
    def test_07_tool_approval_gate_is_preserved(self):
        self.system.tools.register(ToolSpec(name="safe_action",description="test action",handler=lambda a:{"ok":True},required_args=("value",),allowed_args=("value",),requires_approval=True))
        p=self.system.begin_episode("fresh evidence",tool_calls=[ToolCall(tool_name="safe_action",arguments={"value":1},approved=False)])
        self.assertEqual(p.tool_results[0]["status"],"approval_required")
        self.assertEqual(p.status,"needs_review")
    def test_08_audit_record_is_hashed(self):
        p=self.system.begin_episode("fresh evidence")
        self.assertEqual(len(self.system.audit_record(p)["audit_sha256"]),64)
    def test_09_evaluation_delegates_to_stage47(self):
        r=self.system.evaluate(retrieved_ids=["a","b"],relevant_ids=["b"])
        self.assertEqual(r["retrieval"]["precision"],.5)
        self.assertEqual(r["status"],"evaluation_summary_only")
    def test_10_invalid_top_k_rejected(self):
        with self.assertRaisesRegex(SystemIntegrationError,"top_k_must_be_positive_integer"):
            CogniseekSystem(knowledge_base=self.kb,memory=self.memory,top_k=0)
    def test_11_duplicate_episode_is_not_silently_overwritten(self):
        p=self.system.begin_episode("fresh evidence",request_id="duplicate-1")
        self.system.complete_episode(p.request_id,"first answer")
        p2=self.system.begin_episode("fresh evidence",request_id="duplicate-1")
        with self.assertRaises(Exception): self.system.complete_episode(p2.request_id,"second answer")
    def test_12_fresh_question_validated(self):
        with self.assertRaises(Exception): self.system.begin_episode(" ")

if __name__=="__main__": unittest.main(verbosity=2)
