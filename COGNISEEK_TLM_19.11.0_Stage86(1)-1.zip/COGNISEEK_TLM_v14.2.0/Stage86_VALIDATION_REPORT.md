# COGNISEEK 19.11.0 — Stage86 validation

Full unittest discovery exit code: 0
Python compileall exit code: 0
ZIP integrity: PASS
Docker available: False
Docker deployment performed: NO
Live service deployment: NOT VERIFIED

## Test output
```text
ale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaad710>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaad110>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaad310>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaad410>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaadb10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaad510>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaad610>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaad810>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaadf10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaad910>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaada10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaadc10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f0a8a10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f0a8b10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f0a8c10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f0e5310>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f0e5910>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f0e5a10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f0e5c10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f0e5f10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f103110>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f103410>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f103610>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f103710>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f103e10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f103f10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc21f11c010>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fcaade10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fe089f10>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fdf35110>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/functional.py:2567: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7fc1fdf35310>
  return torch.embedding(weight, input, padding_idx, scale_grad_by_freq, sparse)
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/usr/lib/python3.13/multiprocessing/popen_fork.py:67: DeprecationWarning: This process (pid=1210) is multi-threaded, use of fork() may lead to deadlocks in the child.
  self.pid = os.fork()
----------------------------------------------------------------------
Ran 396 tests in 6.173s

OK

```

## Scope and limitations
Adds a local-only Transformers inference adapter, model manifest SHA-256 verification, and fake-backend tests. No pretrained weights are included; no real model or GPU was run. This is an inference integration foundation, not a trained or production-capable independent model.

Passing tests establish only the behaviours covered by the suite. They do not
prove production readiness or independent operation.
