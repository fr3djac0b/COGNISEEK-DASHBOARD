# COGNISEEK TLM v5.4.0
## Evidence Synthesis Intelligence

Built on v5.3.0. Integrates reviewer-approved structured findings, study-level statistical profiles, pairwise comparability screens and available methodological appraisal records.

### Capabilities
- Produces a project-scoped, append-only synthesis report from selected finding IDs.
- Includes only findings with unanimous latest reviewer approval in statistical study profiles.
- Preserves excluded/disputed finding IDs and their review states.
- Integrates effect profiles and comparability status counts without pooling estimates.
- Joins methodological appraisal records by the structured finding's source passage (`chunk_id`).
- Explicitly identifies missing methodological appraisals.
- Flags findings from the same source document.
- Optionally accepts prior statistical and comparability report IDs, validating that their finding scope matches the requested finding set.
- Runs a fresh comparability screen at synthesis time to reflect current reviewer state.

### Endpoints
- `POST /api/evidence-synthesis/intelligence`
- `GET /api/evidence-synthesis/intelligence/reports`
- `GET /api/evidence-synthesis/intelligence/reports/{report_id}`

### Explicit limitations
- Descriptive integration only; no pooled effect, meta-analysis, overall quality score, winner selection, or automated truth/causality determination.
- Methodological appraisal is included only when present in the existing appraisal ledger; it is not inferred.
- A comparability match does not establish exchangeability or eligibility for pooling.
- No automatic generation of natural-language scientific conclusions; this release produces structured synthesis reports.
- Reviewer identities remain supplied strings in this prototype.

See `TEST_RESULTS_v5.4.0.txt`.
