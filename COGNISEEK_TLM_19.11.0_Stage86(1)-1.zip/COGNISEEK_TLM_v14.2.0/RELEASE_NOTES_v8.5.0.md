# COGNISEEK TLM v8.5.0 — Adaptive Verification and Experience Correction

## Purpose
Record verification events for historical experiences and allow a separate reviewer to accept, reject, or defer a proposed correction.

## Workflow
1. Submit a verification event against a currently consolidated experience.
2. Directional outcomes require evidence references.
3. Record verifier identity metadata and rationale.
4. A separate reviewer decision is required: `APPLY_CORRECTION`, `REJECT`, or `DEFER`.
5. Only the latest correction review controls the reuse guidance.
6. An accepted correction lowers that experience's future selection priority and labels it `REVIEW_CORRECTED_EXPERIENCE_BEFORE_REUSE`.

## API
- `POST /api/cognitive-runtime/learning/experience-verifications`
- `POST /api/cognitive-runtime/learning/experience-corrections/review`
- `GET /api/cognitive-runtime/learning/experience-verifications?project=default&candidate_id=...`

Verification outcomes:
- `SUPPORTS_HISTORICAL_EXPECTATION`
- `CONTRADICTS_HISTORICAL_EXPECTATION`
- `INCONCLUSIVE`
- `NOT_VERIFIED`

Review decisions:
- `APPLY_CORRECTION`
- `REJECT`
- `DEFER`

## Safeguards
- Verification events and review decisions are append-only.
- Original experience is never overwritten or deleted.
- A verification event alone does not change retrieval priority.
- Only an explicit latest `APPLY_CORRECTION` reviewer decision changes future reuse guidance.
- Caller-reported evidence references and verifier labels are not independently authenticated.
- Correction is a governance signal, not an automatic truth label or model-weight update.
- Current evidence remains separate and must be independently qualified.

## Validation
See `TEST_RESULTS_v8.5.0.txt`.
