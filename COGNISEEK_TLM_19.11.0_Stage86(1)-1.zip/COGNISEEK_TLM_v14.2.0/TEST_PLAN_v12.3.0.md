# Test Plan — v12.3.0

1. Verify episode and learning reads reject missing authentication.
2. Verify project members can read their own project records.
3. Verify cross-project reads and writes fail closed.
4. Verify Operator can append episode outcomes and learning appraisals.
5. Verify Operator cannot perform reviewer-only episode reconciliation or
   learning outcome review.
6. Verify policy manifest and route governance inventory include all newly
   protected method/path entries.
7. Run full regression on a clean default database.
8. Run compileall and FastAPI import.
9. Compare M-RBAM source hash against v12.2.0.
