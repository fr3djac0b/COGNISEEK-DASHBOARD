# COGNISEEK TLM v8.0.0 — Unified Experience Learning Integration

## What changed
- Reviewed v7.9 execution feedback can be staged as a contextual experience candidate.
- Staging is permitted only when the latest feedback review is `ACCEPT_AS_EXPERIENCE`.
- A second, explicit candidate review is required before retrieval: `CONSOLIDATE`, `REJECT`, or `DEFER`.
- Only candidates whose latest candidate review is `CONSOLIDATE` are returned by contextual experience retrieval.
- Project isolation, append-only review history, source event provenance, and duplicate staging protection are implemented.

## New endpoints
- `POST /api/cognitive-runtime/learning/experience-candidates`
- `POST /api/cognitive-runtime/learning/experience-candidates/review`
- `GET /api/cognitive-runtime/learning/experiences?project=default&query=...&limit=20`
- `GET /api/cognitive-runtime/learning/experience-candidates?project=default&limit=100`

## Learning boundary
Retrieved experiences are historical context only. They are not current evidence, truth labels, source authentication, or model training examples. No model weights are updated. Retrieval uses simple lexical matching, not semantic or calibrated relevance ranking. Reviewer identity fields remain audit metadata and are not authentication.

## Verification
- Full regression suite: 533 passed, 0 failed.
- New v8.0 tests: 9 passed.
- Python compilation: passed.
- ZIP integrity: passed.
- No live external acquisition or model training was performed.
