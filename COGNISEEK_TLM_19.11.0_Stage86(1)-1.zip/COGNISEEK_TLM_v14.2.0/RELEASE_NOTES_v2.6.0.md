# COGNISEEK TLM v2.6.0 — Controlled External Evidence Acquisition

## New capability

This release adds an explicit, controlled URL acquisition layer. A user can submit URLs to fetch; the server retrieves supported public text pages from exact hostnames configured by the operator.

### New API

- `GET /api/acquisition/status` — reports whether the feature is enabled, exact allowlisted hostnames, response size cap, supported content types, and redirect policy.
- `POST /api/acquisition/fetch` — fetches up to 10 user-submitted HTTPS URLs, extracts readable text, stores it as project-scoped document material, and records an acquisition audit event.
- `GET /api/acquisition/history` — lists append-only acquisition events for a project.

### Configuration

Set the server environment variable:

`COGNISEEK_FETCH_ALLOWED_DOMAINS=example.org,another.example`

Entries must be exact hostnames. Wildcards are not supported. An empty setting disables external acquisition. Keep this setting server-side.

### Guardrails

- HTTPS only; no URL credentials; port 443 only.
- Exact hostname allowlist; IP-literal hosts rejected.
- DNS results are checked for public IP addresses before fetching.
- Redirects are not followed.
- Response body is capped at 1 MB.
- Only `text/html`, `application/xhtml+xml`, and `text/plain` are accepted.
- Scripts, styles, SVG, forms, iframes and noscript content are excluded from HTML text extraction.
- Failed attempts are also recorded in the acquisition audit.
- Retrieved content is ingested as unverified document material and becomes searchable by the existing retrieval/lifecycle engine.
- Exact content duplicates are not re-ingested as a second document.

## New data model

`acquisitions` stores the requested URL, final URL, hostname, retrieval timestamp, HTTP status, content type, SHA-256 hash, byte count, extracted character count, outcome, error code, associated document ID, and extraction metadata.

## Verification

- Automated tests: **126 passed, 0 failed**.
- Python compilation: PASS.
- ZIP integrity: PASS.

Tests mock network retrieval; no live external source fetch was performed.

## Limitations and security notes

- This is user-directed URL retrieval, not general web search or autonomous discovery.
- The acquisition record proves only that a response was retrieved from an allowlisted host; it does not authenticate the publisher or validate claims.
- Publication dates, authors and publisher identity are not independently verified.
- The implementation checks DNS results before request, but does not pin the validated IP to the HTTP connection; DNS rebinding protection is therefore not complete. Deploy only with trusted, operator-controlled allowlists and network egress controls.
- Redirects are rejected rather than followed.
- PDF, DOCX, JavaScript-rendered pages, paywalled content, login pages and arbitrary binary formats are not supported.
- No automatic model-weight updates occur.
- The app still lacks authentication and per-user authorization; do not expose this prototype publicly without security hardening.
