# COGNISEEK TLM v7.1.0 — Evidence-to-Answer Integration

## Added
- `POST /api/cognitive-runtime/evidence-to-answer`: one-call orchestration from a new episode through an existing integrated evidence workflow and governed response release.
- `GET /api/cognitive-runtime/evidence-to-answer`: project-scoped history of episode/workflow/release links.
- Append-only `cognitive_evidence_answer_links` ledger.
- Links preserve episode ID, runtime report ID, workflow ID, release ID, finding IDs, workflow status, and release decision.

## Execution
1. Create a new episode from the request.
2. Run the existing integrated evidence-intelligence workflow over supplied finding IDs.
3. Evaluate company output policy through the existing governed release function.
4. Persist a link across the episode, evidence workflow, and release.
5. Return the evidence workflow, release decision, and overall release status.

## Important boundaries
- This endpoint uses existing finding records. It does not acquire or discover external sources in this call.
- The separate controlled acquisition and finding-ingestion workflows remain the upstream path for obtaining evidence.
- Policy BLOCK returns no output.
- Optional model rendering is only a rewrite of the approved deterministic workflow response; it is not an evidence source.
- Caller actor/role fields are not authentication.
- The integrated workflow's completion does not establish scientific truth, source authenticity, causality, or model accuracy.
- A failure before the release/link stage can leave the already-created episode or workflow in history; these stages are append-only and are not a distributed transaction.
- This is an orchestration prototype, not a trained foundation model.

## Validation
- Full regression: 470 passed, 0 failed.
- New v7.1 tests: 8 passed (included in full regression).
- Python compileall: PASS.
- ZIP integrity: PASS.
- Isolated temporary SQLite database used; production/user database not modified.
- No live external acquisition performed.
