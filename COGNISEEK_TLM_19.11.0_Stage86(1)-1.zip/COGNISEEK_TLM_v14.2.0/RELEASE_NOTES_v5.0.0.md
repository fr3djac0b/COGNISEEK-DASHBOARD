# COGNISEEK TLM v5.0.0 — Evidence-Grounded Synthesis and Answer Generation

## Purpose
Connects the v4.9 cross-study comparison report to an answer-rendering layer. The new layer produces a deterministic, provenance-linked narrative from stored study metadata and reviewer-entered records, then sends the target claim through the existing advisory grounding and answer-control workflow.

## New capabilities
- Render an existing project-scoped cross-study report into a readable study-by-study synthesis.
- Include candidate/document identifiers, source metadata, reviewer-coded directions, methodological scope, study design, population, sample size, measurement methods, replication status, and disagreements when available.
- Explicitly report missing evidence reviews and missing methodological appraisals without treating absence as contradiction.
- Preserve source candidate references in a structured provenance array.
- Ground the target claim against the existing exact-text reviewer-coded evidence ledger.
- Attach the existing advisory answer-control decision and append-only decision record.
- Store answer renderings in project-scoped history.

## API
- `POST /api/synthesis/answer`
- `GET /api/synthesis/answer/history`

## Important design boundary
This release is deterministic report rendering, not free-form LLM generation. It does not paraphrase study findings because the stored review records do not contain a validated structured effect/result field. It summarizes the available review classifications and methodological records, and it explicitly identifies missing fields.

The target claim is checked using existing exact claim-text grounding. That is not semantic entailment and does not validate every explanatory sentence in the rendered report. The answer-control decision is advisory, not a publication lock.

## Guardrails
- No automatic evidence direction inference.
- No truth determination or numeric truth probability.
- No pooled effect estimate or meta-analysis.
- No source-independence certification.
- No unqualified answer release.
- Reviewer classifications are not ground truth.
- No model training, weight update, live search/fetch, or deployment.

## Compatibility
Built by copying the v4.9.0 source bundle. Previous release ZIP is preserved unchanged.
