# COGNISEEK TLM v10.6.0 — External Knowledge Acquisition and Source Verification

## Scope
Builds on v10.5.0's trusted identity boundary and extends the existing controlled acquisition/discovery workflow with a persistent source-provenance assessment ledger.

## Implemented
- Reuses the existing HTTPS allowlisted acquisition and search-candidate workflows.
- Adds `POST /api/sources/verify` to assess a project-scoped acquisition record.
- Adds `GET /api/sources/verification-history` and `GET /api/sources/verification-status`.
- Records retrieval status, final/requested URL, domain, content hash, content type, byte count, extracted text length, and operator domain-registry match.
- Supports exact domain registry configuration through `COGNISEEK_TRUSTED_SOURCE_DOMAINS`.
- Keeps assessments append-only and project-scoped.
- Explicitly separates transport/provenance checks from publisher authentication, publication-date verification, source independence, claim direction and claim truth.

## Important interpretation
A domain appearing in the operator-maintained trusted-domain registry is only a local policy signal. It is not proof that the publisher is authentic, that an author/date is correct, that sources are independent, or that any claim is true. All retrieved material remains subject to evidence qualification and claim-level review.

## API
- `POST /api/sources/verify` — body: `{"project":"default","acquisition_id":"..."}`
- `GET /api/sources/verification-history?project=default`
- `GET /api/sources/verification-status`

## Configuration
`COGNISEEK_TRUSTED_SOURCE_DOMAINS=domain1.example,domain2.example` (exact domains only; no wildcard semantics).

## Limitations
No live external search/acquisition provider credentials or live internet fetch were supplied during this build. The release does not certify publisher identity, publication date, source independence, or semantic truth. Existing search and acquisition remain allowlist-controlled; discovery results remain candidates.
