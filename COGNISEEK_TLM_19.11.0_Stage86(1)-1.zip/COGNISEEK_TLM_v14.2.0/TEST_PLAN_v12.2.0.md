# Test Plan — COGNISEEK TLM v12.2.0

1. Confirm no-token requests to protected evidence and memory reads fail closed.
2. Confirm a signed project member with VIEWER can read.
3. Confirm VIEWER cannot write evidence.
4. Confirm an OPERATOR can write reviewed memory.
5. Confirm a token scoped to project-a cannot read or write project-b.
6. Confirm read and write role policies remain distinct and centrally registered.
7. Rebuild route governance and semantic review reports.
8. Run full regression with a fresh isolated database.
9. Run compileall and FastAPI import.
10. Verify M-RBAM source is byte-for-byte unchanged from v12.1.0.
