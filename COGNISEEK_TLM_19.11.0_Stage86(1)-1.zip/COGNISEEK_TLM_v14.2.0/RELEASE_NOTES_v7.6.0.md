# COGNISEEK TLM v7.6.0 — Memory–Evidence Reconciliation

## What changed
- Added explicit reconciliation between retrieved historical memory and current evidence metadata.
- Compares only matching evidence references where both historical and current directions were explicitly recorded.
- Reports directional concordance, discordance, or no valid directional comparison.
- Surfaces stale-memory and prior-correction/rejection warnings.
- Preserves D=0 as indeterminate/F4; no directional update is calculated.
- Adds append-only reconciliation history and project-scoped API routes.

## API
- `POST /api/cognitive-runtime/memory/reconcile`
- `GET /api/cognitive-runtime/memory/reconciliations?project=default&limit=100`

## Request example
```json
{
  "project": "default",
  "retrieval_run_id": "REPLACE_WITH_A_REAL_RETRIEVAL_RUN_ID",
  "episode_id": "OPTIONAL_EPISODE_ID",
  "current_evidence": [
    {"evidence_ref": "EVIDENCE-001", "direction": -1}
  ]
}
```

Directions: `+1` supporting, `-1` contradicting, `0` no interpretable direction. Direction is never inferred from memory prose.

## Boundaries
- Historical memory is not current evidence.
- A discrepancy is a review signal, not a truth decision.
- Current evidence has priority for the current answer.
- No automatic memory promotion, answer overwrite, or model-weight update.
- The API does not authenticate actor identity; deployment authorization remains a separate requirement.

## Validation
- Full regression: 501 passed, 0 failed (isolated database).
- Python compileall: passed.
- Live external acquisition: not performed.
