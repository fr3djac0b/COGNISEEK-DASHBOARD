# v11.6.0 Test Plan

1. Test guarded and unguarded endpoint source detection.
2. Test conservative risk classification for mutating endpoints.
3. Confirm optional global API-key middleware is not counted as project RBAC.
4. Generate inventory against the actual FastAPI application.
5. Run Python compile checks and FastAPI import.
6. Run the full regression suite with a fresh isolated SQLite database.
7. Verify M-RBAM source is byte-for-byte unchanged from v11.5.0.
8. Verify ZIP archive integrity.
