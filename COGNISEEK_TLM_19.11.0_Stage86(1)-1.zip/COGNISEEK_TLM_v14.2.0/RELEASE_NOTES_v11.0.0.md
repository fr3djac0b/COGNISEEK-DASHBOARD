# COGNISEEK TLM v11.0.0 — Integrated Cognitive Runtime

## Added
- `app/integrated_request_runtime.py` composes the existing episode runtime, historical episode retrieval, explicit URL acquisition, passage retrieval, v10.8 structured generation, semantic review, and append-only lifecycle records.
- API:
  - `POST /api/cognitive-runtime/integrated-requests`
  - `GET /api/cognitive-runtime/integrated-requests`
  - `GET /api/cognitive-runtime/integrated-requests/{run_id}`
- Every request creates a fresh episode. Prior episodes are passed to generation only as historical context.
- Retrieved current passages remain unappraised/indeterminate until reviewer appraisal.
- Generation failure does not erase the episode; it is recorded as unavailable.
- The endpoint never authorizes release. Existing evidence workflow, identity and company-policy release controls remain separate and are not bypassed.

## Boundaries
- This is an orchestration integration over existing modules, not a new foundation model or neural training milestone.
- External acquisition occurs only for URLs explicitly supplied in the request and remains subject to the existing acquisition allowlist.
- Semantic reviews are provisional model interpretations, not factual truth.
- Caller-supplied actor is not authenticated identity.
- No automatic memory promotion, model-weight update, operational action, or answer release occurs.
