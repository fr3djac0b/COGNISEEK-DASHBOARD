# COGNISEEK TLM v9.5.0
## Reviewer-Defined Claim Coverage and Episode-Linked Evidence Sufficiency

### Added
- A new coverage assessment bound to a specific project, acquisition orchestration, v9.4 corroboration assessment and target claim.
- Explicit reviewer-defined claim aspects, each with a stable aspect ID and description.
- Reviewer-entered coverage states: `COVERED`, `PARTIALLY_COVERED`, `NOT_COVERED`, `INDETERMINATE`.
- Explicit mapping from covered aspects to candidate IDs already present in the linked v9.4 assessment.
- Preservation of the v9.4 direction summary, including simultaneous supporting and contradicting records.
- Append-only coverage assessment snapshots and history API.

### API
- `POST /api/cognitive-runtime/claim-coverage-assessments`
- `GET /api/cognitive-runtime/claim-coverage-assessments?project=default&orchestration_id=...&target_claim=...&limit=100`

### Guardrails
- Aspect decomposition and coverage labels are supplied by a reviewer; the engine does not invent claim dimensions.
- `COVERED` and `PARTIALLY_COVERED` require at least one linked evidence candidate.
- `NOT_COVERED` cannot list evidence as if it covered the aspect.
- Candidate IDs must exist in the exact linked corroboration assessment.
- Coverage ratios describe reviewer-labelled aspects only. They are not truth probabilities or automatic sufficiency certificates.
- No majority vote, conflict resolution, source-independence certification, answer release or execution authorization occurs.

### Limitation
This is a structured reviewer coverage ledger, not an automated semantic entailment engine. It does not decide whether the claim decomposition is complete or whether a passage genuinely entails an aspect. Those judgments remain reviewer responsibilities.
