# Test Plan — COGNISEEK TLM v12.1.0

1. Verify scoped route-family filtering.
2. Verify method/path and handler extraction.
3. Verify that a project parameter is not treated as authorization.
4. Verify that a payload endpoint remains blocked for ownership review.
5. Verify explicit authorization-helper detection.
6. Verify duplicate method/path declaration detection.
7. Regenerate the source review JSON from `app/main.py`.
8. Run the full regression suite, compileall, FastAPI import, and ZIP integrity checks.
9. Verify `app/research/m_rbam.py` is byte-for-byte unchanged from v12.0.0.
