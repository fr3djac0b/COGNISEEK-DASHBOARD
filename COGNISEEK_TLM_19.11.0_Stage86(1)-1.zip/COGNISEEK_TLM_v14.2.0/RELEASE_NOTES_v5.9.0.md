# COGNISEEK TLM v5.9.0 — Company Policy and Output Governance

## Scope
Final planned v5.x milestone. Adds project-scoped company policy lifecycle and
policy-based release decisions for outputs associated with v5.8 integrated workflows.

## Added
- Append-only, project-scoped policy revisions with SHA-256 policy hashes.
- Restrictive built-in baseline for the `default` project.
- Draft → approval → activation lifecycle.
- Separation of duties: author cannot approve; author and approver cannot activate.
- Policy settings for reviewer count, unanimous latest approval, allowed output modes,
  unreviewed/disputed findings, governance audit, validation PASS, limitations,
  provenance, and optional-stage warnings.
- Release decision engine: ALLOW, ALLOW_WITH_WARNING, BLOCK.
- Rechecks latest reviewer actions at release time.
- Append-only output decision history, including policy revision/hash and workflow refs.
- Eight API routes under `/api/company-governance/`.

## Safety and limitations
- Policy controls output permission, not scientific validity.
- A policy cannot override failed validation or promote unsupported evidence.
- `actor` and `role` are caller-supplied prototype claims, not authenticated identities.
- Production deployment requires real authentication/authorization, signed approvals,
  secure key management, and independent tamper-evident audit storage.
- Release decisions do not constitute scientific truth, clinical advice, or model training.

## Validation
- Full regression suite: 369 passed, 0 failed.
- Python compileall: passed.
- Isolated validation database: `/tmp/cogniseek_tlm_v59_validation.sqlite3`.
- No production database was used or modified.
