# v11.0.0 Test Plan

1. Fresh episode orchestration with separate historical memory and current evidence.
2. Verify current retrieved passages remain unappraised/indeterminate.
3. Verify model-unavailable state retains the created episode and withholds output.
4. Verify optional generation skip.
5. Verify project-scoped run history and detail access.
6. Full inherited regression with isolated database.
7. Compileall, FastAPI import/route check, and ZIP integrity.
