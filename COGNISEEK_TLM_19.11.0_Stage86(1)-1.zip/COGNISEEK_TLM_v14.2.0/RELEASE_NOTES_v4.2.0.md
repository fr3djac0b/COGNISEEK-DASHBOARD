# COGNISEEK TLM v4.2.0
## Cross-Episode Learning and Provenance-Aware Relationship Graph

### Added
- `app/knowledge_graph.py`: project-scoped typed nodes and provenance-bearing directed edges.
- Relationship types: `related_to`, `supports_context`, `contradicts_context`, `corrects`,
  `supersedes`, `derived_from`, `repeats`, `mentions`.
- Provenance classes: `CALLER_DECLARED`, `REVIEWER_CONFIRMED`, `MACHINE_SUGGESTED`.
- Append-only edge decision events: `CONFIRM` and `WITHDRAW`.
- Bounded graph traversal and graph/event history APIs.
- FastAPI integration and health/version update to 4.2.0.

### Safety and interpretation
- Node registration is not verification of the external record.
- A relationship is not a factual claim, entailment judgement, source-independence proof,
  or truth determination.
- Machine-suggested edges remain explicitly labelled and are not auto-promoted.
- Withdrawals supersede active state while preserving history.
- Cross-project graph operations are isolated.
- Graph cycles are allowed; traversal is bounded to four hops.

### Validation
- Automated tests cover provenance, idempotent node registration, project isolation,
  invalid endpoints, edge withdrawal/reconfirmation, history preservation and cycles.
- No live external acquisition, model training, weight updates, or deployment.
