# COGNISEEK TLM v18.3.0

Stage 68: Persistent Experience Memory. Additive release from immutable v17.8.0 baseline.

Adds SQLite-backed append-only episode experience records, project isolation and integrity digests. It does not modify model weights.
