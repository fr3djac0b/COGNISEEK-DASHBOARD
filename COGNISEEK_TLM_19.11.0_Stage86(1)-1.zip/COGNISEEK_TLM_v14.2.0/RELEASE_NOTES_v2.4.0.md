# COGNISEEK TLM v2.4.0

## Cross-Episode Evidence Reconciliation

- Added `app/episode_reconciliation.py`.
- Added `POST /api/episodes/reconcile`.
- Added `GET /api/episodes/reconciliations`.
- Compares two stored episodes within the same project.
- Compares exact evidence-reference identifiers and reports shared, prior-only, and current-only references.
- Surfaces episode uncertainty/conflict flags and recorded correction/rejection outcomes.
- Supports optional attributed reviewer assessments: `CONFIRMS_PRIOR`, `CONTRADICTS_PRIOR`, `REFINES_PRIOR`, `UNRESOLVED`.
- Stores append-only reconciliation snapshots.
- Preserves original episode records and outcomes.

## Boundaries

- Structural comparison does not establish factual agreement or contradiction.
- Different evidence IDs do not prove independent sources.
- Shared evidence IDs do not prove evidential agreement.
- Reviewer assessment is not automatically treated as ground truth.
- No model weights updated; no automatic episode rewrite.
