# COGNISEEK TLM v6.6.0 — Evidence Quality and Methodological Reliability

## Purpose
Adds a reviewer-recorded methodological appraisal layer to the unified cognitive runtime. It records what is known about a study's design and conduct without converting missing information into a favourable or unfavourable judgement.

## Added
- Append-only `cognitive_method_appraisals` table.
- Reviewer appraisal API: `POST /api/cognitive-runtime/methodological-appraisals`.
- Retrieval API: `GET /api/cognitive-runtime/reports/{report_id}/methodological-appraisals`.
- Diagnostic API: `GET /api/cognitive-runtime/reports/{report_id}/methodological-diagnostics`.
- Structured study fields: design, sample size, population, setting, outcome definition, measurement method, missing data, funding/conflicts, and limitations.
- Risk-of-bias domains: selection, performance, detection/measurement, attrition, confounding, selective reporting, and other.
- Ratings: LOW, SOME_CONCERNS, HIGH, UNCLEAR, NOT_REPORTED.
- Multiple reviewer records are retained; differing bias-domain appraisals are surfaced as disagreements.

## Guardrails
- Missing fields remain missing; they are not treated as low risk or low quality.
- `NOT_REPORTED` is distinct from `LOW`.
- No automatic overall quality grade or certainty-of-evidence grade is calculated.
- Risk of bias and certainty of evidence remain separate concepts.
- Only evidence references linked to the selected report can be appraised.
- Reviewer identity and judgement are caller-supplied; this prototype does not authenticate reviewer credentials.
- Appraisals are not independently verified and do not establish truth, sufficiency, consensus, or permission to release an answer.
- Appraisals are append-only; corrections are new records, not silent overwrites.

## Validation
- Full regression suite: 411 passed.
- Python compileall: run as part of packaging.
- Isolated SQLite test database used; no production database modified.
- No live external acquisition was performed by this test run.
