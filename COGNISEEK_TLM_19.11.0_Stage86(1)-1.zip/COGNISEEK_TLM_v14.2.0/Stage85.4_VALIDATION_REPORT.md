# COGNISEEK 19.10.4 — Stage85.4 validation

Full unittest discovery exit code: 0
Python compileall exit code: 0
ZIP integrity: PASS
Docker available: False
Docker deployment performed: NO
Live service deployment: NOT VERIFIED

## Test output
```text
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f99078ed710>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f99078ed810>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f99078eda10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881010>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f99078edb10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f99078edc10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f99078ede10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881510>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f99078edf10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881110>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881210>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881910>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881310>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881410>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881610>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9929ecd510>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9929ecd610>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9929ecd710>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9929ecde10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cd410>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cd510>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cd710>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cda10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cdc10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cdf10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cf110>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cf210>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cf910>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cfa10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f992a1cfb10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881810>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881a10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881c10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f9908881e10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/usr/lib/python3.13/multiprocessing/popen_fork.py:67: DeprecationWarning: This process (pid=818) is multi-threaded, use of fork() may lead to deadlocks in the child.
  self.pid = os.fork()
----------------------------------------------------------------------
Ran 389 tests in 6.047s

OK

```

## Scope and limitations
Adds a hardened Docker Compose deployment profile and operator runbook, with static tests. Docker is unavailable here, so this is artifact-verified only: no actual image build, container launch, HTTP health check, volume persistence, restart or TLS test has been performed.

Passing tests establish only the behaviours covered by the suite. They do not
prove production readiness or independent operation.
