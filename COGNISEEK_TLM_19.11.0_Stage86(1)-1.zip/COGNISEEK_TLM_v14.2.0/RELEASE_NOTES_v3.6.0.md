# COGNISEEK TLM v3.6.0 — Evidence-to-Claim Reasoning

## Delivered
- New `app/claim_evidence_reasoning.py` orchestration module.
- New `POST /api/reasoning/claim-evidence` endpoint.
- New `GET /api/reasoning/claim-evidence/history` endpoint.
- Combines provisional heuristic passage relationship analysis with the existing
  reviewer-confirmed evidence-link ledger.
- Reports claim-level coverage, cross-passage conflict diagnostics and
  same-passage reviewer-direction conflicts.
- Uses exact chunk identity so repeated reviews do not inflate distinct-passage counts.
- Conflicting reviewer directions on the same passage remain unresolved.
- Append-only run snapshots; project-scoped history.
- F4 preservation: `INDETERMINATE` remains distinct; no coercion to support,
  contradiction, or zero appraisal change.

## Boundaries
- Provisional labels are not NLI, entailment, evidence direction, or truth.
- Reviewer-coded directions remain human supplied and are not ground truth.
- Passage counts do not establish source independence or sufficiency.
- No automatic source verification, truth adjudication, answer rewriting,
  model training, weight updates, or deployment.
- Existing v3.5.0 functionality is retained in this versioned copy.

## Validation
- Automated test suite: see `TEST_RESULTS_v3.6.0.txt`.
- Compile check: `python -m compileall -q app`.
- Isolated validation database only; no production database used.
- No live external search or external fetch required for tests.
