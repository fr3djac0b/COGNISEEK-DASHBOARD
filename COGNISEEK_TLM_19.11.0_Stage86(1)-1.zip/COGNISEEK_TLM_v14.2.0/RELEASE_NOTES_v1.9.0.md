# COGNISEEK TLM v1.9.0 — Claim-Level Evidence Sufficiency and Controlled Abstention

## What changed
- Added `app/claim_sufficiency.py` for deterministic, claim-by-claim evidence appraisal.
- Added `POST /api/claims/sufficiency` and `GET /api/claims/sufficiency`.
- Requires caller/reviewer-supplied evidence direction for each linked record.
- Preserves five claim statuses: `SUPPORTED_FOR_REVIEW`, `CONTRADICTED_FOR_REVIEW`, `MIXED_EVIDENCE`, `INSUFFICIENT_EVIDENCE`, and `NO_INTERPRETABLE_EVIDENCE`.
- Adds conservative response actions: `ABSTAIN` or `QUALIFY`. No unqualified answer is authorized by this gate.
- Keeps F4-compatible no-interpretable-direction evidence separate from F1/F2/F3.
- Deduplicates repeated submissions by evidence ID for counting; conflicting directions for one ID are rejected.
- Persists appraisal snapshots append-only using the existing `appraisal_snapshots` table.
- Added adversarial and API tests for empty, neutral/indeterminate, support-only, contradiction-only, mixed, duplicate, invalid, and project-isolation cases.

## Policy and interpretation
The default minimum is two distinct evidence IDs. This is a record-count threshold only. It does not establish independent sources. All direction labels are supplied by the caller/reviewer; COGNISEEK does not infer entailment or truth. Statuses are review classifications, not truth certifications or calibrated confidence scores.

## API
- `POST /api/claims/sufficiency`
- `GET /api/claims/sufficiency?project=default&limit=100`

## Limitations
- No source authentication, DOI/publisher verification, entailment model, semantic contradiction model, independent-source verification, or truth adjudication.
- No autonomous training or model-weight updates.
- Existing LLM answer generation is not yet automatically decomposed into claims and passed through this gate. This release exposes a claim-level appraisal API; an orchestrator must call it explicitly.
- No deployment performed and no live external model/provider test performed.
