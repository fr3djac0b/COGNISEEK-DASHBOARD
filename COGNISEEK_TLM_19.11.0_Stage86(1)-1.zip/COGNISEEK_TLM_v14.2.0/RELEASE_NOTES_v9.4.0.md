# COGNISEEK TLM v9.4.0
## Episode-Linked Corroboration and Source-Origin Assessment

### Added
- A new assessment workflow that joins v9.3 approved, valid, reviewer-entered evidence reviews to existing provenance and dependency diagnostics.
- Requires an exact project, acquisition orchestration, claim, and explicit candidate IDs.
- Requires each candidate to have an episode-linked APPROVED + VALID review for the same orchestration and claim.
- Maps reviewed sentence candidates to their document chunks before invoking the existing dependency engine.
- Reports reviewer-entered direction counts separately from source-origin diagnostics.
- Persists assessment snapshots append-only.

### API
- `POST /api/cognitive-runtime/corroboration-assessments`
- `GET /api/cognitive-runtime/corroboration-assessments?project=default&orchestration_id=...&limit=100`

### Guardrails
- Existing reviewer directions are not changed.
- No majority vote or automatic conflict resolution.
- Shared document, URI, content hash, source-group, publisher-context and declared lineage signals remain diagnostics.
- A detected dependency signal is not conclusive proof of common origin.
- No detected signal is not proof of independence.
- The system never certifies independent sources, truth, sufficiency, answer release or execution authorization.

### Limitation
This milestone provides an episode-linked assessment layer over existing metadata and reviewer-declared lineage. It does not independently investigate publisher ownership, author relationships, citation networks, datasets, funding or study derivation. Those require verified external records and human review.
