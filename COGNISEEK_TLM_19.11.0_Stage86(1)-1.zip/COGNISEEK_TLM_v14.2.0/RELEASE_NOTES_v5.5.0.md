# COGNISEEK TLM v5.5.0
## Evidence-Grounded Response Integration

Built from v5.4.0 in a separate release directory.

### What is new
- Converts a stored v5.4 Evidence Synthesis Intelligence report into a structured, readable response draft.
- Rechecks each selected finding's latest reviewer status immediately before response construction.
- Only findings that remain unanimously latest-approved are used as supporting study-level records.
- Carries reported effect estimates, confidence intervals, confidence level, p-values, sample sizes and recorded directionality without silently filling missing values.
- Preserves exact excerpt text, passage IDs, document IDs and character offsets for traceability.
- Records findings excluded because their current review state is not unanimously approved.
- Stores every response in an append-only response history.

### API
- `POST /api/evidence-responses/integrate`
- `GET /api/evidence-responses`
- `GET /api/evidence-responses/{response_id}`

Request example:
```json
{
  "project": "my-research-project",
  "synthesis_report_id": "YOUR_V5_4_REPORT_ID",
  "question": "What do the selected studies report?"
}
```

### Important boundaries
- Deterministic response rendering, not new LLM generation.
- Not a foundation model, model training, or weight update.
- Does not pool effects, perform meta-analysis, infer causality, determine truth, certify source independence, or assign an overall quality score.
- Statistical values are carried from v5.2 study profiles and are not independently recomputed.
- Reviewer approval is a workflow state, not independent proof of accuracy.
- This release creates response drafts; external publication and consequential use still require appropriate review.

See `TEST_RESULTS_v5.5.0.txt`.
