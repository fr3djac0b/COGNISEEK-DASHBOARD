# COGNISEEK TLM v2.8.0 — Evidence-Grounded Answer Policy

## Purpose
Connect generated draft text to reviewer-confirmed claim-to-passage links. The system now produces a claim-by-claim evidence ledger and conservative response instructions. It does not generate or certify facts.

## New API
- `POST /api/answer/ground`
  - Input: `project`, `draft`, optional `min_distinct_records` (1–20).
  - Splits draft into sentence-level candidate claims.
  - Finds reviewer-confirmed links for exact target-claim text in the same project.
  - Deduplicates repeated review events by passage `chunk_id`.
  - Applies the existing evidence sufficiency policy to each claim.
  - Returns claim status, reviewer-coded direction, provenance, limitations and response instructions.
  - Persists an append-only run.
- `GET /api/answer/ground/history?project=default&limit=100`
  - Returns prior grounding runs without overwriting them.

## Claim-level policy
- `SUPPORTED_FOR_REVIEW`: may be described only as supported by reviewed passages, with provenance and qualification.
- `CONTRADICTED_FOR_REVIEW`: do not present as established; explain the contradiction.
- `MIXED_EVIDENCE`: preserve both sides; do not choose a winner.
- `INSUFFICIENT_EVIDENCE`: qualify or abstain.
- `NO_INTERPRETABLE_EVIDENCE`: abstain; retain F4-compatible state.

The overall policy is always `QUALIFY` or `ABSTAIN`. An unqualified answer is not enabled.

## Calibration honesty
The response includes `numeric_truth_probability: null` and `confidence_calibrated: false`. Evidence coverage and reviewer-coded directions are not calibrated probabilities. This release deliberately does not manufacture a confidence percentage.

## Validation
- 133 automated tests passed.
- Added tests cover reviewed-link use, append-only history, no-review abstention, mixed-direction preservation and project isolation.
- Python compileall passed.
- ZIP integrity checked after packaging.
- No live external acquisition, deployment, model training or weight updates performed.

## Limitations
- Sentence splitting is heuristic and does not reliably identify atomic/material claims.
- Only exact target-claim text matches are considered; paraphrase matching is not used for grounding.
- Reviewer labels are not ground truth.
- Distinct passage IDs do not establish source independence.
- This is an evidence policy/trace layer, not a calibrated model or autonomous fact checker.
