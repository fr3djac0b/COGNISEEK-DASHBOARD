# COGNISEEK TLM v0.6.1

- Adds a Dockerfile and Render blueprint for deployment.
- Adds deployment and public-use safety notes.
- Keeps the v0.6.0 evidence, feedback, trace, and M-RBAM research features.
- Does not add automatic model training, independent web retrieval, or authentication.
