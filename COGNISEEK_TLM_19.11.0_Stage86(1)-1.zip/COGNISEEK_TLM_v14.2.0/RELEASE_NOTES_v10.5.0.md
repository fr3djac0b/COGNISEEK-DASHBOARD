# COGNISEEK TLM v10.5.0 — Identity Provider Integration

## Scope
Adds an OIDC/JWT identity-provider boundary to the v10.4.0 request authorization workflow.

## Implemented
- Configured issuer, audience and JWKS endpoint are mandatory for token authentication.
- PyJWT verifies asymmetric token signatures and issuer/audience/expiry/issued-at claims.
- Subject is taken only from a verified token.
- Signed role claims are mapped through `COGNISEEK_ROLE_MAP_JSON`.
- Signed project membership is checked before a principal is accepted.
- FastAPI authorization endpoint accepts `Authorization: Bearer <token>`.
- Caller-supplied actor/role remain untrusted metadata.
- Authorization remains assessment-only: no answer publication is implemented.

## Configuration
Set `COGNISEEK_OIDC_ISSUER`, `COGNISEEK_OIDC_AUDIENCE`, and `COGNISEEK_OIDC_JWKS_URL`.
Optional: `COGNISEEK_OIDC_ROLE_CLAIM` (default `roles`), `COGNISEEK_OIDC_PROJECT_CLAIM` (default `projects`),
`COGNISEEK_ROLE_MAP_JSON`, and `COGNISEEK_OIDC_ALGORITHMS` (asymmetric algorithms only; default RS256).

## Security limitations
- Deployment must supply a real OIDC provider, trusted JWKS URL, TLS/network policy and role/project claims.
- This release does not implement login/session issuance, user provisioning, revocation introspection, MFA policy, or tenant administration.
- JWKS caching/refresh behavior is delegated to PyJWT's `PyJWKClient`; operational key-rotation behavior must be verified against the selected provider.
- Project membership is based on the configured signed token claim; deployments must ensure the issuer controls this claim.
- A verified identity is not equivalent to authorization to publish. Publication remains disabled.

## Compatibility
v10.4.0 source archive remains unchanged. This is a separate v10.5.0 candidate built on its extracted source.
