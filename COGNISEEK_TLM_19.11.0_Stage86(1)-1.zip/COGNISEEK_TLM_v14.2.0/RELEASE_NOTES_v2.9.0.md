# COGNISEEK TLM v2.9.0 — Evidence Reliability and Calibration

## Added
- Transparent source metadata profiles: source identity, publisher, author, publication date, method, scope, limitations, URI and content-hash presence.
- Metadata completeness is reported descriptively; no scalar source credibility/truth score is invented.
- Append-only benchmark records with explicit dataset name, predicted probability, binary reference outcome, decision threshold, reviewer and label basis.
- Evaluation metrics: Brier score, log loss, fixed 10-bin expected calibration error (ECE), confusion matrix, accuracy, precision and recall.
- Empty benchmark datasets return no metrics rather than fabricated performance.
- Append-only reliability report snapshots combining source profiles and benchmark metrics.

## API
- `GET /api/reliability/sources?project=default`
- `POST /api/reliability/benchmark`
- `GET /api/reliability/metrics?project=default&dataset=...`
- `POST /api/reliability/reports?project=default&dataset=...`
- `GET /api/reliability/reports?project=default`

## Benchmark record requirements
Each record requires a probability in [0,1], binary outcome 0/1, threshold in (0,1), reviewer and label-basis description. The supplied values are recorded as evaluation data. They do not train or update model weights.

## Interpretation and limits
- Calibration metrics are meaningful only against an appropriately constructed labelled dataset.
- Reviewer labels may contain error; dataset scope and label provenance must be documented.
- Results do not guarantee future or cross-domain performance.
- Metadata completeness is not authority, methodological quality, factual accuracy or source independence.
- The benchmark endpoint evaluates supplied probabilities; this release does not itself produce calibrated probabilities.
- No automatic source ranking, truth score, NLI, model training or deployment occurs.

## Validation
- 139 automated tests passed.
- Python compileall passed.
- ZIP integrity verified after packaging.
- Tests used an isolated SQLite database.
- No live external acquisition or deployment performed.
