# COGNISEEK TLM v0.7.0

## Evidence provenance and relationship layer
- Added publisher, author, publication/access dates, source group, source hash, method, scope and limitations fields.
- Added an additive SQLite migration so existing v0.6.1 databases can be opened without dropping existing evidence.
- Added evidence relation records: corroborates, contradicts, derived_from, duplicates and context_for.
- Enforced same-project, distinct-record relation constraints.
- Added evidence metadata qualification summary and source-group counts.
- Exact duplicate records remain auditable and point to the earlier record.

## Explicit limitations
Source group and relation labels are user-supplied, not independently verified. Metadata completeness is not source quality. No external retrieval, source validation, semantic duplicate detection, authentication or automatic model training is added in this release.
