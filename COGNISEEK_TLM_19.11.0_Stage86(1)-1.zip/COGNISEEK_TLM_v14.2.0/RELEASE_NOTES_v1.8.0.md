# COGNISEEK TLM v1.8.0 — Evidence Qualification

## Added
- Transparent item-level source metadata qualification diagnostics for evidence records and ingested documents.
- Missing-field flags for source identity, URI, publisher, author, publication date, method, scope and limitations.
- Publication-age review flags using a configurable threshold.
- Reports declared `derived_from` and `duplicates` relationships.
- Reports potential dependency clusters based on exact shared identifiers and user-supplied source-group hints.
- New endpoints:
  - `GET /api/evidence/qualification/detailed`
  - `GET /api/documents/qualification/detailed`

## Interpretation safeguards
- Metadata completeness is not a quality, authority, accuracy or truth score.
- No source is certified independent.
- Source groups remain user-supplied hints.
- Exact shared identifiers and declared relations are diagnostic signals, not proof of common origin.
- Old publication dates trigger review, not automatic rejection.
- Evidence sufficiency and claim truth are not automatically adjudicated.

## Limitations
- No automated publisher verification, DOI resolution, citation-chain crawling, plagiarism detection, or semantic duplicate detection.
- No statistical source-independence model.
- No model weights updated.
- No live provider test and no deployment.
