# COGNISEEK TLM v10.3.0 — Claim Review and Governed Release Gate Integration

## What changed
- Extended the v10.2 request pipeline with optional claim-level review of a caller-supplied draft.
- Reuses the existing claim-aware orchestrator; reviewers/callers must supply claim-indexed evidence directions.
- Records an advisory answer-control decision against the claim appraisal ledger.
- Adds append-only trace events for claim review, advisory answer control, and governed publication.
- Preserves F4-compatible `NO_INTERPRETABLE_EVIDENCE` states.

## Release behavior
- An advisory `RELEASE_QUALIFIED` is not publication authorization.
- The pipeline keeps `release_gate.eligible=false` and `answer_released=false`.
- Company-policy workflow linkage and authenticated actor/role are not established by this request route.
- No model generation, semantic entailment verification, source authentication, or external acquisition is performed.

## API
`POST /api/requests/execute` optionally accepts:
- `draft_answer`: candidate text to review
- `claim_reviews`: list of `{claim_index, evidence:[{evidence_id,direction,source_name,source_group,reference,note}]}`
- `min_distinct_records`: threshold from 1 to 20

The evidence directions are reviewer/caller supplied. Distinct evidence IDs are not proof of independent sources.

See `TEST_RESULTS_v10.3.0.txt` and `RELEASE_MANIFEST_v10.3.0.json`.
