# COGNISEEK TLM v1.2.0 — Evidence Reasoning and Provenance

## Added
- `POST /api/claims/match`: matches a target claim to candidate document passages using lexical retrieval and, when configured, embedding similarity with reciprocal-rank fusion.
- Matching results preserve passage provenance: document/chunk IDs, source name, URI, publisher, author, date, source group, method, scope and limitations.
- Every match is explicitly marked `NOT_ASSESSED` for evidence direction. Similarity is not support, contradiction, entailment, or truth.
- `GET /api/evidence/dependency-graph`: returns evidence records as nodes and manually recorded evidence relations as edges, with duplicate/source-group hints.
- New tests for end-to-end claim matching, provenance preservation, and dependency graph boundaries.

## API additions
- `POST /api/claims/match`
- `GET /api/evidence/dependency-graph`

## Boundaries
- Matching is retrieval, not logical inference.
- Semantic matching is only available when a compatible embedding provider is configured and vectors exist.
- Dependency graph displays recorded relationships; it does not infer or verify source independence.
- Evidence direction still requires caller coding/human review before appraisal.
- No live web acquisition, source authentication, automatic fact-checking, or model-weight training is included.
