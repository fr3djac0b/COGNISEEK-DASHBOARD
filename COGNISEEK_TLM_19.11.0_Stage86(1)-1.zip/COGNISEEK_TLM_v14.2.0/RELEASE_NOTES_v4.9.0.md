# COGNISEEK TLM v4.9.0 — Evidence Synthesis and Cross-Study Comparison

## Purpose
Adds a claim-focused comparison report across explicitly selected stored evidence candidates. The report combines source metadata, reviewer-coded claim/source states, and reviewer-entered methodological appraisals while preserving each study's distinct profile.

## New capabilities
- Compare 1–100 exact project-scoped candidate passage IDs against one target claim.
- Display study/source metadata alongside reviewer-coded evidence states.
- Summarize latest distinct reviewer assessments per candidate while retaining all earlier review events in their original append-only tables.
- Preserve within-study reviewer disagreement and across-study directional variation.
- Compare recorded study-design descriptions, populations, sample sizes, measurement methods, replication statuses, and claim-scope relations.
- Flag candidates without evidence review or methodological appraisal; absence is not treated as negative evidence.
- Store project-scoped append-only synthesis reports.

## API
- `POST /api/synthesis/cross-study`
- `GET /api/synthesis/cross-study/history`

## Guardrails
- No pooled effect estimate or meta-analysis.
- No automatic winner selection or vote-based truth conclusion.
- No evidence direction inference; direction counts summarize reviewer-entered labels only.
- No aggregate study-quality score or source-independence certification.
- Different text descriptions do not prove methods are comparable or different.
- Candidate passage selection is explicit; the system does not claim the selected set is exhaustive.
- No model training, weight update, live search/fetch, or deployment.

## Compatibility
Built by copying the v4.8.0 source bundle. Previous release ZIP is preserved unchanged.
