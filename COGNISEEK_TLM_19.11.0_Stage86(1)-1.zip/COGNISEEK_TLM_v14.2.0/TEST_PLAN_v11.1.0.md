# v11.1.0 Test Plan

1. Verify a new integrated run can be resolved within its project.
2. Reject references not linked to that integrated run/report.
3. Reject cross-project run access.
4. Confirm unreviewed passages are `PENDING`, not F4.
5. Confirm existing appraisal engine calculates delta and U without reinterpretation.
6. Confirm direction 0 retains the existing F4 / U=NA behavior.
7. Confirm multiple appraisals are append-only and disagreement remains visible.
8. Confirm completion percentage counts reviewed passage coverage, not number of appraisal events.
9. Confirm zero-passage reports are `NOT_APPLICABLE`.
10. Confirm completion checks do not authorize answer release.
11. Verify all four FastAPI routes register.
12. Run the full inherited regression suite with a fresh isolated database.
13. Run Python compileall and verify ZIP integrity.
