# COGNISEEK TLM v3.0.0 — Controlled Learning and Adaptation

## What this release adds
- Converts an existing project-scoped appraisal plus its linked reviewer outcome into a structured, provenance-bearing learning example.
- Classifies memory examples as episodic, semantic, or procedural; the caller must explicitly select the type.
- Keeps examples in `PROVISIONAL_REVIEWED_FEEDBACK` state. A reviewer outcome is not silently promoted to ground truth.
- Evaluates paired baseline and candidate probabilities on the same case IDs and outcomes.
- Reports Brier score and log loss for both systems.
- Applies a minimum sample gate and a configurable Brier-regression tolerance.
- Stores explicit reviewer decisions (APPROVE, REJECT, DEFER).
- Records a governance promotion only when the experiment passes and an explicit reviewer approves it.

## API
- `POST /api/learning/examples/build`
- `GET /api/learning/examples`
- `POST /api/learning/experiments`
- `GET /api/learning/experiments`
- `POST /api/learning/reviews`
- `GET /api/learning/reviews`
- `POST /api/learning/promotions`
- `GET /api/learning/promotions`

## Safety and scientific boundaries
- No base-model or adapter weights are trained or changed.
- No live model is switched and no deployment is performed.
- A promotion record means governance approval for separate implementation, not deployment.
- Paired scores are only meaningful for the supplied dataset and labels; label errors, leakage, class imbalance, sample size, and dataset representativeness still matter.
- Brier score is the primary regression gate; log loss is reported as a secondary diagnostic, not separately gated.
- The current release does not create training datasets from arbitrary chat text. It requires an existing project-scoped appraisal and linked outcome.
- No automatic semantic-memory consolidation or procedural policy rewrite occurs.
- Existing records are not overwritten; learning examples, experiments, reviews and promotion records are append-only.

## Validation
See `TEST_RESULTS_v3.0.0.txt`.
