# COGNISEEK TLM v2.0.0 — Claim-Aware Answer Orchestration

## Added
- `app/orchestrator.py`: deterministic draft-to-claim-to-policy orchestration.
- Candidate claim splitting by sentence boundaries with review-required flags.
- Per-claim evidence appraisal using the v1.9 claim sufficiency engine.
- Per-claim statuses and explanations preserved independently.
- Whole-answer action: `ABSTAIN` when all claims have no records/no interpretable direction; otherwise `QUALIFY` for review. No unqualified `ANSWER` action is enabled.
- Append-only `answer_orchestrations` table and claim appraisal snapshots.
- API:
  - `POST /api/answer/orchestrate`
  - `GET /api/answer/orchestrations`
- Tests for sentence splitting, missing evidence, mixed evidence, F4 compatibility, policy output, invalid claim indices, persistence, project isolation, API and health version.

## Validation
- Automated tests: 86 passed, 0 failed.
- `python -m compileall -q app`: passed.
- ZIP integrity: verified during packaging.

## Important limitations
- The input is a candidate draft answer; this endpoint does not yet call the LLM or retrieve evidence automatically.
- Sentence splitting is not reliable atomic-claim extraction and requires human review.
- Evidence directions are supplied by caller/reviewer; no automated entailment or contradiction model is included.
- No source authentication, source independence verification, truth adjudication, or calibrated confidence.
- No autonomous model training or weight updates.
- No deployment or live external model/provider test performed.
