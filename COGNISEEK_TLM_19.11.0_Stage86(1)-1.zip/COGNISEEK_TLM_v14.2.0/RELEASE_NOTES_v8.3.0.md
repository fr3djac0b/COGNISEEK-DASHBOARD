# COGNISEEK TLM v8.3.0 — Adaptive Experience Selection

## Purpose
Prioritize consolidated historical experiences using current query relevance and the v8.2 reviewer-outcome reliability assessment.

## Selection behavior
1. Only experiences that remain currently consolidated are eligible (inherited v8.0 gate).
2. Lexical relevance is the primary ordering factor.
3. Reliability guidance is a secondary ordering factor:
   - Repeatedly helpful: higher advisory priority.
   - Insufficient history or mixed/inconclusive: neutral middle priority.
   - Stale: low priority pending refresh.
   - Repeatedly unhelpful: lowest priority.
4. Candidate ID is the deterministic tie-breaker.
5. The result limit is applied after ranking.

## API
`GET /api/cognitive-runtime/learning/experience-selection?project=default&query=...&limit=5&stale_after_days=180`

The episode application endpoint now uses this selector:
`POST /api/cognitive-runtime/learning/experience-applications`

## Safeguards
- Relevance remains primary: a historically helpful but unrelated experience cannot outrank a directly matching one.
- Stale and repeatedly unhelpful experiences are retained but deprioritized, not silently deleted.
- Reliability is based on reviewer-entered assessments and is not a calibrated probability.
- Lexical matching is not semantic understanding.
- Historical experience remains context, never current evidence.
- Current evidence must be independently qualified and may contradict historical experience.
- No truth inference, evidence promotion, model-weight update, or automatic action is performed.

## Validation
See `TEST_RESULTS_v8.3.0.txt` for the executed test result.
