# COGNISEEK TLM v12.4.0

## Milestone
**Learning Experience and Promotion Authorization**

This release extends the existing verified-identity and project-membership boundary
to 11 additional learning and experience-memory API method/path entries.

## Newly governed routes

| Method | Route | Required roles |
|---|---|---|
| POST | `/api/learning/examples/build` | ADMIN, OPERATOR |
| GET | `/api/learning/examples` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| POST | `/api/experience-memory/reviews` | ADMIN, REVIEWER |
| GET | `/api/experience-memory/history` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| POST | `/api/experience-memory/retrieve` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| POST | `/api/learning/experiments` | ADMIN, OPERATOR |
| GET | `/api/learning/experiments` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| POST | `/api/learning/reviews` | ADMIN, REVIEWER |
| GET | `/api/learning/reviews` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| POST | `/api/learning/promotions` | ADMIN |
| GET | `/api/learning/promotions` | ADMIN, REVIEWER, OPERATOR, VIEWER |

## Authorization design

- Every listed route requires a verified bearer identity.
- Project membership is checked at the same authorization boundary used by earlier releases.
- Experience-memory approval and revocation require ADMIN or REVIEWER.
- Experiment creation and learning-example construction require ADMIN or OPERATOR.
- Experiment review requires ADMIN or REVIEWER.
- Promotion is ADMIN-only; read access remains available to authorized project roles.
- Authorization outcomes continue through the existing append-only identity authorization audit.
- A route policy is an access-control decision, not evidence that the underlying scientific claim is true.
- Approval or promotion does not convert historical experience into universal truth or silently update model weights.

## Verification

- New v12.4 authorization tests: 10 passed.
- v12.3 + v12.4 focused authorization tests: 19 passed.
- Full regression suite: 803 passed, 0 failed.
- Python compileall: PASS.
- FastAPI import: PASS; 307 routes registered.
- Route governance register: 299 entries; 34 explicit policies; 208 review-required;
  57 unclassified; 0 declared public.
- M-RBAM source unchanged byte-for-byte from v12.3.0 baseline.
- M-RBAM source SHA-256: `5bcafd59da496342370c9877510a9e4e67cd8f9107be76d21377cce12340bf84`.

## Scope limitations

This is a selected route remediation, not a complete API security certification.
The remaining 208 review-required and 57 unclassified route entries still need
semantic review. Live identity-provider/JWKS validation, deployed penetration
testing, and external security certification were not performed.
