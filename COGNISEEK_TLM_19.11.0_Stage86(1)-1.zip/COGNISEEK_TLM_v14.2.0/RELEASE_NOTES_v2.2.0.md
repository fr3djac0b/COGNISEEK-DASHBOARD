# COGNISEEK TLM v2.2.0

## Provisional Semantic Evidence Relationship Analysis

- Added `app/evidence_analysis.py`.
- Added `POST /api/claims/evidence-analyze`.
- Analyzes candidate passages using lexical coverage/Jaccard overlap, negation mismatch, contrast cues, and optional embedding similarity.
- Returns provisional relationship labels, reasons, retrieval features, source provenance, and `review_required=true`.
- Project-scoped retrieval and optional candidate chunk ID filtering.
- Embedding provider failure is handled with lexical fallback.
- No provisional relationship is written as a confirmed evidence direction.
- No automatic appraisal, truth determination, or model-weight update.

## Explicit boundaries

This is not a validated NLI model. The system does not currently emit automatic contradiction labels; possible polarity mismatch is classified as `AMBIGUOUS`. `POTENTIAL_SUPPORT` is a heuristic candidate only and must be reviewed against the source in context. Similarity is not entailment.
