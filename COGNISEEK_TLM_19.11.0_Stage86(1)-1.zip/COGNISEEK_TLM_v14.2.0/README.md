# COGNISEEK TLM v12.0.0

Major milestone: structured API route governance register. Generates an auditable inventory of route ownership, sensitivity prompts, role policies, and review status without changing endpoint behavior. See release notes and test results.

# COGNISEEK TLM v11.9.0

Adds a repeatable security regression gate, governed route-policy registration checks, route inventory artifacts, and a GitHub Actions workflow. See release notes and test results for scope and limitations.

# COGNISEEK TLM v11.8.0

Cross-project isolation adversarial regression tests for selected identity, memory lifecycle, integrated review, and evidence-reference boundaries. See release notes and test results for exact scope and limitations.

# COGNISEEK TLM v11.7.0

Authorization policy hardening for the seven explicitly governed v11.4 routes, plus defense-in-depth project membership enforcement. This does not secure every legacy route. See `RELEASE_NOTES_v11.7.0.md`, `TEST_PLAN_v11.7.0.md`, and `TEST_RESULTS_v11.7.0.txt`.

# COGNISEEK TLM v11.6.0

Static API route security inventory and manual-review findings. This is not security certification. See `RELEASE_NOTES_v11.6.0.md`, `TEST_PLAN_v11.6.0.md`, and `TEST_RESULTS_v11.6.0.txt`.

# COGNISEEK TLM v11.5.0\n\nEnd-to-end deployment preflight and validation additions. See `RELEASE_NOTES_v11.5.0.md`, `TEST_PLAN_v11.5.0.md`, and `TEST_RESULTS_v11.5.0.txt`. This is not production certification.\n\n# COGNISEEK TLM v10.7.0

Model-assisted semantic claim-to-passage assessment. Results are provisional and require human review; this is not factual truth certification. See `RELEASE_NOTES_v10.7.0.md` and `TEST_RESULTS_v10.7.0.txt`.

# COGNISEEK TLM v10.6.0

Source provenance assessment extends the existing controlled discovery and HTTPS acquisition workflow. See `RELEASE_NOTES_v10.6.0.md` and `TEST_RESULTS_v10.6.0.txt`.

# COGNISEEK TLM v10.5.0

This release extends the v10.4.0 baseline with an OIDC/JWT trusted identity-provider boundary.
See `RELEASE_NOTES_v10.5.0.md` for configuration, capabilities, test evidence and security limitations.

# COGNISEEK TLM v3.9.0 — Governed Experience Learning Engine

**Tagline:** Seek Truth. Ignite COGNISEEK.

This release builds on the v0.4 prototype, preserving its evidence, appraisal, trace, trajectory, optional model connector and interface while adding persistent feedback records. It remains a prototype: it is not a trained foundation model and does not automatically learn model parameters.

## What's new in v0.5
- `POST /api/feedback`: persist agree/disagree/note/correction feedback, optionally linked to a known interaction trace in the same project.
- `GET /api/feedback`: retrieve stored feedback.
- `GET /api/learning/summary`: report feedback totals and categories.
- Feedback is reviewable experience data only; no automatic parameter updates or self-training occur.

## Retained from v0.4
- `app/evidence.py`: validated evidence input, text normalization, stable duplicate fingerprint, conservative claim appraisal.
- `app/trace.py`: SQLite storage for evidence, trace events and trajectory snapshots, with project/time indexes.
- `app/model_client.py`: optional OpenAI-compatible chat-completions client with timeout; safe demo mode if no model is configured.
- `app/main.py`: FastAPI endpoints and SSE response streaming, using the modular helpers.
- Duplicate submissions are retained for audit but flagged; they must not be counted as independent confirmation.
- Tests are split between evidence/appraisal and API integration.

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
python -m pip install -r requirements.txt
cp .env.example .env  # optional; set values in your shell or environment manager
python -m uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000`. API health: `/health`; interactive API docs: `/docs`.

To use a compatible model, configure `OPENAI_API_KEY`, `MODEL_NAME`, and optionally `MODEL_BASE_URL` on the **server**. Never place credentials in frontend code or commit `.env`.

## Run tests

```bash
python -m pytest -q
```

The included `TEST_RESULTS.txt` records the result from the packaged source tree. Tests use an isolated temporary SQLite database during verification; no user data or pre-populated database is included in this release.

## v0.7.0 — Evidence provenance and relationship layer

This release adds an additive SQLite migration and structured evidence lineage fields: publisher, author, publication/access dates, source group, source hash, method, scope and limitations. Evidence relationships can be recorded as `corroborates`, `contradicts`, `derived_from`, `duplicates` or `context_for`. Project boundaries are enforced for relationship creation. Repeated records remain in the audit store and retain a `duplicate_of` pointer where an exact normalized fingerprint match is found.

New endpoints:
- `GET /api/evidence/qualification?project=default` — metadata completeness and user-supplied source-group overview.
- `POST /api/evidence/relations` — link two existing records in one project.
- `GET /api/evidence/relations?project=default&evidence_id=...` — retrieve links.

**Interpretation boundary:** source groups are dependency hints supplied by users, not proof of independence. Metadata completeness is not evidence quality. Relation labels are not automatically verified. A corroboration link does not prove a claim. The engine preserves relations and warnings; it does not decide truth.

## API endpoints
- `GET /health`
- `GET /api/evidence?project=default`
- `POST /api/evidence`
- `GET /api/evidence/qualification`
- `POST /api/evidence/relations`
- `GET /api/evidence/relations`
- `POST /api/claims/review`
- `POST /api/chat`
- `POST /api/chat/stream` (SSE chunks; answer generation is not upstream token-streaming)
- `POST /api/feedback`
- `GET /api/feedback?project=default`
- `GET /api/learning/summary?project=default`
- `GET /api/trajectory?project=default`
- `GET /api/traces?project=default`

## Important limitations
- Evidence status is user-entered and not independently verified; labels are not proof.
- Duplicate detection is a warning based on normalized record fields, not proof that sources are dependent.
- No web retrieval, authentication, per-user authorization, or autonomous real-world actions.
- A trajectory/trace and stored feedback are operational records, not automatic learning or a trained TLM.
- Do not deploy publicly with sensitive data until authentication, authorization, privacy controls, abuse protection, and security review are implemented.

## v0.6.0: M-RBAM research workbench

This release adds a research-only M-RBAM episode workbench and API. It records pre/post appraisal scores, evidence direction and coding notes; computes `Delta_A` and `U` only when valid; persists episode-level records; and exposes separate QAAT, UAT and CAR trajectories. It preserves missing values as `null` rather than silently replacing them with zero.

Endpoints:
- `POST /api/m-rbam/episodes` — classify and save a research episode.
- `GET /api/m-rbam/episodes` — list saved research episodes.
- `GET /api/m-rbam/trajectory` — return separate QAAT/UAT/CAR series.
- `GET /api/m-rbam/protocols` — document supported, versioned rule profiles.

Two explicitly versioned profiles are available. `strict_alignment_v0.2` is the default and preserves strict F1–F3 meanings plus UC and NA. F2 requires `meaningful_realignment=true`; F3 requires `material_discordance=true`, adequate communication and comprehension. Alignment boundaries (0–3 discordant / 4–6 borderline / 7–10 aligned in the appropriate direction) are provisional research examples, not validated clinical thresholds. `directional_v0.1` is an experimental alternative implementing F1 when U>0, F2 when U=0, F3 when U<0, and F4 when evidence direction is indeterminate. Do not mix the two profiles or treat their labels as equivalent.

The assistant instructions now explicitly treat M-RBAM as a proposed research framework, distinguish evidence records from research coding, separate indeterminate evidence from missing appraisal measurements, and prohibit treating research categories as diagnosis or treatment advice. This does not create a clinical system or train model weights. Use synthetic data during development; do not enter identifiable participant information. Before research recruitment, obtain appropriate ethics approvals and have the SAP, measurement protocol and thresholds reviewed by qualified researchers/statisticians and relevant clinical/laboratory experts.


## Deployment (v0.7.0)

This package includes a Dockerfile and Render Blueprint (`render.yaml`). Connect the repository to Render, set `MODEL_NAME` and `OPENAI_API_KEY` only if using a compatible model, and use `/health` as the health check. Before public use, add authentication and configure persistent storage; the current prototype has no user access controls. See `DEPLOYMENT_NOTES.md`.

## v0.8 document ingestion and retrieval

COGNISEEK can ingest user-supplied text documents into a project-scoped store and retrieve relevant passages using transparent lexical ranking.

### Ingest a document

```bash
curl -X POST http://127.0.0.1:8000/api/documents \
  -H 'Content-Type: application/json' \
  -d '{"project":"research","title":"Example report","source_name":"Example source","publisher":"Example publisher","source_group":"study-001","text":"Paste extracted document text here."}'
```

### Search stored documents

```bash
curl "http://127.0.0.1:8000/api/retrieval/search?project=research&q=your%20research%20question"
```

`POST /api/documents` accepts plain text and provenance metadata. `GET /api/documents` lists documents in a project. Chat requests retrieve up to six matching passages and pass them to a connected model as **unverified source material**.

Important: lexical ranking estimates textual relevance only. It does not establish truth, authority, independence, or evidential direction. v0.8 does not fetch URLs, parse PDF/DOCX files, create embeddings, or authenticate sources. Extract document text before ingestion.


## v0.9 retrieval qualification additions
- Hybrid lexical ranking combines inverse-document-frequency term relevance, query-term coverage and exact phrase matching.
- `GET /api/documents/qualification` reports source metadata completeness and missing provenance fields.
- Retrieval scores are relevance indicators only; they are not truth or confidence scores.
- Semantic embeddings, live web retrieval and independent source validation remain future work.


## v1.0.0 — Optional semantic retrieval and hybrid RAG

COGNISEEK can now use a configured OpenAI-compatible embeddings endpoint to embed document chunks and queries. When configured, it computes cosine similarity and merges semantic and lexical rankings using Reciprocal Rank Fusion (RRF). If the provider is not configured or a query-time provider call fails, the API falls back to lexical retrieval and reports the retrieval mode.

### Configure embeddings
Set these server-side environment variables:
- `EMBEDDING_BASE_URL` (defaults to `MODEL_BASE_URL` or the OpenAI API base URL)
- `EMBEDDING_API_KEY` (falls back to `OPENAI_API_KEY`)
- `EMBEDDING_MODEL` (required to enable embeddings)

After configuring the provider, ingest documents again to create and persist vectors. v0.9 documents are not automatically backfilled. Check `GET /api/retrieval/status` to see vector counts and whether semantic search is active.

### v1.0 limitations
- No embedding model is bundled or trained.
- No automatic re-embedding when the embedding model changes.
- No live web search, PDF/DOCX parsing, source authentication or claim-level adjudication.
- RRF is a ranking merge, not a truth score or confidence calibration.


## v1.1 Evidence intelligence endpoints

- `POST /api/claims/extract` — sentence-segment document chunks into unverified candidate statements.
- `GET /api/claims/candidates` — list candidate statements by project.
- `POST /api/claims/compare` — lexical overlap/negation review heuristic; not entailment verification.
- `POST /api/claims/appraise` — summarize caller-coded SUPPORTS, CONTRADICTS, NEUTRAL, INDETERMINATE evidence; abstains on conflict or inadequate directional/source-group hints.
- `GET /api/claims/appraisals` — retrieve append-only appraisal snapshots.

See `RELEASE_NOTES_v1.1.0.md` for limitations. All claim/evidence conclusions require human review.


## v1.2 Evidence reasoning and provenance
- `POST /api/claims/match` — retrieve potentially relevant document passages for a target claim; preserves source provenance and never assigns evidence direction from similarity.
- `GET /api/evidence/dependency-graph` — inspect recorded evidence relationships and source-group hints.
- See `RELEASE_NOTES_v1.2.0.md` for the precise scope and limitations.


## v1.3 Episode intelligence and longitudinal memory
Every chat request now creates an append-only episode. Potentially relevant prior episodes are retrieved within the project using lexical overlap and recency, then passed as explicitly historical and unverified context. Outcomes can be appended as confirmed, corrected, rejected, inconclusive, or follow-up; recorded corrections are surfaced during later retrieval.

Endpoints:
- `GET /api/episodes`
- `GET /api/episodes/retrieve?q=...`
- `POST /api/episodes/outcomes`
- `GET /api/episodes/outcomes`

See `RELEASE_NOTES_v1.3.0.md` for limits and governance boundaries.


## v1.4.0 — Adaptive Episodic Memory and Temporal Reasoning

This release adds optional semantic retrieval for past episodes using the configured embedding provider, with lexical fallback when unavailable. Episode vectors are stored separately from document-chunk vectors and are keyed by embedding model. Retrieval returns lexical overlap, semantic similarity (when available), age, temporal review flags, outcomes, and an audit explanation.

Temporal decay is a ranking heuristic only. Old information is not automatically false; records beyond the configurable default review horizon are flagged for review rather than deleted or rejected. Recorded corrections are included in the historical context supplied to the connected model, while the original episode remains immutable.

New endpoints:
- `POST /api/episodes/compare` — structural side-by-side comparison of a prior episode and current material; it does not decide truth or contradiction.
- `POST /api/memory/items` and `GET /api/memory/items` — store and retrieve explicitly reviewed episodic, semantic, or procedural memory items with provenance.
- `GET /api/episodes/retrieve` — now exposes temporal qualification and memory audit details.

Memory types are not automatically inferred. A reviewer must explicitly classify a stored item. Semantic episode retrieval requires a configured embedding provider and stored episode vectors; otherwise lexical retrieval continues. Embedding model changes require re-embedding episodes for comparable semantic retrieval.

Limitations remain: no authentication or per-user isolation, no automatic truth adjudication, no source-independence verification, no autonomous model-weight updates, and no live provider test is implied by offline tests.


## v1.5.0 — Evidence-Driven Appraisal and Conflict Tracking

This release adds a separate append-only learning appraisal ledger. A reviewer records pre-evidence appraisal (A_pre), post-evidence appraisal (A_post), and an explicit evidence direction D ∈ {-1, 0, +1}. The system computes:

- ΔA = A_post − A_pre
- U = D × ΔA, only when D is interpretable (+1 or −1)

For D = 0, the record is F4 (no interpretable evidence direction), and U is left undefined rather than forced to zero. A non-interpretable record must use D=0. The system rejects D=0 when the caller marks evidence interpretable.

For directional records, the software records whether the appraisal moved consistently with, against, or not at all relative to the coded evidence direction. It deliberately does not assign F1/F2/F3 labels: the exact user-defined mapping for those forms has not yet been specified and must not be invented.

The ledger can link a new appraisal to a prior appraisal and flag a change in nonzero evidence direction for review. This is a discordance flag, not an automatic resolution. Reviewer-recorded outcomes are append-only and can be summarized for monitoring; they are not independent ground truth and do not produce an accuracy or calibration claim.

New endpoints:
- `POST /api/learning/appraisals`
- `GET /api/learning/appraisals`
- `POST /api/learning/outcomes`
- `GET /api/learning/outcomes`
- `GET /api/learning/evaluation`

No model weights are updated. Evidence direction is explicitly supplied by a reviewer; it is not automatically inferred by the language model.


## v1.6.0 — Expectation and Reality Tracking

This release adds an append-only trajectory layer that keeps four concepts distinct:
1. **Expectation** — a recorded prior prediction, including its direction, optional confidence, basis and provenance.
2. **Observation** — later reviewer-coded evidence direction and its supporting references.
3. **Comparison** — concordance, discordance, or indeterminate comparison.
4. **Review history** — append-only records; no earlier expectation is overwritten.

### New endpoints
- `POST /api/trajectory/expectations`
- `GET /api/trajectory/expectations`
- `POST /api/trajectory/reviews`
- `GET /api/trajectory/reviews`
- `GET /api/trajectory/evaluation`

A direction of `0` remains indeterminate; it is not forced into a positive or negative direction. A discordant comparison is flagged, not resolved. Optional confidence fields are descriptive only: this release does not calculate Brier score, ECE, accuracy, or calibrated probabilities. No model weights are updated.


## v1.7.0 — Correction-Aware Memory and Evidence Reuse

Historical episodes with `corrected` or `rejected` outcomes now carry a special retrieval status. The original answer is preserved for audit, but downstream context explicitly labels it as not reusable as knowledge and surfaces reviewer-recorded corrections separately. This is a review signal, not automatic truth verification.

`POST /api/episodes/evidence-reuse` compares exact evidence identifiers across a selected set of episodes and flags repeated references. It does not prove that sources are independent or detect all paraphrased duplicates.


## v1.8.0 — Evidence Qualification

Adds detailed metadata and dependency diagnostics for stored evidence and ingested documents. The endpoints identify missing source metadata, parseable publication dates, stale-review flags, explicit dependency relations, and potential clusters based on exact identifiers or user-supplied source-group hints.

These are qualification signals only. They do not certify source quality, truth, independence, or evidential sufficiency.


## v1.9.0 — Claim-level evidence sufficiency and controlled abstention

COGNISEEK can now appraise evidence separately for each material claim through
`POST /api/claims/sufficiency`. Each evidence-to-claim direction must be supplied
explicitly as `SUPPORTS`, `CONTRADICTS`, `NEUTRAL`, or `INDETERMINATE`; the
engine does not infer entailment from text similarity.

The default policy threshold is two distinct evidence IDs. This is a count of
records, **not a count of verified independent sources**. Repeated submissions
with the same evidence ID do not inflate the count. Conflicting directions for
one evidence ID are rejected for review.

Claim statuses:
- `SUPPORTED_FOR_REVIEW`
- `CONTRADICTED_FOR_REVIEW`
- `MIXED_EVIDENCE`
- `INSUFFICIENT_EVIDENCE`
- `NO_INTERPRETABLE_EVIDENCE`

Response actions are conservative policy outputs: `ABSTAIN` for no records or
no interpretable direction, and `QUALIFY` for partial, mixed, or review-labelled
directional evidence. The engine does not emit an unqualified `ANSWER` action.
`NO_INTERPRETABLE_EVIDENCE` is F4-compatible and is not forced into F1/F2/F3.

Appraisals are stored as append-only snapshots in the existing appraisal table.
Retrieve them with `GET /api/claims/sufficiency?project=default`.

Example request:

```json
{
  "project": "default",
  "claim": "The intervention reduced the measured outcome.",
  "min_distinct_records": 2,
  "evidence": [
    {"evidence_id": "record-1", "direction": "SUPPORTS", "source_name": "Study A"},
    {"evidence_id": "record-2", "direction": "CONTRADICTS", "source_name": "Study B"}
  ]
}
```

The response is `MIXED_EVIDENCE` and `QUALIFY`; neither direction is silently
discarded. These labels do not establish factual truth, source authenticity,
methodological validity, or source independence.


## v2.0.0 — Claim-aware answer orchestration

This release adds a first orchestration layer that takes a user request and a
candidate draft answer, splits the draft into candidate sentences, appraises
each sentence separately, and produces a whole-response policy result.

### Endpoints
- `POST /api/answer/orchestrate`
- `GET /api/answer/orchestrations?project=default&limit=100`

### Example request

```json
{
  "project": "default",
  "user_request": "Did the intervention reduce the outcome?",
  "draft_answer": "The intervention reduced the measured outcome. The effect was sustained for six months.",
  "min_distinct_records": 2,
  "claim_reviews": [
    {
      "claim_index": 0,
      "evidence": [
        {"evidence_id": "study-a", "direction": "SUPPORTS"},
        {"evidence_id": "study-b", "direction": "CONTRADICTS"}
      ]
    },
    {
      "claim_index": 1,
      "evidence": []
    }
  ]
}
```

The engine retains claim-level distinctions. The first claim is `MIXED_EVIDENCE`;
the second is `INSUFFICIENT_EVIDENCE`. The whole response is `QUALIFY`, and
the assembled output labels each claim and its reason. If all claims have no
records or no interpretable directional evidence, the overall action is
`ABSTAIN`.

### Design boundary
- Sentence splitting creates candidate claims, not guaranteed atomic claims.
- `claim_index` connects reviewer-supplied evidence to each extracted sentence.
- Evidence directions remain caller/reviewer supplied. No text similarity or
  LLM-generated guess is silently promoted to a SUPPORTS/CONTRADICTS label.
- The orchestrator stores append-only orchestration snapshots and individual
  claim appraisal snapshots.
- No unqualified `ANSWER` action is enabled in v2.0.0.
- This endpoint currently accepts a candidate draft answer; it does not yet
  automatically call the connected LLM, retrieve passages, and infer claim
  relations. That requires a separately validated evidence-linking layer.


## v2.1.0 — Retrieval candidates and reviewer-confirmed evidence links

This release connects stored document passages to the claim review workflow.

### New endpoints
- `POST /api/claims/evidence-candidates`\n- `POST /api/claims/evidence-analyze` — provisional claim-to-passage relationship suggestions\n- `POST /api/claims/evidence-conflicts` — reviewer-direction conflict and dependency diagnostics\n- `GET /api/claims/evidence-conflicts/history` — append-only diagnostic history\n- `POST /api/episodes/reconcile` — compare two stored episodes and optionally record a reviewer assessment\n- `GET /api/episodes/reconciliations` — retrieve append-only reconciliation history — retrieves ranked passages for a claim.
- `POST /api/claims/evidence-links/confirm` — records a reviewer-assigned direction for a specific passage.
- `GET /api/claims/evidence-links` — lists append-only confirmed links.
- `POST /api/answer/orchestrate/linked` — passes exact-text claims' reviewer-confirmed links into the v2.0 orchestrator.

### Candidate request
```json
{
  "project": "default",
  "claim": "The intervention reduced the measured outcome.",
  "limit": 8
}
```

Candidate results carry the chunk/document IDs, passage text, source metadata, lexical relevance score and matched terms. They always begin with `CANDIDATE_REQUIRES_REVIEW` and `direction: null`.

### Confirmation request
```json
{
  "project": "default",
  "claim": "The intervention reduced the measured outcome.",
  "chunk_id": "CHUNK_ID_FROM_CANDIDATE",
  "direction": "SUPPORTS",
  "reviewer": "Reviewer 1",
  "rationale": "The passage reports the measured outcome."
}
```

Directions must be one of `SUPPORTS`, `CONTRADICTS`, `NEUTRAL`, or `INDETERMINATE`.
The API verifies that the chunk belongs to the requested project and stores a new
append-only link. Repeated reviews of the same passage use the stable chunk ID as
the evidence identity, so they cannot inflate the distinct-passage count. Conflicting
directions for the same passage are not silently reconciled; they are rejected by
the downstream appraisal for human resolution.

### Integration behavior
The linked orchestrator matches reviewer-confirmed links to extracted candidate
claims by exact claim text. Unmatched text is not silently linked. If a draft is
edited after review, the new text must be reviewed again.

### Boundaries
- Retrieval is lexical in this endpoint and returns relevance candidates only.
- It does not infer entailment, support, contradiction, or truth.
- Reviewer direction is a recorded appraisal input, not independent validation.
- Different chunks or document IDs do not prove independent sources.
- Source metadata and source-group hints remain unverified.
- The endpoint does not fetch external URLs or perform live web research.


## v2.2.0 — Provisional Semantic Evidence Relationship Analysis

This release adds `POST /api/claims/evidence-analyze`. It compares a claim with project-scoped document passages and returns provisional labels: `POTENTIAL_SUPPORT`, `POTENTIAL_CONTRADICTION` (reserved for future validated analysis; not emitted by the current conservative heuristic), `TOPIC_RELEVANT_ONLY`, `INSUFFICIENT_MATCH`, or `AMBIGUOUS`.

The analysis uses lexical overlap, negation mismatch checks, contrast cues, and optional stored embedding similarity when an embedding provider is configured. It returns source metadata, retrieval signals, shared terms, explanation, and an explicit review requirement. Similarity is not entailment. The current heuristic deliberately does not infer a confirmed contradiction from negation alone.

**Governance boundary:** provisional labels are never written to reviewer-confirmed evidence links and are never supplied to claim appraisal. The existing v2.1 workflow remains the only route for a reviewer to confirm `SUPPORTS`, `CONTRADICTS`, `NEUTRAL`, or `INDETERMINATE`. No model parameters are updated.

### v2.2.0 limitations
- No natural-language-inference (NLI) model is bundled; relationship suggestions are heuristic and provisional.
- Optional embedding similarity depends on a separately configured provider and stored vectors; if unavailable, analysis falls back to lexical signals.
- Semantic similarity, shared vocabulary, and negation cues cannot establish factual support or contradiction.
- Source independence, authority, truth, and methodological quality are not verified.


## v2.3.0 — Evidence Conflict and Dependency Diagnostics

This release adds two endpoints:

- `POST /api/claims/evidence-conflicts` — compares reviewer-confirmed directions for an exact claim and identifies mixed support/contradiction, conflicting directions assigned to the same passage, possible source-dependency clusters, and stale/missing source metadata.
- `GET /api/claims/evidence-conflicts/history` — retrieves append-only diagnostic snapshots by project and optionally exact claim.

The analysis counts distinct passages rather than repeated review events. `NEUTRAL` and `INDETERMINATE` remain separate and are not forced into support or contradiction. Possible dependency clusters are based on shared document IDs, exact source URIs, or user-supplied source-group hints.

**Governance boundary:** the engine never selects a winner, never certifies source independence, and never infers reviewer directions. Staleness is a review flag, not automatic rejection. Legacy evidence-relation records are not joined to document/chunk links because their identifier domains do not match.


## v2.4.0 — Cross-Episode Evidence Reconciliation

New endpoints:
- `POST /api/episodes/reconcile` — compares two stored episodes in the same project, including exact evidence-reference overlap, prior/current-only references, temporal order, uncertainty/conflict flags, and recorded correction/rejection outcomes.
- `GET /api/episodes/reconciliations` — lists append-only reconciliation snapshots for a project.

Optional reviewer assessments are `CONFIRMS_PRIOR`, `CONTRADICTS_PRIOR`, `REFINES_PRIOR`, and `UNRESOLVED`. When supplied, the assessment is explicitly attributed to the reviewer and rationale. It does not modify either episode.

The comparison is structural. Different answers or evidence identifiers do not prove factual contradiction; shared identifiers do not prove independent corroboration. No automatic factual agreement/contradiction inference, model training, or episode overwrite occurs.


## v2.5.0 — Evidence acquisition and episode lifecycle integration

New end-to-end route:
- `POST /api/trajectory/execute` — starts a fresh episode; retrieves stored passages and historical episodes; qualifies source metadata and temporal/dependency hints; surfaces reviewer-recorded corrections and conflict signals; produces optional connected-model generation or a labelled structured fallback; and stores an append-only lifecycle snapshot.
- `GET /api/trajectory/runs` — retrieves saved lifecycle runs by project.

The lifecycle is `INTAKE → RETRIEVE HISTORY → RETRIEVE DOCUMENTS → QUALIFY → RECONCILE → APPRAISE → GENERATE/FALLBACK → STORE`.

The endpoint deliberately does not infer evidence direction from retrieval similarity, promote candidates to confirmed evidence links, resolve conflicting evidence automatically, or update model parameters. See `RELEASE_NOTES_v2.5.0.md` for details and limitations.


## v2.6.0 — Controlled external evidence acquisition

This release adds user-directed URL retrieval from operator-configured exact HTTPS hostnames. New routes:
- `GET /api/acquisition/status`
- `POST /api/acquisition/fetch`
- `GET /api/acquisition/history`

Fetched text is stored as unverified, project-scoped document material and can be found by the existing retrieval and trajectory lifecycle. Acquisition events are append-only. External acquisition is disabled until the server operator sets `COGNISEEK_FETCH_ALLOWED_DOMAINS` to a comma-separated exact-host allowlist. Redirects are rejected, responses are limited to 1 MB, and only HTML/plain text content types are accepted. See `RELEASE_NOTES_v2.6.0.md` for security limitations.


## v2.7.0 — Evidence Verification and Source Intelligence

See `RELEASE_NOTES_v2.7.0.md`. This release adds provenance-preserving claim candidates, reviewer-confirmed claim-to-passage direction links, claim-level source intelligence reports, and append-only acquisition rechecks/version snapshots. It does not infer evidence direction or certify source independence.


## v2.8.0 — Evidence-Grounded Answer Policy

See `RELEASE_NOTES_v2.8.0.md`. New endpoints:
- `POST /api/answer/ground`
- `GET /api/answer/ground/history`

The grounding layer evaluates each candidate sentence against exact reviewer-confirmed passage links. It preserves conflicting evidence and returns a claim-level evidence ledger. The system never enables an unqualified answer and does not claim calibrated truth probabilities.


## v3.0.0 — Evidence Reliability and Calibration

See `RELEASE_NOTES_v3.0.0.md`. This release adds descriptive source metadata profiles and benchmark metrics (Brier score, log loss, ECE, confusion matrix, accuracy, precision and recall) based on explicitly supplied probabilities and labelled outcomes. It does not invent a source credibility score or train model weights.


## v3.0.0 — Controlled Learning and Adaptation
This release adds provenance-bearing provisional feedback examples, paired baseline-versus-candidate evaluation, regression gates, explicit reviewer decisions, and append-only governance approval records. It does **not** train weights, deploy a candidate, or switch the live model. See `RELEASE_NOTES_v3.0.0.md` for API details and limitations.


## v3.1.0 — Memory-Use Governance
Each new chat request now applies a deterministic policy to retrieved prior episodes before they enter model context. Correction/rejection-marked prior answers are withheld; other historical answers remain explicitly unverified. Every request writes an append-only memory-use audit, available at `GET /api/memory/governance`. See `RELEASE_NOTES_v3.1.0.md`.


## v3.2.0 — Evidence-First Answer Engine
Current project evidence, retrieved document passages, and historical memory now enter the model as explicitly separated context channels. Exact duplicates are reported in a context manifest. Chat answers receive a post-generation claim-level grounding review against reviewer-coded evidence, and the review is stored append-only. Use `POST /api/answer/evidence-first` to review a draft manually and `GET /api/answer/evidence-first/history` to inspect audit records. This review does not automatically rewrite or certify generated text. See `RELEASE_NOTES_v3.2.0.md`.


## v3.3.0 — Contradiction and Temporal Reasoning

- `app/temporal_reasoning.py` adds an append-only evidence-event ledger scoped by project and claim.
- Records event time, episode, evidence/source identifiers, source version, content hash, reviewer-entered direction, appraisal before/after, and rationale.
- Distinguishes first-seen evidence, repeated evidence, changed source snapshots, and unresolved direction disagreement.
- Reviewer-explicit relation hints can record corrections, interpretation changes, missing evidence, or unresolved disagreement without pretending these were automatically discovered.
- `POST /api/temporal/events`, `GET /api/temporal/history`, and `GET /api/temporal/compare`.

**Boundary:** different directions remain unresolved; neither source is selected as correct. Content hashes detect changes in supplied content but do not authenticate sources. Repeated or distinct identifiers do not prove source independence. `INDETERMINATE` remains separate from directional evidence and is not coerced into an update. No model weights are trained or changed.


## v3.4.0 — Evidence Acquisition Intelligence

- `POST /api/acquisition/assess` checks a claim against the project's currently stored document passages and acquisition history.
- `GET /api/acquisition/assessments` returns append-only assessment snapshots.
- Returns `ACQUIRE_EVIDENCE`, `SEEK_CORROBORATION`, or `REVIEW_EXISTING_EVIDENCE` as workflow recommendations.
- Reports acquisition failures, older retrieval snapshots, missing publication-date metadata and source-host hints.
- Suggests candidate search terms and reviewer next steps.

**Boundary:** this layer plans acquisition; it does not automatically search the internet or fetch URLs. Existing user-directed fetching still requires exact HTTPS allowlisting. Candidate retrieval is not evidence support, passage count is not sufficiency, and host diversity does not prove independence.


## v3.5.0 — Controlled Source Discovery

- Optional Tavily Search API integration, configured with server-side `TAVILY_API_KEY`.
- `GET /api/discovery/status`, `POST /api/discovery/search`, `GET /api/discovery/history`.
- Bounded candidate discovery (1–10 results), optional exact-domain filters, HTTPS-only candidate URLs and per-run duplicate URL removal.
- Candidate metadata is append-only and marked `CANDIDATE_REQUIRES_REVIEW`; no evidence direction is assigned.
- Selected URLs must still be fetched separately through the existing exact-HTTPS-allowlisted acquisition endpoint.

**Boundary:** discovery does not fetch full pages, authenticate publishers, verify publication dates, establish source independence, or determine truth. No candidate is automatically promoted into reviewer-confirmed evidence.


## v3.6.0 — Claim-Level Evidence Reasoning

The v3.6.0 release adds an orchestration layer that brings together provisional
claim-to-passage analysis and separately reviewer-confirmed evidence links.

### New API

- `POST /api/reasoning/claim-evidence` — analyse one exact claim against stored
  passages, then report provisional relationships, reviewer-confirmed links,
  same-passage direction conflicts, cross-passage conflict diagnostics and
  claim-level coverage.
- `GET /api/reasoning/claim-evidence/history` — retrieve append-only run snapshots
  by project and optional exact claim.

Provisional relationship labels remain heuristic review prompts. They are never
promoted to reviewer-confirmed directions. Repeated reviews of one passage do not
inflate distinct-passage coverage. Conflicting reviewer directions on the same
passage are surfaced with a null effective direction pending review. `NEUTRAL`
and `INDETERMINATE` remain separate from support/contradiction; indeterminate
evidence remains F4-compatible and is not forced into a directional category.

Coverage counts describe the recorded project corpus. They do not establish
source independence, evidential sufficiency, factual truth, or model confidence.


## v3.7.0 — Evidence-Governed Response Generation

The `/api/chat` path now prepares a claim-evidence assessment for each new request
episode and adds a separate evidence-governance policy channel to the connected
language model's context before generation. The policy distinguishes:
- reviewed directional evidence;
- reviewed neutral/indeterminate evidence;
- provisional passage matches only;
- no matching stored passages;
- mixed or conflicting reviewer-coded evidence.

The generation instructions require the model to preserve conflicts, avoid
presenting provisional matches as support, distinguish `NEUTRAL` from
`INDETERMINATE`, and preserve F4-compatible indeterminate evidence. The policy
assessment and episode linkage are stored append-only.

New endpoint:
- `GET /api/answer/response-policy/history`

This is generation guidance, not an enforcement guarantee. A connected language
model may fail to follow instructions. The existing post-generation grounding
review remains a separate audit and does not certify factual truth or rewrite
the generated answer. The request text is analysed as a retrieval query, not
assumed to be a factual claim.


## v3.8.0 — Independent Verification and Answer Control

This release adds `app/answer_control.py`, a separate advisory decision layer
that runs after draft generation and the existing claim-level grounding review.
It distinguishes the generated draft from reviewer-coded evidence and from
the system's recommended handling of that draft.

Decision outcomes:
- `RELEASE_QUALIFIED`: every extracted candidate claim has `SUPPORTED_FOR_REVIEW`;
  release remains qualified and must retain provenance.
- `WITHHOLD_UNSUPPORTED`: at least one candidate claim has
  `CONTRADICTED_FOR_REVIEW`; do not present that claim as established fact.
- `REVIEW_REQUIRED`: mixed, insufficient, neutral, indeterminate/F4-compatible,
  incomplete, or unavailable review; do not present an unqualified factual answer.

New endpoints:
- `POST /api/answer/control`: ground a supplied draft and return a separate
  advisory answer-control decision.
- `GET /api/answer/control/history`: retrieve project-scoped append-only
  decision records.
- `/api/chat` now returns `answer_control_decision` and
  `answer_control_record` for each episode.

The control layer does not rewrite the model answer, authenticate sources,
infer semantic entailment, establish source independence, or prove truth.
`SUPPORTED_FOR_REVIEW` means only that reviewer-coded passages were recorded
as supporting the exact candidate claim. A decision is an advisory release
recommendation, not a technical publication block. The F4-compatible
`NO_INTERPRETABLE_EVIDENCE` state remains separate and is never converted into
support or contradiction.


## v3.9.0 — Governed Experience-Based Learning

This release adds `app/experience_memory.py`, which connects explicitly reviewed
learning examples to future retrieval without treating experience as current
evidence or verified truth.

Workflow:
1. A learning example is created from an existing appraisal and linked reviewer
   outcome using the existing `/api/learning/examples/build` workflow.
2. A reviewer explicitly approves it for contextual retrieval through
   `POST /api/experience-memory/reviews` with `APPROVE_FOR_CONTEXT`.
3. Future chat episodes retrieve only approved examples with lexical relevance
   to the current request and add them to a separate
   `reviewed_experience_not_evidence` context channel.
4. A later `REVOKE_CONTEXT` review event removes the example from future
   retrieval without deleting or overwriting its history.

New endpoints:
- `POST /api/experience-memory/reviews`
- `GET /api/experience-memory/history`
- `POST /api/experience-memory/retrieve`

The chat response includes `reviewed_experience_memory`, including retrieved
example IDs and an append-only retrieval audit. Unapproved examples are never
retrieved. Project isolation is enforced. Current evidence remains separate
and takes precedence; historical experience is a reasoning precedent only.

This is controlled memory use, not autonomous learning of foundation-model
weights. It does not validate reviewer labels, prove facts, infer source
independence, or generalize learning across domains. Retrieval currently uses
lexical overlap; semantic retrieval is not implemented in this module.


## v4.1.0 — Continuous Episode Learning and Memory Consolidation

COGNISEEK can now prepare a candidate memory record from an episode after a recorded outcome exists. The candidate preserves the original request, response, evidence references and outcome history. It is not an automatically inferred lesson. A reviewer must explicitly approve it for future contextual retrieval. Rejection and revocation remain in the append-only audit history. Approved consolidated experience enters `/api/chat` through a separate historical-context-not-evidence channel. No model weights are updated.


## v4.5.0 — Claim/source verification and safe decision execution

- Append-only, project-scoped claim/source review events tied to exact stored passage IDs.
- Review states separate topical relevance from evidence direction:
  - `REVIEWED_RELEVANT` and `REVIEWED_NOT_RELEVANT` do not assign a direction.
  - `REVIEWED_SUPPORTS`, `REVIEWED_CONTRADICTS`, `REVIEWED_NEUTRAL`, and `REVIEWED_INDETERMINATE` preserve reviewer-entered distinctions.
  - `CANDIDATE_REQUIRES_REVIEW` remains provisional.
- Conflicting reviews for the same passage are preserved as separate events; no winner is selected.
- Safe internal execution of acquisition plans with exact project/plan/action matching.
- External acquisition plans cannot be executed through this endpoint; live discovery/fetch remains a separate, controlled workflow.

See `RELEASE_NOTES_v4.5.0.md` for API and safety details.


## v4.6.0 — Reviewer disagreement and consensus reporting

- Transparent consensus report over exact project-scoped target claims.
- One latest assessment per distinct reviewer is used for the current agreement calculation; earlier events remain preserved in the report.
- Repeated submissions by one reviewer do not inflate the reviewer count.
- Unanimous directional agreement is reported only when the minimum distinct reviewer count is met and all counted reviewers agree.
- Majority opinion never overrides a minority assessment. Any directional disagreement returns `UNRESOLVED_REVIEWER_DISAGREEMENT` with no consensus direction.
- `NEUTRAL` and `INDETERMINATE` remain distinct; relevance-only labels never count as evidence direction.
- Same-passage conflicts and reviewers who changed their assessments are surfaced.
- Consensus report snapshots are append-only.

See `RELEASE_NOTES_v4.6.0.md` for API and interpretation details.


## v4.7.0 — Evidence dependency and corroboration intelligence

- Candidate-level dependency diagnostics across exact document IDs, source URIs, content hashes, and user-supplied source-group hints.
- Shared publisher is displayed as context, not automatically treated as dependency.
- Reviewer-declared candidate relationships: `DERIVED_FROM`, `DUPLICATES`, `CITES`, `SHARES_DATASET`, and `SAME_ORIGIN`.
- Every declared relationship requires a reviewer and rationale and is stored as an append-only event.
- Claim-focused corroboration reports identify potential shared-origin signals and distinguish them from no detected signal.
- Append-only project-scoped corroboration report history.

See `RELEASE_NOTES_v4.7.0.md` for API and interpretation details.


## v4.8.0 — Evidence Quality and Methodological Appraisal

- Project-scoped, append-only methodological appraisals tied to exact stored passage (`candidate_id`) records.
- Separate fields for study-design description and reviewer assessment of design fit.
- Structured capture of population, sample size, measurement methods, bias risks and limitations.
- Replication status distinguishes not reported, author-claimed replication, reviewer-recorded independent replication, reviewer-recorded absence of independent replication, and unclear.
- Claim-scope relation is a separate reviewer-entered category: `DIRECTLY_ADDRESSES`, `PARTIALLY_ADDRESSES`, `DOES_NOT_ADDRESS`, `UNCLEAR`.
- Multiple reviewers and conflicting appraisals are preserved. Reports use each reviewer's latest assessment for a candidate while retaining all earlier events.
- Append-only project-scoped report history.


## v4.9.0 — Evidence Synthesis and Cross-Study Comparison

- Compare 1–100 exact project-scoped candidate passage IDs against one target claim.
- Display study/source metadata alongside reviewer-coded evidence states.
- Summarize latest distinct reviewer assessments per candidate while retaining all earlier review events in their original append-only tables.
- Preserve within-study reviewer disagreement and across-study directional variation.
- Compare recorded study-design descriptions, populations, sample sizes, measurement methods, replication statuses, and claim-scope relations.
- Flag candidates without evidence review or methodological appraisal; absence is not treated as negative evidence.
- Store project-scoped append-only synthesis reports.


## v5.0.0 — Evidence-Grounded Synthesis and Answer Generation

- Render an existing project-scoped cross-study report into a readable study-by-study synthesis.
- Include candidate/document identifiers, source metadata, reviewer-coded directions, methodological scope, study design, population, sample size, measurement methods, replication status, and disagreements when available.
- Explicitly report missing evidence reviews and missing methodological appraisals without treating absence as contradiction.
- Preserve source candidate references in a structured provenance array.
- Ground the target claim against the existing exact-text reviewer-coded evidence ledger.
- Attach the existing advisory answer-control decision and append-only decision record.
- Store answer renderings in project-scoped history.

## API
- `POST /api/synthesis/answer`
- `GET /api/synthesis/answer/history`


## v5.1.0 — Structured Findings Extraction

Adds a project-scoped, passage-grounded structured findings ledger.

- Create a finding candidate against an exact stored `document_chunks.chunk_id`.
- Record intervention, comparator, outcome, effect measure, estimate, confidence interval, p-value, population, follow-up, sample size, events, denominator, units and directionality when reported.
- Preserve exact quoted excerpt, passage offsets, document ID and chunk ID.
- Missing values remain omitted; the service does not infer or fill them.
- Candidates remain `CANDIDATE_REQUIRES_REVIEW`.
- Append-only reviewer actions: `APPROVE`, `REJECT`, `CORRECT`; reviewer and rationale required.
- Compare only findings with latest reviewer actions unanimously `APPROVE`; unresolved disagreement/correction states remain visible.
- Stratify by outcome, effect measure, population, follow-up, units and comparator. Incompatible strata remain separate.
- Validates numeric fields, p-values, counts, ratio measures and confidence interval ordering.
- APIs: `POST/GET /api/findings/candidates`, `POST/GET /api/findings/reviews`, `POST /api/findings/compare`.

Important limitations: values are submitted by the caller/reviewer, not automatically extracted from prose. Exact excerpt matching proves only that the quoted text occurs at the recorded offsets; it does not prove that the structured interpretation is correct. Review approval is a workflow state, not factual truth. No pooled effect, meta-analysis, source-independence certification or causal conclusion is produced.


## v5.2.0 Statistical Evidence Intelligence
See `RELEASE_NOTES_v5.2.0.md` for the statistical analysis layer and its limitations.


## v5.3.0 Cross-Study Statistical Comparability
See `RELEASE_NOTES_v5.3.0.md` for the pairwise compatibility screen, statuses, API routes and limitations.


## v5.4.0 Evidence Synthesis Intelligence
See `RELEASE_NOTES_v5.4.0.md` for integration scope, APIs and limitations.


## v5.5.0 Evidence-Grounded Response Integration
See `RELEASE_NOTES_v5.5.0.md` for response generation, provenance, APIs and limitations.


## v5.6.0 Evidence and Governance Audit Intelligence
See `RELEASE_NOTES_v5.6.0.md` for audit snapshots, detected changes, API and limitations.


## v5.7.0 — End-to-End Research Intelligence Validation

This release adds a read-only validation pass across selected research lifecycle
records. It checks project-scoped finding IDs, exact source-passage provenance,
latest reviewer workflow state, and optional references to synthesis, response,
and governance-audit records. Optional stages not selected are explicitly marked
`NOT_CHECKED`; they are never silently treated as successful.

API:
- `POST /api/research-validation/end-to-end`
- `GET /api/research-validation/reports?project=default&limit=100`
- `GET /api/research-validation/reports/{report_id}?project=default`

The report status is `BLOCKED`, `WARNING`, `PASS`, or `NOT_CHECKED`, with
`BLOCKED` taking precedence over warnings. The validator does not modify source
evidence, finding candidates, reviewer actions, synthesis reports, integrated
responses, or governance audits. Only the validation report is appended.

A `PASS` means the selected lifecycle linkage checks passed; it does not prove
scientific truth, source authenticity, study quality, causality, or model accuracy.
This remains a research-engine prototype, not a trained foundation model.


## v5.8.0 — Integrated Evidence Intelligence System

This release coordinates the existing statistical evidence, cross-study
comparability, evidence synthesis, evidence-grounded response, governance audit,
and end-to-end validation modules in a single ordered workflow.

API:
- `POST /api/evidence-intelligence/workflows/run`
- `GET /api/evidence-intelligence/workflows?project=default&limit=100`
- `GET /api/evidence-intelligence/workflows/{workflow_id}?project=default`

The workflow stores references to each specialist report and the stage outcome.
A failed stage is recorded; dependent stages are not silently marked complete.
The workflow can optionally skip the governance audit. Each specialist module
continues to retain its own report and history.

This is orchestration, not a new reasoning model. It does not pool effects,
perform meta-analysis, modify reviewer decisions, train model weights, or
determine scientific truth.


## v5.9.0 — Company Policy and Output Governance

v5.9.0 is the final planned v5.x milestone. It adds project-scoped policy revisions,
separated author/approver/activator actions, policy hashes, and append-only output
release decisions over integrated evidence workflows.

### Company governance API
- `POST /api/company-governance/policies/draft`
- `POST /api/company-governance/policies/{policy_id}/approve`
- `POST /api/company-governance/policies/{policy_id}/activate`
- `GET /api/company-governance/policies?project=...`
- `GET /api/company-governance/policies/{policy_id}?project=...`
- `POST /api/company-governance/output-decisions/evaluate`
- `GET /api/company-governance/output-decisions?project=...`
- `GET /api/company-governance/output-decisions/{decision_id}?project=...`

The baseline policy is restrictive: it requires latest unanimous finding approval,
an end-to-end validation PASS, a governance audit reference, provenance/limitations,
and one or more reviewers. The company may create a project-specific draft, but
activation requires approval by someone other than the author and activation by a
third distinct actor. Supported output modes are explicitly allowlisted.

**Security boundary:** `actor` and `role` are caller-supplied demonstration claims.
This prototype does not authenticate identities or provide production-grade RBAC.
Before production use, integrate a trusted identity provider, server-enforced
authorization, signed approvals, secure secret handling, and tamper-evident external
audit storage. SQLite append-only application records are not immutable against a
database administrator or attacker with write access.

Company policy governs permission to release an output; it cannot convert
unsupported evidence into supported evidence, bypass source/provenance validation,
or establish scientific truth. An ALLOW decision is a release-policy result only.


## Current release: v6.3.0

Evidence Interpretation and Reviewer Appraisal Integration. See `RELEASE_NOTES_v6.3.0.md` and `TEST_RESULTS_v6.3.0.txt`. The full regression suite reports 389 passing tests.


## Current release: v6.4.0

Evidence Conflict and Sufficiency Diagnostics. See `RELEASE_NOTES_v6.4.0.md` and `TEST_RESULTS_v6.4.0.txt`. Clean-database full regression: 395 passed.


## Current release: v6.5.0

Source Dependency and Lineage Diagnostics. See `RELEASE_NOTES_v6.5.0.md` and `TEST_RESULTS_v6.5.0.txt`. Full clean-database regression: 401 passed.


## v6.6.0 — Methodological reliability
This release adds append-only reviewer appraisals of study methods and risk-of-bias domains. It preserves missing information and reviewer disagreement, and deliberately does not assign automatic quality or certainty grades. See `RELEASE_NOTES_v6.6.0.md`.


## v6.7.0 — Evidence calibration
Adds a prediction/outcome ledger, explicit abstention records, and descriptive Brier score, log loss, expected calibration error, label accuracy, outcome coverage, and abstention-rate diagnostics. It does not automatically retrain the model or establish general reliability. See `RELEASE_NOTES_v6.7.0.md`.


## v6.8.0 — Temporal knowledge reconciliation
Adds time-bounded assertions, overlap diagnostics, append-only reviewer reconciliation events, and as-of knowledge views. New information does not silently overwrite historical claims. See `RELEASE_NOTES_v6.8.0.md`.


## v6.9.0 — Controlled cross-episode memory consolidation
Adds a provenance-preserving candidate memory workflow from episode outcomes. Candidate creation is separate from reviewer approval; only approved candidates enter persistent reviewed memory. This is application-memory learning, not LLM weight training. See `RELEASE_NOTES_v6.9.0.md`.


## v7.0.0 — Unified Cognitive Learning Cycle
Adds three cycle endpoints connecting request-side runtime processing, outcome recording, candidate memory generation, reviewer approval, and cycle-state inspection. Response release remains governed by the existing separate evidence workflow and policy gate. See `RELEASE_NOTES_v7.0.0.md`.


## v7.1.0 — Evidence-to-Answer Integration
Adds a one-call orchestration endpoint connecting a new request episode, the existing integrated evidence-intelligence workflow, company-policy evaluation, and governed response release. It operates on pre-existing finding IDs; source acquisition remains a separate upstream workflow. See `RELEASE_NOTES_v7.1.0.md`.


## v8.6.0 — Cross-Episode Learning Evaluation
The new cross-episode evaluation endpoint measures repeated patterns across
applications of consolidated experience. It is descriptive, project-scoped,
and read-only. It does not prove causation or update model weights.
See `RELEASE_NOTES_v8.6.0.md`.


## v8.7.0 — Adaptive Learning Policy
Read-only policy layer for governing contextual reuse based on cross-episode patterns. See `RELEASE_NOTES_v8.7.0.md`.


## v8.8.0 — Governed Learning Feedback Loop
Episode-scoped policy-governed experience application with append-only candidate dispositions. See `RELEASE_NOTES_v8.8.0.md`.


## v8.9.0 — Evidence-Governed Learning and Outcome Integration

- Records caller/appraiser-supplied evidence direction against an exact v8.8 governed application and candidate.
- Requires evidence references for SUPPORTS, CONTRADICTS, and NEUTRAL appraisals; INDETERMINATE and UNAPPRAISED may be recorded without refs.
- Preserves M-RBAM F4 for INDETERMINATE; UNAPPRAISED remains a separate state. No numeric zero is substituted for undefined appraisal update.
- Adds a separate append-only reviewer decision gate; only the latest ACCEPT_FOR_LEARNING_REVIEW is marked eligible for supervised feedback.
- No evidence authentication, automatic truth label, automatic memory mutation, model-weight update, answer release, or action authorization.

### v8.9 APIs

- `POST /api/cognitive-runtime/learning/evidence-appraisals`
- `POST /api/cognitive-runtime/learning/evidence-appraisals/review`
- `GET /api/cognitive-runtime/learning/evidence-appraisals?project=default&application_id=...&episode_id=...&limit=100`

Direction values: `SUPPORTS`, `CONTRADICTS`, `NEUTRAL`, `INDETERMINATE`, `UNAPPRAISED`.


## v9.1.0 — Unified Cognitive Decision Cycle

Coordinates the existing request-episode runtime, adaptive memory retrieval, governed experience application, evidence qualification, and memory/evidence reconciliation in one auditable cycle. It creates a fresh episode and retrieves historical memory before episode creation so the new request cannot retrieve itself.

### API
- `POST /api/cognitive-runtime/decision-cycles`
- `GET /api/cognitive-runtime/decision-cycles/{cycle_id}?project=default`
- `GET /api/cognitive-runtime/decision-cycles?project=default&limit=50`

The POST body accepts `project`, `request`, `evidence`, optional `actor`, `memory_limit`, `experience_limit`, and optional paired `a_pre`/`a_post`. Evidence items require `reference`, `summary`, and caller-supplied `direction` (-1, 0, +1).

### Boundaries
The cycle coordinates modules; it does not generate or release answers, authenticate evidence or reviewer identities, perform external acquisition, update model weights, mutate memory, or authorize execution. Direction 0 remains indeterminate (M-RBAM F4); it is not converted into a numeric zero appraisal update.


## v9.1.0 — Evidence-Grounded Answer and Release Bridge

`POST /api/cognitive-runtime/answer-release-bridges` links a v9.0 decision cycle to an existing integrated evidence workflow. It requires exact equality between the cycle's current evidence references and the workflow's selected finding IDs, then evaluates company output policy. A BLOCK decision withholds the response. Historical memory is never used as answer evidence; the bridge does not authenticate identity, establish truth, update model weights, or authorize execution.


## v9.2.0 — Episode-Linked Evidence Acquisition Orchestration

The new acquisition orchestration connects a v9.0 decision cycle to the existing acquisition coverage assessor, adaptive acquisition planner, source discovery and controlled URL acquisition modules.

- `POST /api/cognitive-runtime/acquisition-orchestrations`
- `GET /api/cognitive-runtime/acquisition-orchestrations`
- `GET /api/cognitive-runtime/acquisition-orchestrations/{orchestration_id}`

Planning is the default. External execution requires both `allow_external=true` and `execute_external=true`, plus the server-side `COGNISEEK_FETCH_ALLOWED_DOMAINS` exact HTTPS allowlist. Acquired material remains unappraised (D=0). This feature does not authenticate publishers, prove source independence, determine truth, release answers or authorize operational execution.


## v9.3.0 — Evidence Verification and Independent Source Appraisal
Adds reviewer-controlled claim-to-passage verification records linked to v9.2 acquisition episodes. It preserves conflicting directions, records validation states and provisional dependency hints, and does not automatically infer evidence direction, source independence, truth, answer release or execution permission. See `RELEASE_NOTES_v9.3.0.md`.


## v9.4.0 — Episode-Linked Corroboration and Source-Origin Assessment
Joins approved, valid v9.3 reviewer assessments to the existing source dependency engine. It produces append-only, claim- and episode-scoped diagnostics while keeping reviewer direction separate from source independence. See `RELEASE_NOTES_v9.4.0.md`.


## v9.6.0 — Reviewer-Defined Claim Coverage
Adds episode-linked claim aspect coverage assessment. Reviewers define the aspects of a claim and classify each as covered, partially covered, not covered or indeterminate, mapping coverage to candidates from the linked v9.4 corroboration assessment. Coverage is descriptive and does not certify truth or sufficiency. See `RELEASE_NOTES_v9.6.0.md`.


## v9.6.0 — Evidence Sufficiency Decision Engine

See `RELEASE_NOTES_v9.6.0.md`. New APIs: `POST/GET /api/cognitive-runtime/sufficiency-decisions`. The engine creates transparent, append-only review profiles and never certifies truth or releases answers.


## v9.7.0 — Decision-to-Answer Governance Bridge

See `RELEASE_NOTES_v9.7.0.md`. New endpoints: `POST/GET /api/cognitive-runtime/answer-packages`. Packages are prepared only when a v9.6 decision and the exact reviewer-grounded claim ledger align; preparation is not release.


## v9.8.0 — End-to-End Cognitive Evaluation

This release adds transparent, append-only lifecycle evaluation. It checks the project-scoped links among a v9.0 decision cycle, optional v9.6 sufficiency decision, and optional v9.7 answer-preparation package. Every check is reported separately as `PASS`, `FAIL`, or `NOT_TESTED`; unavailable lifecycle stages are never silently counted as passed.

Endpoints:
- `POST /api/cognitive-runtime/end-to-end-evaluations` — evaluate a cycle and optional linked decision/package. Example body: `{"project":"research","cycle_id":"<cycle-id>","decision_id":"<decision-id>","package_id":"<package-id>"}`.
- `GET /api/cognitive-runtime/end-to-end-evaluations?project=research&cycle_id=<cycle-id>` — list evaluation snapshots.

A PASS is only a recorded linkage/control check, not a truth, intelligence, or security certification. External source authentication, company-policy release, publication, real-world execution and model-weight updates remain outside this lifecycle.


## v9.9.0 — Security and Operational Hardening

Optional API bearer authentication is enabled by setting `COGNISEEK_API_KEY` on the server (minimum 32 characters). API requests then require `Authorization: Bearer <key>`. The middleware also applies a per-process request rate limit (`COGNISEEK_RATE_LIMIT_PER_MINUTE`, default 1000), a declared content-length limit (`COGNISEEK_MAX_REQUEST_BYTES`, default 1 MiB), and response security headers. `/health` remains available without the API key for health checks.

This is a baseline, not a complete production security system. The shared key does not provide user accounts or project-level authorization. The rate limiter is process-local, and the body-size check relies on Content-Length. Deploy behind TLS and a reverse proxy with hard request limits; add identity/roles, per-project authorization, shared rate limiting, secure secret management, database protection, backups and independent security testing before handling sensitive production data.


## v10.0.0 Integrated Release Assessment

Run `GET /api/release/assessment` for a read-only report of module discoverability,
SQLite integrity, selected security configuration, implemented/partial capabilities,
and explicit `NOT_TESTED` lifecycle areas. The assessment does not generate answers,
fetch external sources, authorize release, or claim production readiness. See
`RELEASE_NOTES_v10.0.0.md`.


## v10.4.0 Request Lifecycle Architecture Map

Use `GET /api/architecture/lifecycle` to inspect the major request stages and their
implemented/partial status. This is a static source-tree inventory, not proof that
every request traverses every stage. See `RELEASE_NOTES_v10.4.0.md`.


## v10.4.0 — Unified Request Execution Pipeline

The `POST /api/requests/execute` endpoint creates a new request episode and
coordinates the existing unified decision cycle. It records project-scoped,
append-only stage events. Retrieve a trace with
`GET /api/requests/{request_id}/trace?project=default`; list records with
`GET /api/requests/history?project=default`.

The pipeline is intentionally fail-closed. It does not perform external
acquisition, invoke a language model, verify generated claims, authorize
actions, or release an answer. Its current status is `PREPARED_NOT_RELEASED`.
Caller-supplied evidence references and directions are not authenticated.


## v10.4.0 — Claim Review and Governed Release Gate Integration

The request execution endpoint accepts optional `draft_answer`, `claim_reviews`, and
`min_distinct_records` fields. When a draft is supplied, COGNISEEK runs the existing
claim-aware review engine, records an advisory answer-control decision, and appends
three trace stages: claim-level review, advisory answer control, and governed
publication. Reviewer/caller-supplied evidence directions remain judgments, not
authenticated truth. Even a `RELEASE_QUALIFIED` advisory result does not publish
the answer: the release gate remains closed because this pipeline does not establish
the separate company-policy workflow or authenticated actor/role.


## v10.9.0 — Experience trajectory evaluation

Adds project-scoped descriptive evaluation of reviewed experience feedback, consolidation decisions, execution outcomes, generation-run statuses, and cross-episode appraisal trajectories. This is observational reporting only; it does not train model weights, promote memories, determine truth, or change retrieval policy. See `RELEASE_NOTES_v10.9.0.md`.


## v11.0.0 — Integrated cognitive runtime

Adds a request-level orchestrator joining fresh episode creation, historical episode retrieval, explicit source acquisition, passage retrieval, structured generation, provisional semantic review and append-only lifecycle history. Historical memory remains context only; retrieved passages remain unappraised until reviewed; answer release remains withheld pending the existing evidence workflow and company-policy controls. See `RELEASE_NOTES_v11.0.0.md`.


## v11.1.0 — End-to-End Episode Review Completion

Adds integrated-run human appraisal linkage, review coverage/status, append-only review history, and completion checks. Existing M-RBAM mathematics and protocol selection are preserved unchanged. Review completion does not authorize answer release. See `RELEASE_NOTES_v11.1.0.md`, `TEST_PLAN_v11.1.0.md`, and `TEST_RESULTS_v11.1.0.txt`.


## v11.2.0 — Governed Answer Assembly and Release Integration

Adds strict linkage from the v11.1 integrated request and review lifecycle to the existing decision-cycle, evidence-intelligence workflow, answer-release bridge, and company-policy governance engine. Incomplete review and unresolved reviewer disagreement block release attempts. Existing M-RBAM mathematics and protocol implementation remain unchanged. Review completion does not automatically release an answer. See `RELEASE_NOTES_v11.2.0.md`, `TEST_PLAN_v11.2.0.md`, and `TEST_RESULTS_v11.2.0.txt`.


## v11.3.0 — Persistent Experience and Memory Lifecycle

Adds a project-scoped append-only lifecycle controller for adaptive memory retrieval, outcome-linked consolidation candidate preparation, and reviewer approval/rejection/revocation. Existing retrieval ranking and consolidation engines remain authoritative. Historical memory remains context, never current evidence. No model-weight training is added. See the v11.3.0 release notes and test records.


## v11.4.0 — Multi-User Identity, Permissions and Security

Adds OIDC/JWT authenticated authorization for selected governed-release and memory-lifecycle routes, signed project membership checks, role gates, and an append-only authorization audit. Caller-supplied actor/role values are not accepted as authority on these routes. This is a scoped security increment, not a complete application-wide security certification. See the v11.4.0 release notes and test records.


## v12.1.0 — Evidence, Memory, Learning and Episode Route Review

This release adds a read-only semantic source review for the first API route
batch covering evidence, memory, learning and episodes. It records handler
names, method/path pairs, source lines, visible parameters, explicit
authorization-helper calls, and duplicate declarations.

The report intentionally does **not** equate a `project` parameter or an
`authorization` parameter with enforced authorization. Payload-based routes
remain blocked for ownership and downstream data-access review. No endpoint
behavior is changed and no route is declared public or secure.

Generate the report with:

```bash
python scripts/build_route_semantic_review.py
```

See `RELEASE_NOTES_v12.1.0.md`, `TEST_PLAN_v12.1.0.md`, and
`ROUTE_SEMANTIC_REVIEW_v12.1.0.json`.


## v12.2.0 — Evidence and Reviewed-Memory Authorization

The evidence collection (`GET/POST /api/evidence`) and reviewed-memory
collection (`GET/POST /api/memory/items`) now enforce the existing signed
identity boundary, project membership, and explicit route-role policies.

Read access is available to ADMIN, REVIEWER, OPERATOR, and VIEWER roles.
Write access is limited to ADMIN and OPERATOR. The authorization boundary
rechecks project membership and records allow/deny outcomes. Requests without
a valid bearer token are rejected. Cross-project access is denied even when
the caller presents a valid token for another project.

This milestone protects these four routes only; it does not certify the
remaining evidence, memory, learning, or episode API families. See
`RELEASE_NOTES_v12.2.0.md` and `ROUTE_GOVERNANCE_REGISTER.json`.


## v12.3.0 — Episode and Learning Route Authorization

This release adds signed identity, project membership, and role checks to
selected episode-history/retrieval/outcome/reconciliation routes and
learning-appraisal/outcome/evaluation routes. Read access is separated from
operator writes and reviewer decisions. See `RELEASE_NOTES_v12.3.0.md`.
