# COGNISEEK TLM v10.7.0 — Semantic Claim Verification

## Scope
Adds model-assisted semantic assessment of a target claim against a bounded set of supplied evidence passages. Builds on v10.6.0 provenance records and preserves the earlier reviewer-confirmed claim-evidence workflow.

## New API
- `GET /api/semantic-verification/status`
- `POST /api/semantic-verification/claims`
- `GET /api/semantic-verification/history`

## Request example
```json
{
  "project": "default",
  "claim": "The system passed the test.",
  "passages": [
    {
      "evidence_id": "passage-001",
      "text": "The system passed the test on the validation run.",
      "source_name": "Validation report",
      "source_uri": "https://example.org/report"
    }
  ]
}
```

## Implemented behavior
- Calls the configured OpenAI-compatible model endpoint using `OPENAI_API_KEY`, `MODEL_NAME`, and optional `MODEL_BASE_URL`.
- Requests one passage-level relation per supplied evidence ID: SUPPORTS, CONTRADICTS, NEUTRAL, or INDETERMINATE.
- Accepts only evidence IDs supplied in the request; unknown or duplicate IDs from model output are discarded.
- Missing model assessments are recorded as INDETERMINATE.
- Retains a quoted span only when it is an exact substring of the supplied passage.
- Preserves mixed support/contradiction and indeterminate outcomes.
- Stores append-only, project-scoped review records.

## Interpretation and limitations
- This is model-assisted semantic interpretation, not factual truth verification.
- Model outputs are provisional and require human review.
- It does not establish source authenticity, publication date, methodological quality, source independence, or factual accuracy.
- Model errors may arise from negation, scope, causality, temporal context, ambiguity, or omitted context.
- No confidence probability is generated.
- If the model is not configured or its provider fails, the endpoint fails closed rather than inventing a result.
