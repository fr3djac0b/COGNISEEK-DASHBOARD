# COGNISEEK TLM v2.5.0 — Evidence Acquisition and Episode Lifecycle Integration

## What changed

This release adds an end-to-end lifecycle route that connects existing retrieval, episodic memory, evidence qualification, reconciliation signals, appraisal boundaries, optional generation, and append-only storage.

### New API

- `POST /api/trajectory/execute`
  - Starts a new request episode.
  - Retrieves relevant stored document passages and potentially relevant prior episodes within the requested project.
  - Retrieves project evidence records and recorded evidence relationships.
  - Qualifies metadata, publication dates, duplicate/dependency hints, and missing fields.
  - Surfaces prior reviewer-recorded corrections/rejections.
  - Reports mixed stored `supports` / `contradicts` labels as a conflict signal.
  - Produces a connected-model answer when configured and requested; otherwise returns a clearly labelled structured fallback.
  - Stores a new episode and an append-only lifecycle snapshot.
- `GET /api/trajectory/runs`
  - Retrieves saved lifecycle snapshots by project.

### Lifecycle

`INTAKE → RETRIEVE HISTORY → RETRIEVE DOCUMENTS → QUALIFY → RECONCILE → APPRAISE → GENERATE / FALLBACK → STORE`

### Governance boundaries

- Retrieval relevance is not evidential support, authority, accuracy, or truth.
- Similarity never promotes a passage to a reviewer-confirmed evidence link.
- Existing status labels are reported as stored; the lifecycle does not infer direction from text.
- A mixture of recorded supporting and contradicting statuses is a conflict signal, not a winner-selection mechanism.
- Historical answers remain unverified; recorded corrections are surfaced for review.
- Metadata completeness and date flags are diagnostics, not source-quality scores.
- Source groups are dependency hints; source independence is not certified.
- No model parameters are trained or updated.
- No autonomous web acquisition is implemented.
- The new endpoint does not replace or alter the existing `/api/chat` behavior.

## Verification

- Automated tests: **120 passed, 0 failed**.
- New v2.5 tests cover new episode creation, empty-evidence fallback, project isolation, conflict signalling, correction-aware history, and API execution/history.
- Python compilation and ZIP integrity are checked in `TEST_RESULTS_v2.5.0.txt`.

## Not yet implemented / not claimed

- Live external web search, source authentication, DOI/publisher verification, or citation-chain validation.
- Automated factual claim adjudication or calibrated confidence.
- Automatic semantic contradiction inference or source independence certification.
- Authentication, per-user authorization, or production security hardening.
- Live model-provider verification in this release.
- Foundation-model pretraining or automatic weight updates.
