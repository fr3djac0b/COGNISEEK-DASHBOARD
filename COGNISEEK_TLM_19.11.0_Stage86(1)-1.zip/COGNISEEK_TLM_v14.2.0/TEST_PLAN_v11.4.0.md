# v11.4.0 Test Plan

1. Verified project member with required role is allowed.
2. Authenticated principal missing the required role is denied and audited.
3. Project membership mismatch is denied and audited.
4. Missing bearer token fails closed.
5. OIDC configuration failure fails closed.
6. ADMIN satisfies lower privilege gates.
7. Invalid role requirements are rejected.
8. Authorization history is project-scoped.
9. The protected release and memory routes require authenticated principals and trusted roles.
10. The identity audit endpoint is registered and restricted to ADMIN.
11. Full inherited regression suite runs with a fresh isolated database.
12. Python compileall and FastAPI import pass.
13. Seven v11.4-related routes are registered.
14. Verify M-RBAM mathematics source remains byte-for-byte unchanged.
15. Verify release archive integrity and manifest.
