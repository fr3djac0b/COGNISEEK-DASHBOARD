# COGNISEEK TLM v17.3.0 — Release Notes

Stage 58 adds paired learning validation and adaptive reasoning evaluation.

- Paired baseline-versus-treatment comparisons.
- Bounded scores and evidence provenance subset checks.
- Duplicate scenario prevention.
- Conservative screening based on minimum trial count, mean uplift and harmful regressions.
- Human release-review record; no automatic live reasoning activation.
- 18 focused tests.

The v17.2.0 baseline is preserved byte-for-byte.
