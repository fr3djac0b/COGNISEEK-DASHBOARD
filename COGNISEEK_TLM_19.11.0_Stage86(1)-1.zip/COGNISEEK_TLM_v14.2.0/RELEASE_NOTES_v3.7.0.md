# COGNISEEK TLM v3.7.0 — Evidence-Governed Response Generation

## Delivered
- New `app/response_policy.py`.
- Every `/api/chat` episode prepares a claim-evidence assessment from the current
  project corpus before model generation.
- Adds a dedicated `generation_guidance_not_evidence` context channel to the
  model input, separate from current project evidence, retrieved passages and
  historical memory.
- Policy modes distinguish reviewed directional evidence, reviewed
  non-directional evidence, provisional passages only, no retrieved passages,
  and conflicting reviewed evidence.
- Preserves reviewer conflicts and the distinction between `NEUTRAL` and
  `INDETERMINATE`; indeterminate remains F4-compatible.
- Append-only policy audit linked to the created episode.
- New `GET /api/answer/response-policy/history` endpoint.

## Boundaries
- Generation policy is an instruction/context layer, not a hard enforcement
  mechanism. A language model may fail to comply.
- The post-generation grounding review remains separate and does not certify
  truth or automatically rewrite an answer.
- The user's question is used as a retrieval query; it is not presumed to be a
  factual claim.
- No automatic source authentication, truth adjudication, model training,
  weight update, or deployment.
- v3.6.0 and earlier release functionality is preserved in this copy.

## Validation
- Automated test suite: see `TEST_RESULTS_v3.7.0.txt`.
- Python compileall: PASS.
- Isolated validation database only; production database not used.
- No live external search/fetch or model call was performed.
