# COGNISEEK TLM v11.8.0 — Cross-Project Isolation Adversarial Tests

## Added
- Added an adversarial regression suite covering identity authorization, project-scoped memory lifecycle history, integrated episode review ownership, review-history ownership, and evidence-reference linkage.
- Tests exercise both negative probes (Project A attempting to access Project B) and legitimate same-database separation between two projects.
- The suite uses a controlled identity-provider test double; no production identity provider is contacted.

## Findings and scope
The tested functions enforce project scoping for the exercised data paths. This is not an exhaustive assessment of every table, API route, connector, export, cache, or background job. No production code authorization behavior was relaxed or bypassed in this release.

## Preservation
`app/research/m_rbam.py` is unchanged from v11.7.0. No M-RBAM formulas, thresholds, labels, or protocol definitions were changed.
