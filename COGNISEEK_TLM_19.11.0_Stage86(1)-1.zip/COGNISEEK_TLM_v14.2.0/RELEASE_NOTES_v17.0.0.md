# COGNISEEK TLM v17.0.0 — Stage 55

- Added adaptive episodic-memory retrieval with optional embedding similarity.
- Added lexical fallback and explainable lexical, semantic, recency and feedback signals.
- Added configurable semantic similarity floor and normalized heuristic ranking scores.
- Added useful / irrelevant / outdated / corrected feedback records.
- Added duplicate-candidate detection and explicit memory relation links.
- Added symmetric contradiction caution visibility.
- Hardened Stage 55 SQLite connection lifecycle and bounded duplicate-scan inputs.
- Preserved every v16.9.0 archive entry byte-for-byte at the uncompressed file-content level.
- Stage 54 source and schema remain unchanged.
