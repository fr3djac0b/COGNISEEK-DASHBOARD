# v10.5.0 Test Plan
- Missing OIDC configuration fails closed.
- Missing bearer token fails closed.
- Invalid token/signature fails closed.
- Verified subject and role mapping.
- Project membership enforcement.
- Existing v10.4.0 authorization regression tests.
- Full historical pytest suite and compileall.
