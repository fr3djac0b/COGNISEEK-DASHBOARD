# COGNISEEK TLM v8.7.0 — Adaptive Learning Policy

## Purpose
Translate descriptive cross-episode patterns and existing reviewer governance
into explicit advisory controls for future historical-experience reuse.

## New module
`app/adaptive_learning_policy.py`

## API
- `GET /api/cognitive-runtime/learning/adaptive-policy?project=default&limit=500&stale_after_days=180`
- `GET /api/cognitive-runtime/learning/adaptive-policy/{candidate_id}?project=default&stale_after_days=180`

## Policy actions
- `RESTRICT_PENDING_POST_CORRECTION_REVIEW`
- `EXCLUDE_FROM_ROUTINE_REUSE`
- `REQUIRE_FRESH_VERIFICATION_BEFORE_REUSE`
- `REQUIRE_CURRENT_EVIDENCE_AND_VERIFICATION`
- `REFRESH_BEFORE_REUSE`
- `ALLOW_CONTEXTUAL_REUSE_WITH_CURRENT_EVIDENCE`
- `CAUTIOUS_CONTEXTUAL_REUSE`

## Integration
The adaptive experience selector now applies the policy's advisory tier and
returns the policy action alongside the selected experience. Relevance remains
the primary ranking factor; current evidence remains mandatory.

## Guardrails
Read-only policy evaluation. No automatic memory mutation, truth labels, model
weight updates, answer release, or execution authorization. Inputs are
caller/reviewer-reported and not independently authenticated.
