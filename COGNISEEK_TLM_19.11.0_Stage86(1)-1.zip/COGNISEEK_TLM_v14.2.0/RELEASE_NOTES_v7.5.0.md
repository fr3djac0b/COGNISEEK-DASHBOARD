# COGNISEEK TLM v7.5.0 — Adaptive Memory Retrieval

## Delivered
- Combines approved reviewed-experience examples with prior episode history.
- Ranks retrieval candidates using query relevance, review freshness, recency, and memory type.
- Preserves provenance and reviewer approval state for experience memories.
- Exposes prior episode corrections and rejected-answer warnings.
- Flags stale records and keeps historical memory separate from current evidence.
- Records each adaptive retrieval as an append-only audit run.

## API
- `POST /api/cognitive-runtime/memory/adaptive-retrieve`
- `GET /api/cognitive-runtime/memory/adaptive-retrieval-history?project=...`

## Boundaries
- Retrieval scores are ranking heuristics, not truth or calibrated confidence.
- Only approved experience examples are included from the reviewed-experience channel.
- Episodic history remains unverified context.
- The system does not infer evidence direction from memory text, override current evidence, or update LLM weights.
- Current evidence with D=0 remains non-directional; F4 is not coerced into support or contradiction.

## Validation
- Full test suite: 494 passed, 0 failed.
- Python compileall: passed.
- No live external network calls were made.
