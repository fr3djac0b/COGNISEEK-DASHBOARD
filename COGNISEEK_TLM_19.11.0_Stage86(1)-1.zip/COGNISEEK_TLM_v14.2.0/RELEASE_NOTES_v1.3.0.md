# COGNISEEK TLM v1.3.0 — Episode Intelligence and Longitudinal Memory

## Added
- Append-only episode records for every `/api/chat` request.
- Project-scoped retrieval of potentially relevant prior episodes using lexical overlap and a recency heuristic.
- Historical episodes are passed to the model context with explicit `historical_unverified` status.
- Episode records preserve request, answer, mode, evidence/document/prior-episode references, uncertainty, conflict flag, trace ID and timestamp.
- Outcome capture for confirmed, corrected, rejected, inconclusive and follow-up outcomes.
- Outcome-aware memory retrieval surfaces recorded corrections and warns against blindly reusing historical answers.
- API endpoints:
  - `GET /api/episodes`
  - `GET /api/episodes/retrieve`
  - `POST /api/episodes/outcomes`
  - `GET /api/episodes/outcomes`

## Architecture rule
Every chat request is a new episode. Previous episodes are historical context, not authoritative evidence. New evidence must be evaluated independently. Corrections/outcomes append to history and do not overwrite old answers.

## Boundaries
- Prior episode retrieval is lexical overlap plus recency, not semantic understanding.
- Memory retrieval does not resolve contradictions automatically.
- Outcome labels are user supplied and are not independently validated.
- Outcome storage does not train or update model weights.
- No account-level authentication or per-user isolation; project names alone are not access control.
