# COGNISEEK TLM v11.9.0 — Security Regression Automation

## Added
- `scripts/run_security_regression.py` runs focused identity, authorization and cross-project isolation tests.
- The gate validates that all seven explicit route-policy entries still correspond to registered FastAPI paths.
- The gate regenerates `ROUTE_SECURITY_INVENTORY.json` and writes `SECURITY_REGRESSION_RESULT.json`.
- Added a GitHub Actions workflow for push, pull request and manual execution.
- Added a test that verifies the seven governed policies remain registered.

## Gate semantics
A missing governed route registration or failing focused security test fails the gate. Static high/elevated route findings are recorded as a manual-review backlog and do not fail the gate automatically; source scanning cannot reliably establish whether every legacy route is safe or unsafe.

## Preservation
`app/research/m_rbam.py` is unchanged. No M-RBAM formulas, thresholds, labels or protocol definitions were modified.
