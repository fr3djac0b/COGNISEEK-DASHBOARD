# COGNISEEK TLM v4.8.0 — Evidence Quality and Methodological Appraisal

## Purpose
Adds a reviewer-governed record of study methods and claim-scope fit. It helps reviewers inspect *how* evidence was produced without converting descriptive metadata into an automatic quality or truth score.

## New capabilities
- Project-scoped, append-only methodological appraisals tied to exact stored passage (`candidate_id`) records.
- Separate fields for study-design description and reviewer assessment of design fit.
- Structured capture of population, sample size, measurement methods, bias risks and limitations.
- Replication status distinguishes not reported, author-claimed replication, reviewer-recorded independent replication, reviewer-recorded absence of independent replication, and unclear.
- Claim-scope relation is a separate reviewer-entered category: `DIRECTLY_ADDRESSES`, `PARTIALLY_ADDRESSES`, `DOES_NOT_ADDRESS`, `UNCLEAR`.
- Multiple reviewers and conflicting appraisals are preserved. Reports use each reviewer's latest assessment for a candidate while retaining all earlier events.
- Append-only project-scoped report history.

## API
- `POST /api/methodology/appraisals`
- `GET /api/methodology/appraisals`
- `POST /api/methodology/analyze`
- `GET /api/methodology/reports`

## Guardrails
- No aggregate methodological quality score.
- No automatic evidence direction (`SUPPORTS` / `CONTRADICTS`) assignment.
- Claim-scope alignment is not evidence direction.
- A study-design description is not an assessment that the design is appropriate.
- Author-claimed replication is not independently verified replication.
- Reviewer-recorded replication status is not independently authenticated.
- Reviewer agreement is not truth.
- Metadata completeness is not study quality.
- No source-independence certification, truth adjudication, model training, weight update, live search/fetch, or deployment.

## Compatibility
Built by copying the v4.7.0 release source bundle. Previous release ZIP is preserved unchanged.
