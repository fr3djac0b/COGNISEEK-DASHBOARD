# COGNISEEK TLM v7.0.0 — Unified Cognitive Learning Cycle

## Purpose
Introduces a unified episode-level orchestration interface that connects request processing, historical retrieval, evidence qualification, optional M-RBAM appraisal, outcome recording, candidate memory generation, reviewer memory decisions, and cycle inspection.

## New cycle endpoints
- `POST /api/cognitive-runtime/cycles` — start a request episode and run the request-side stages.
- `POST /api/cognitive-runtime/cycles/{episode_id}/advance` — record a later outcome and optionally propose a memory candidate.
- `GET /api/cognitive-runtime/cycles/{episode_id}` — inspect report, outcomes, candidate status, and cycle state.

## Cycle states
- `AWAITING_OUTCOME`
- `OUTCOME_RECORDED`
- `AWAITING_MEMORY_REVIEW`
- `MEMORY_CONSOLIDATED`

## What is connected
- Existing runtime request creation and historical episode retrieval.
- Evidence qualification and optional appraisal.
- Existing append-only outcome recording.
- v6.9 candidate generation and reviewer-controlled memory consolidation.
- Project-scoped cycle inspection.

## Guardrails and boundaries
- Response generation remains withheld unless the separately governed evidence workflow and release gate are completed.
- An outcome is caller-supplied and is not independently verified.
- Candidate generation is not approval.
- Memory approval updates application memory, not LLM weights.
- The cycle view is bounded by the runtime report listing limit (200); large installations should add indexed direct episode lookup.
- This is an orchestration prototype, not a trained foundation model or autonomous general intelligence.
- No live external acquisition is performed by the cycle endpoints.

## Validation
- Full regression: 462 passed, 0 failed.
- New v7.0 integration tests: 10 passed (included in full regression).
- Python compileall: PASS.
- ZIP integrity: PASS.
- Isolated temporary SQLite database used; production/user data not modified.
