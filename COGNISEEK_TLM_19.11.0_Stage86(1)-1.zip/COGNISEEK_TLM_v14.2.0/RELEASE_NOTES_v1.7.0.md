# COGNISEEK TLM v1.7.0

## Added
- Correction-aware episodic retrieval: episodes with reviewer-recorded `corrected` or `rejected` outcomes are marked `CORRECTED_OR_REJECTED_REQUIRES_REVIEW`.
- Retrieval metadata explicitly instructs downstream generation not to reuse the prior answer as knowledge when a correction/rejection exists.
- Reviewer-recorded corrections are surfaced separately from the preserved original answer.
- Exact evidence-reference reuse diagnostics across selected episodes.
- `POST /api/episodes/evidence-reuse` endpoint.
- Tests for correction propagation, outcome status handling, duplicate reference detection and project isolation.

## Preserved
- Original episode and answer are immutable.
- All outcome records remain append-only.
- Historical outcomes do not become verified truth automatically.
- v1.6 expectation/reality comparison and v1.5 F4 handling remain intact.

## Limitations
- Corrections are reviewer-supplied and are not automatically verified.
- Correction-aware retrieval is a context signal, not a hard guarantee that an external LLM will obey the instruction.
- Exact reference reuse detects repeated identifiers only; it does not identify paraphrased duplicates or prove source independence.
- No model weights are updated; no automatic online training.
- No authentication/per-user access control.
- No live provider test and no deployment.
