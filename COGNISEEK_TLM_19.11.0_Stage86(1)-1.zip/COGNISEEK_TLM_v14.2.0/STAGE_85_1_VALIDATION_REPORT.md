# COGNISEEK v19.10.1 — Stage 85.1 Validation Report

## Results
- Full repository unittest discovery: exit=0
- Stage 85.1 corrective tests: exit=0
- Python compileall: exit=0
- Docker CLI available: False
- Docker image build / container launch: NOT RUN (Docker CLI unavailable)
- Live HTTP deployment / persistence / backup-restore: NOT VERIFIED

## Full test output
```text
:
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f6400779c10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff183910>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff183b10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2010>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff183c10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff183e10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff183f10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2610>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2110>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2210>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2310>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2a10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2410>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2510>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2710>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2e10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2810>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2910>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2b10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f64002ec010>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2c10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2d10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f63ff8f2f10>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f6429794510>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f6429794610>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f6429794710>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f6429794810>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642979a410>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642979a510>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642979a610>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f64297af010>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f64297af210>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642153b310>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642153b410>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642153b510>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642155e310>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642155e410>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f642155e510>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f64002ec210>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f64002ec310>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f64002ec510>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/mnt/data/COGNISEEK_v19_10_1_work/COGNISEEK_TLM_v14.2.0/app/stage73_tlm_model_core.py:27: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f64002ec710>
  def forward(self,x,mask):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/usr/lib/python3.13/multiprocessing/popen_fork.py:67: DeprecationWarning: This process (pid=3506) is multi-threaded, use of fork() may lead to deadlocks in the child.
  self.pid = os.fork()
----------------------------------------------------------------------
Ran 383 tests in 5.536s

OK

```

## Stage 85.1 test output
```text
Spreadsheet runtime warmup failed during python startup
Traceback (most recent call last):
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/spreadsheet_warmup.py", line 718, in _warm_feature_flows
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/spreadsheet_warmup.py", line 509, in _warm_drawing_and_image_flows
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/generated/interface/models.py", line 32861, in bring_to_front
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/rpc/remote.py", line 764, in __call__
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/rpc/client.py", line 175, in call
artifact_tool.rpc.client.RemoteError: Element ordering requires an owning element collection.
test_accepts_absolute_persistent_path (tests.test_v19_10_1_stage85_1_hardening.Stage851HardeningTests.test_accepts_absolute_persistent_path) ... ok
test_deployment_requires_explicit_opt_in (tests.test_v19_10_1_stage85_1_hardening.Stage851HardeningTests.test_deployment_requires_explicit_opt_in) ... ok
test_rejects_empty_relative_and_ephemeral_paths (tests.test_v19_10_1_stage85_1_hardening.Stage851HardeningTests.test_rejects_empty_relative_and_ephemeral_paths) ... ok
test_timed_task_is_terminated_not_left_running (tests.test_v19_10_1_stage85_1_hardening.Stage851HardeningTests.test_timed_task_is_terminated_not_left_running) ... /usr/lib/python3.13/multiprocessing/popen_fork.py:67: DeprecationWarning: This process (pid=3590) is multi-threaded, use of fork() may lead to deadlocks in the child.
  self.pid = os.fork()
ok
test_untimed_task_still_returns_result (tests.test_v19_10_1_stage85_1_hardening.Stage851HardeningTests.test_untimed_task_still_returns_result) ... ok

----------------------------------------------------------------------
Ran 5 tests in 0.159s

OK

```

## Compilation output
```text
Spreadsheet runtime warmup failed during python startup
Traceback (most recent call last):
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/patches/warm_spreadsheet_runtime_on_startup.py", line 26, in warm_spreadsheet_runtime_on_startup
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/spreadsheet_warmup.py", line 785, in warm_spreadsheet_runtime
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/spreadsheet_warmup.py", line 718, in _warm_feature_flows
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/spreadsheet_warmup.py", line 509, in _warm_drawing_and_image_flows
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/generated/interface/models.py", line 32861, in bring_to_front
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/rpc/remote.py", line 764, in __call__
  File "/tmp/tmp.QlpUkOUI9D/artifact_tool_v2-2.8.66/artifact_tool/rpc/client.py", line 175, in call
artifact_tool.rpc.client.RemoteError: Element ordering requires an owning element collection.

```

## Interpretation
Passing unit tests validate code paths covered by those tests only. They do not
establish production deployment, TLS, external security, multi-process load,
persistent-volume durability, or backup restoration.

## Known constraints
- Timed task execution uses process isolation; on spawn-based platforms, the
  callable and its return value must be pickleable.
- Terminating a process does not reverse external side effects already completed.
- Docker deployment requires a real Docker host, production secrets, persistent
  storage and an operator-approved TLS/network configuration.
