# v9.3.0 verification plan
- Project isolation for orchestration and candidate records
- Reviewer-entered direction validation
- Separate INDETERMINATE and NEUTRAL categories
- VALID-only, APPROVED-only summary counts
- Append-only records and preservation of conflicting directions
- Stale/rejected records excluded from approved-valid summaries
- Provisional source dependency metadata; independence never certified
- No live external acquisition in tests
