# COGNISEEK TLM v10.8.0 — Model-Backed Answer Generation

## Added
- `app/generation_orchestrator.py`: structured model draft, evidence-ID allowlisting, exact-quote checks, semantic review handoff, deterministic review status, and append-only project-scoped generation history.
- API:
  - `GET /api/generation/status`
  - `POST /api/generation/execute`
  - `GET /api/generation/history`
- Factual claims with valid linked evidence are passed to the v10.7 semantic verifier.
- Unknown evidence IDs are discarded. Quotes are retained only when they are exact substrings of the cited passage.
- Contradiction and INDETERMINATE states remain visible through the existing semantic verifier.
- Release authorization is always false in this milestone.

## Important boundaries
- This is model-backed structured drafting, not a newly trained foundation model.
- Model-generated claim relations are provisional interpretations, not truth verification.
- Evidence authenticity, publisher identity, source independence and methodological quality are not established by this endpoint.
- Human review remains mandatory. No calibrated confidence score is claimed.
- Live provider behavior was not tested as part of the automated suite; provider calls are mocked in focused tests.
