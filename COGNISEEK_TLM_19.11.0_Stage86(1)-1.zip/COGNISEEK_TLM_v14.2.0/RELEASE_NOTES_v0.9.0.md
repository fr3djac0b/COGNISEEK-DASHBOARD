# COGNISEEK TLM v0.9.0 — Retrieval Ranking & Source Metadata Qualification

## Added
- Hybrid lexical retrieval combines IDF-weighted term relevance, query-term coverage and exact phrase matching.
- Results expose component scores, matched terms, phrase-match flag and ranking explanation.
- Source metadata qualification reports completeness and missing provenance fields.
- Retrieved passages remain explicitly labelled unverified in chat context.

## New API
- `GET /api/documents/qualification?project=default&limit=100`

## Boundaries
- Not semantic/vector retrieval; no embeddings are generated.
- Metadata completeness does not establish authority, truth, accuracy, independence or methodological validity.
- Ranking scores are relevance indicators, not confidence scores.
- No live web crawling or external source authentication.
\n## Verification\n- 28 automated tests passed on an isolated temporary database.\n- Python compilation passed.\n- No live web retrieval or deployment test performed.\n