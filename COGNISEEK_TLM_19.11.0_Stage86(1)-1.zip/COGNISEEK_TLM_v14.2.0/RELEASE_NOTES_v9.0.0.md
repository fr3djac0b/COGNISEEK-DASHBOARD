# COGNISEEK TLM v9.0.0 — Unified Cognitive Decision Cycle

## Purpose
Move from individually implemented cognitive modules to one auditable orchestration cycle.

## Coordinated stages
1. Create a new request episode.
2. Retrieve adaptive historical memory before creating the episode (prevents self-retrieval).
3. Qualify caller-supplied current evidence and preserve rejected/malformed entries.
4. Optionally run M-RBAM appraisal when both pre/post appraisal values are supplied.
5. Apply historical experiences through v8.7/v8.8 governance; restricted candidates remain withheld.
6. Reconcile current evidence against explicit historical evidence metadata.
7. Leave answer generation, company-policy release, and execution authorization as explicit not-run states.

## API
- `POST /api/cognitive-runtime/decision-cycles`
- `GET /api/cognitive-runtime/decision-cycles/{cycle_id}`
- `GET /api/cognitive-runtime/decision-cycles`

## Governance and limitations
Historical memory is contextual, not current evidence. Retrieval is not verification. Evidence direction, references, and identity fields are caller-supplied. No evidence authentication, external acquisition, model generation, automatic memory mutation, model-weight update, answer release, or action authorization is performed. M-RBAM F4 is preserved for indeterminate direction; no U value is fabricated.
