# COGNISEEK TLM v11.2.0 — Governed Answer Assembly and Release Integration

## Release objective
Connect the v11.1 integrated request and human-review lifecycle to the existing decision-cycle, evidence-intelligence workflow, answer-release bridge, and company-policy governance engine.

## Additions
- `app/governed_answer_integration.py`
  - Resolves the integrated request, decision cycle, evidence workflow, and review status within the requested project.
  - Requires run/report/episode identity linkage.
  - Requires exact current-evidence reference equality across run, cycle, and workflow.
  - Blocks incomplete human review.
  - Blocks unresolved reviewer disagreement.
  - Requires a completed/eligible workflow and existing evidence-grounded response.
  - Delegates release to the existing `answer_release_bridge.release()` implementation.
  - Stores append-only release-attempt integration events.
- API routes:
  - `POST /api/cognitive-runtime/integrated-requests/{run_id}/governed-release`
  - `GET /api/cognitive-runtime/integrated-requests/{run_id}/governed-release-history`

## Preserved behaviour
- Existing M-RBAM mathematics and protocol selection are unchanged.
- `app/research/m_rbam.py` is byte-for-byte identical to v11.1.0.
- No new generation engine or policy engine is introduced.
- The existing answer-release bridge remains authoritative for company-policy decisions.
- Policy BLOCK results remain blocked; no response text is exposed by this integration when blocked.
- Caller-supplied actor/role values are not authenticated identity.
- No automatic release occurs when review completes; a separate explicit governed-release request is required.

## Safety and limitations
- Review completion is not scientific truth or evidence sufficiency.
- F4 remains an appraisal state; the new layer does not reinterpret or numerically recode it.
- Source authenticity and independence remain upstream concerns.
- No operational execution is authorized.
- Live external model-provider testing was not performed.
