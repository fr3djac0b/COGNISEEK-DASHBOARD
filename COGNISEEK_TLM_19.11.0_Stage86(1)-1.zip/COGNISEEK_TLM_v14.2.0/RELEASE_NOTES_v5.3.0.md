# COGNISEEK TLM v5.3.0
## Cross-Study Statistical Comparability

Built on v5.2.0 Statistical Evidence Intelligence and the v5.1 structured findings ledger.

### Capabilities
- Performs pairwise comparability screening across reviewer-approved findings.
- Assesses outcome, effect measure, population, intervention, comparator, study design, follow-up period, units and directionality.
- Distinguishes core mismatches, missing critical information, optional mismatches and complete recorded matches.
- Does not infer missing study characteristics or convert units.
- Flags multiple findings originating from the same source document; does not count them as independent studies.
- Stores append-only comparability reports with finding IDs and reviewer eligibility state.

### Endpoints
- `POST /api/statistics/comparability/analyze`
- `GET /api/statistics/comparability/reports`
- `GET /api/statistics/comparability/reports/{report_id}`

### Interpretation statuses
- `INCOMPATIBLE_FOR_DIRECT_QUANTITATIVE_COMPARISON`
- `INSUFFICIENT_INFORMATION`
- `CONDITIONAL_REVIEW_REQUIRED`
- `CORE_MATCH_OPTIONAL_DIMENSIONS_UNREPORTED`
- `CORE_AND_RECORDED_DIMENSIONS_MATCH`

### Explicit limitations
- A compatibility match is not proof of exchangeability, absence of bias, independent samples, or meta-analysis eligibility.
- No effect pooling, meta-analysis, causal inference, truth determination or source-independence certification.
- Reviewer identity remains a supplied string in the prototype.
- Study-design field is an additive optional extension to structured findings; legacy findings without it remain valid but are marked unreported.

See `TEST_RESULTS_v5.3.0.txt`.
