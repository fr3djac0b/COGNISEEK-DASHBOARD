# COGNISEEK TLM v4.0.0 — Trajectory Intelligence and Adaptive Retrieval

## Added
- `app/trajectory_intelligence.py` provides expectation-to-current-material comparison, temporal review profiles and offline retrieval strategy evaluation.
- Project-scoped append-only history for comparisons and retrieval evaluations.
- API endpoints:
  - `POST /api/trajectory/intelligence/compare`
  - `POST /api/retrieval/strategies/evaluate`
  - `GET /api/trajectory/intelligence/history`

## Design safeguards
- Prior experience remains historical context, never current evidence or ground truth.
- Comparison uses lexical overlap/difference only; it does not infer semantic agreement, contradiction, or evidence direction.
- Older records are not assumed false; corrections and revocations are review signals.
- Retrieval evaluation uses externally supplied relevance labels and candidate rankings.
- A metric recommendation does not automatically alter production retrieval.
- No model training, embedding weight updates, automatic strategy switching, or deployment.
