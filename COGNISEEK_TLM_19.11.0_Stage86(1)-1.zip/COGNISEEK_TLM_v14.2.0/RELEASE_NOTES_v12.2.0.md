# COGNISEEK TLM v12.2.0

## Milestone
**Evidence and Reviewed-Memory Route Authorization Remediation**

This release applies the existing signed identity and project-membership
authorization boundary to four API routes:

| Route | Access policy |
|---|---|
| `GET /api/evidence` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| `POST /api/evidence` | ADMIN, OPERATOR |
| `GET /api/memory/items` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| `POST /api/memory/items` | ADMIN, OPERATOR |

## Enforcement
- Each route extracts the bearer token from the Authorization header.
- The existing identity provider verifies the signed token.
- The existing authorization boundary independently checks that the verified
  principal belongs to the requested project.
- Route-specific roles are enforced centrally through
  `app/route_authorization_policy.py`.
- Allow and deny outcomes are appended to the identity-authorization audit.
- Project identity for write routes is taken from the validated request model,
  not from a separate caller-supplied header.

## Test evidence
- 8 new API authorization integration tests passed.
- Full isolated regression suite: 784 passed, 0 failed.
- Cross-project read and write probes denied.
- Viewer read allowed; viewer write denied.
- Operator write allowed.
- Unauthenticated read rejected.
- Route governance register now records 11 explicit policies, including the
  four new evidence and reviewed-memory policies.
- Source semantic review detects explicit authorization helper calls in all
  four protected handlers.

## Scope boundaries
Only the four routes above are newly protected in this milestone. Other
evidence, memory, learning, and episode endpoints remain subject to further
route-by-route review. This release is not a full API security certification,
deployed penetration test, or live identity-provider/JWKS validation.

## Compatibility
- The v12.1.0 baseline is retained.
- Existing data models and evidence/memory persistence logic are unchanged.
- M-RBAM mathematical definitions and source are unchanged.
- Legacy tests that exercise endpoint business logic use an explicit
  test-only authorization stub; dedicated v12.2 tests exercise the real
  authorization boundary.
