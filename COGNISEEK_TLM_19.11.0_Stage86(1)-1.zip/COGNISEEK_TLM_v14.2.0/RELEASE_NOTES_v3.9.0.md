# COGNISEEK TLM v3.9.0 — Governed Experience-Based Learning

## New capability
Reviewed experience examples can be retrieved in future episodes only after
explicit reviewer approval. A separate append-only review event can revoke
future contextual use without deleting the original example or review history.

## Workflow
- Existing `/api/learning/examples/build` creates a provisional reviewed-feedback example from a linked appraisal and outcome.
- `POST /api/experience-memory/reviews` accepts `APPROVE_FOR_CONTEXT` or `REVOKE_CONTEXT`.
- `/api/chat` retrieves only currently approved examples, project-scoped, using lexical relevance.
- Experience is injected as a separate `reviewed_experience_not_evidence` context channel.
- `GET /api/experience-memory/history` exposes approval/revocation and retrieval audit history.
- `POST /api/experience-memory/retrieve` supports explicit preview.

## Governance
Unapproved examples are excluded. Revocation takes effect on future retrieval.
Historical experience is not current evidence, ground truth, or proof. Current
evidence remains in separate channels. No cross-project retrieval, automatic
example approval, model-weight update, autonomous training, or deployment.

## Limitations
Lexical retrieval only; no semantic matching in this module. Reviewer labels
may be mistaken. Retrieved examples may be irrelevant despite lexical overlap.
The connected model may fail to follow context instructions. This is controlled
memory use, not a trained foundation model.
