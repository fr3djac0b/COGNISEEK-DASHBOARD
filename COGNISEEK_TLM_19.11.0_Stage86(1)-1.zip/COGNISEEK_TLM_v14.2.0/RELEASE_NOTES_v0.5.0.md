# COGNISEEK TLM v0.5.0

## Added
- Persistent SQLite feedback memory with project-scoped records.
- Optional feedback-to-trace linking, validated against existing traces in the same project.
- Feedback retrieval and learning-summary endpoints.
- Audit trace event when feedback is submitted.
- API tests for persistence, trace validation, input validation, and honest learning-status reporting.

## Preserved
- v0.4 evidence records, duplicate warnings, appraisal, chat interface, SSE responses, trajectory snapshots, and optional compatible model client.

## Important boundary
This release stores feedback for later review. It does not update model weights, perform online training, independently verify sources, or make COGNISEEK a trained foundation model. Authentication and authorization remain necessary before public deployment with sensitive data.
