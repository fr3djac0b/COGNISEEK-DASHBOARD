# COGNISEEK TLM v6.0.0 — Unified Cognitive Runtime

## What is new
- Adds `app/unified_cognitive_runtime.py` as a first orchestration layer connecting episode creation, prior-episode retrieval, explicit evidence qualification, optional M-RBAM appraisal, and append-only runtime reporting.
- Adds API routes:
  - `POST /api/cognitive-runtime/requests`
  - `GET /api/cognitive-runtime/reports`
  - `GET /api/cognitive-runtime/reports/{report_id}`
  - `POST /api/cognitive-runtime/outcomes`
- Every request creates a new episode. Retrieved past episodes are labelled contextual candidates, not proof.
- Explicit evidence references are checked for required fields, supported direction values, and duplicate reference IDs. Opposing directions are preserved as a conflict.
- Directional M-RBAM appraisal is optional. When evidence direction is indeterminate (D=0), the experimental directional profile returns F4 and U=null.
- Outcomes append to episode history without rewriting the original runtime report.
- Project-scoped report retrieval.

## Important boundaries
- This is an orchestration prototype, not a newly trained foundation model.
- No external web/source acquisition, independent source authentication, LLM response generation, or v5.9 company-policy release evaluation is performed by this runtime yet.
- Response generation is explicitly marked `NOT_RUN`; output is withheld rather than fabricated.
- Company policy release is `NOT_EVALUATED`; v5.9 governance is not bypassed.
- Source freshness and independence labels are caller-supplied and not independently established here.
- Caller-supplied actor is not authenticated identity.

## Validation
- Full test suite: 377 passed.
- Python compilation: passed.
- ZIP integrity: passed.
