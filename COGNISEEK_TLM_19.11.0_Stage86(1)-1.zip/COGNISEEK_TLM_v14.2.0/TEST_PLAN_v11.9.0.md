# v11.9.0 Test Plan

1. Run the security regression script in a clean isolated environment.
2. Confirm the focused v11.4, v11.7 and v11.8 suites execute.
3. Confirm all seven explicit role-policy paths are registered in FastAPI.
4. Confirm static route inventory and machine-readable gate result are emitted.
5. Confirm GitHub Actions workflow syntax and expected commands by source inspection.
6. Run the full project regression suite separately.
7. Run compileall and FastAPI import.
8. Verify M-RBAM source is byte-for-byte unchanged from v11.8.0.
9. Verify release ZIP integrity.
