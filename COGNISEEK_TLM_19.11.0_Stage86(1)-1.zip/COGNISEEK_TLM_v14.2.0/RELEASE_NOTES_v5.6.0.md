# COGNISEEK TLM v5.6.0
## Evidence and Governance Audit Intelligence

Built as a separate release from v5.5.0.

### Capabilities
- Project-scoped integrity snapshots over an explicit allowlist of evidence lifecycle tables.
- SHA-256 row digests and whole-snapshot digest.
- Compares the current snapshot with the previous audit and reports `ADDED`, `CHANGED`, `DISAPPEARED` and `UNCHANGED` records.
- Preserves prior audit IDs and snapshot hashes for sequential comparison.
- Stores audit reports, snapshot rows and change events in append-only audit tables.
- Does not expose source row contents in change events.
- Reports tables that are unavailable or do not have the required project/key columns rather than treating them as empty.

### API
- `POST /api/governance-audits/run`
- `GET /api/governance-audits`
- `GET /api/governance-audits/{audit_id}`

### Important limits
- Hashes are integrity digests, not digital signatures or proof of source authenticity.
- The audit does not prevent a database administrator or attacker from changing both source records and audit storage.
- A disappeared row is an anomaly to investigate, not proof of malicious deletion.
- Only explicitly allowlisted project-scoped tables are included.
- No automated disciplinary, legal, scientific-truth or reviewer-integrity conclusions are made.

See `TEST_RESULTS_v5.6.0.txt`.
