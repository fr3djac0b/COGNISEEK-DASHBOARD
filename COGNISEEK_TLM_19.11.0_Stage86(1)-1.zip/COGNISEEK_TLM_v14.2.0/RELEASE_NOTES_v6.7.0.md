# COGNISEEK TLM v6.7.0 — Evidence Calibration and Confidence Reliability

## Purpose
Adds an explicit prediction/outcome ledger so COGNISEEK can compare stated probabilities with later observed outcomes and report descriptive calibration diagnostics. It also records abstentions rather than treating them as predictions.

## Added
- Append-only prediction records in `cognitive_calibration_records`.
- `POST /api/cognitive-runtime/calibration/predictions` to record a prediction or abstention.
- `POST /api/cognitive-runtime/calibration/outcomes` to record a later observed outcome.
- `GET /api/cognitive-runtime/calibration/records` to inspect the ledger.
- `GET /api/cognitive-runtime/calibration/diagnostics` to calculate descriptive metrics.
- Binary probability metrics: Brier score, log loss, and expected calibration error (ECE).
- Label accuracy where predicted and actual labels are both supplied.
- Abstention rate, pending outcome count, and outcome coverage.

## Metric conventions
- Binary actual outcomes for probability scoring must be encoded as the strings `0` or `1`.
- Predicted probability must be between 0 and 1.
- Brier score and log loss are computed only for resolved records with a valid binary outcome and a stored probability.
- Label accuracy is computed only when both labels are present.
- Pending outcomes are excluded from scoring.
- Fewer than 20 probability-scored outcomes produces `INSUFFICIENT_RESOLVED_PROBABILITY_OUTCOMES`; metrics may be displayed descriptively but must not be interpreted as validation.

## Guardrails
- A confidence value is not automatically treated as a calibrated probability.
- An abstention is logged but not automatically judged correct.
- No automatic confidence threshold, model retraining, or weight update occurs.
- No claim of general reliability is made from a small or biased logged sample.
- Outcomes are reviewer-supplied; this release does not independently verify real-world outcomes.
- The calibration ledger does not change evidence appraisals, source lineage, methodological ratings, or release permissions.

## Validation
- Full regression suite: 425 passed.
- New v6.7 focused tests: 14 passed (included in full regression).
- Python compileall: run during packaging.
- Isolated temporary SQLite database used; no production/user database modified.
- No live external acquisition performed.
