# COGNISEEK TLM v15.3.0 — Stage 38

Adds incremental per-layer GQA key/value caching, prompt prefill, cache reset, bounded-window overflow rebuild, and greedy cached generation. Cached logits are tested against full-window forward logits.
