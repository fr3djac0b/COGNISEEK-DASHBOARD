# v10.8.0 Test Plan

1. Reject missing model configuration.
2. Discard model-invented evidence IDs.
3. Retain quotations only when exact substrings of supplied passages.
4. Preserve unsupported factual claims as unresolved.
5. Verify project-scoped append-only generation history.
6. Verify release authorization remains false.
7. Run the inherited full regression suite, Python compilation, FastAPI import/route checks, and ZIP integrity validation.
