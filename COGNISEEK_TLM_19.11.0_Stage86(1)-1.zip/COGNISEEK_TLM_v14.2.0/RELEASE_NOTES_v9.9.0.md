# COGNISEEK TLM v9.9.0 — Security and Operational Hardening

## Added
- `app/security_controls.py` middleware.
- Optional bearer-token authentication for `/api/*`, enabled by server-side `COGNISEEK_API_KEY`.
- Fail-closed behavior if a configured API key is shorter than 32 characters.
- In-process per-client rate limiting via `COGNISEEK_RATE_LIMIT_PER_MINUTE` (default 1000; set 0 to disable).
- Declared request-size limit via `COGNISEEK_MAX_REQUEST_BYTES` (default 1 MiB).
- Standard response security headers: CSP, frame denial, MIME sniffing protection, referrer and permissions policies, and no-store.
- Health metadata reports whether API-key auth is configured and documents the limiter scope.

## Configuration
Set a random API key of at least 32 characters on the server:
```bash
export COGNISEEK_API_KEY="$(python -c 'import secrets; print(secrets.token_urlsafe(48))')"
export COGNISEEK_RATE_LIMIT_PER_MINUTE=120
export COGNISEEK_MAX_REQUEST_BYTES=1048576
```
Send `Authorization: Bearer <key>` on API requests. The key must never be placed in browser JavaScript or committed to source control.

## Important deployment limitations
- Authentication is one shared bearer key, not user identity, roles, or per-project authorization.
- Rate limiting is in-process memory and resets on restart; it is not shared across workers or instances and must be backed by a trusted edge/shared limiter for production.
- Client IP is taken from the ASGI connection; forwarded headers are not trusted by this middleware.
- Request-size checks use `Content-Length`; a reverse proxy must enforce hard body limits for chunked/streamed uploads.
- TLS termination, secrets management, database encryption/backups, audit tamper resistance, account lifecycle, authorization policy, and security penetration testing remain deployment responsibilities.
- No public deployment with sensitive data should be considered production-ready solely because this middleware is present.
