# COGNISEEK TLM v2.1.0 — Retrieval Candidates and Reviewer-Confirmed Evidence Links

## Added
- `app/evidence_linking.py`.
- Claim-to-passage candidate retrieval from project-scoped stored document chunks.
- Candidate records preserve chunk/document IDs, passage text, source metadata, lexical score, coverage and matched terms.
- Candidate direction remains null until a reviewer confirms one of `SUPPORTS`, `CONTRADICTS`, `NEUTRAL`, or `INDETERMINATE`.
- Append-only reviewer-confirmed link table.
- Project membership validation for selected chunks.
- Stable evidence identity uses passage `chunk_id`, preventing repeated reviews of one passage from inflating distinct-record counts.
- Conflicting directions for the same passage are not silently resolved; downstream appraisal rejects conflicting duplicate IDs.
- API:
  - `POST /api/claims/evidence-candidates`
  - `POST /api/claims/evidence-links/confirm`
  - `GET /api/claims/evidence-links`
  - `POST /api/answer/orchestrate/linked`
- Linked orchestration uses exact claim-text matching; changed draft wording requires fresh review.

## Validation
- Automated tests: 92 passed, 0 failed.
- `python -m compileall -q app`: passed.
- ZIP integrity: verified during packaging.

## Limitations
- Candidate retrieval uses lexical ranking; no semantic model is invoked by this endpoint.
- Retrieval scores are not support or truth scores.
- Directions are human-supplied.
- Distinct passage IDs are not verified independent sources.
- No URL fetching, external research, source authentication, entailment model, truth adjudication, or calibrated confidence.
- No live model/provider test or deployment performed.
