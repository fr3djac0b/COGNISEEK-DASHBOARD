# COGNISEEK TLM v15.5.0 — Stage 40

Adds governed local text ingestion, provenance/license gates, deterministic train/validation/test splits, training-only tokenizer fitting, bounded next-token batching, dataset manifests and JSONL import/export. No external corpus is bundled.
