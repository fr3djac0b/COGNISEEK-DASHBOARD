# COGNISEEK TLM v8.9.0 — Evidence-Governed Learning and Outcome Integration

## What changed
This release connects current evidence appraisal to the exact governed experience application and candidate that informed an episode. Appraisals are caller/appraiser supplied; the engine does not infer direction from text, historical experience, or similarity.

## Appraisal states
- `SUPPORTS`
- `CONTRADICTS`
- `NEUTRAL`
- `INDETERMINATE` — explicitly maps to M-RBAM F4. The update remains undefined; it is not coerced to zero.
- `UNAPPRAISED` — distinct from F4; no direction has yet been appraised.

Directional and neutral appraisals require at least one evidence reference. Indeterminate and unappraised states can be recorded without one.

## Governance
A separate reviewer decision is required. The latest `ACCEPT_FOR_LEARNING_REVIEW` marks an appraisal eligible for supervised feedback; `REJECT` and `DEFER` do not. Reviews and appraisals are append-only. Project scope and exact application/candidate membership are checked.

## API
- `POST /api/cognitive-runtime/learning/evidence-appraisals`
- `POST /api/cognitive-runtime/learning/evidence-appraisals/review`
- `GET /api/cognitive-runtime/learning/evidence-appraisals`

## Boundaries
Evidence references are not authenticated or fetched. Appraiser/reviewer identities are caller-supplied metadata, not authentication. No automatic truth labels, causal claims, memory mutation, model-weight updates, answer release, or execution authorization are performed.
