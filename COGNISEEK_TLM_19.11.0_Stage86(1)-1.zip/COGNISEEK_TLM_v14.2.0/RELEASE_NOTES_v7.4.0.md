# COGNISEEK TLM v7.4.0 — Cross-Episode Evidence Learning

## Delivered
- Compares successive evidence reassessments for the same exactly normalized claim.
- Tracks changes in SUPPORTS, CONTRADICTS, NEUTRAL, INDETERMINATE, reviewer disagreement, and relevance-only/unreviewed records.
- Stores an append-only learning comparison linked to the prior comparison and reassessment.
- Supports an explicitly selected, project-scoped reassessment.
- Keeps F4/INDETERMINATE distinct; it is never coerced into a directional score.

## API
- `POST /api/cognitive-runtime/learning/evidence-episodes`
- `GET /api/cognitive-runtime/learning/evidence-episodes?project=...&claim=...`

## Boundaries
- Claim matching is exact normalized text, not semantic equivalence.
- Count changes do not prove source independence, evidence quality, probability, causality, or truth.
- The module does not assign appraisal direction, resolve reviewer disagreement, promote durable memory, or update LLM weights.
- Earlier episode records remain unchanged.

## Validation
- Full test suite: 488 passed, 0 failed.
- Python compileall: passed.
- No live external network calls were made.
