# COGNISEEK TLM v1.5.0 — Evidence-Driven Appraisal and Conflict Tracking

## Added
- Append-only evidence-direction appraisal ledger.
- Explicit A_pre, A_post, ΔA and direction-adjusted update U = D × ΔA.
- F4 handling for D=0 / no interpretable evidence direction; U remains undefined.
- Validation prevents non-interpretable evidence from being assigned a directional code.
- Prior appraisal links and flags when two nonzero evidence directions differ.
- Append-only reviewer outcome records.
- Project-scoped appraisal and outcome endpoints.
- Evaluation coverage summary with explicit warning that reviewer outcomes are not ground truth or model accuracy.

## Important taxonomy boundary
F1/F2/F3 are not assigned by this release because their exact mapping has not been specified in the available project definition. Directional response classification is therefore returned as `DIRECTIONAL_FORM_PENDING_SPECIFICATION`. F4 is explicitly reserved for D=0.

## Preserved boundaries
- Direction coding is supplied by a reviewer, not inferred automatically by the LLM.
- Conflict flags do not select a winner.
- Outcomes do not update model weights.
- No autonomous learning, no external evidence verification, and no claim of model accuracy or calibration.
