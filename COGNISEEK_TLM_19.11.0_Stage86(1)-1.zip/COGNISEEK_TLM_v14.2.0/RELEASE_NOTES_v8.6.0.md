# COGNISEEK TLM v8.6.0
## Cross-Episode Learning Evaluation

### Purpose
Evaluate repeated use of consolidated experience across successive episodes.
This release adds descriptive metrics for repeated contradictions, unhelpful
reuse, accepted corrections followed by later applications, and verification
gaps.

### New module
`app/cross_episode_learning_evaluation.py`

### API
- `GET /api/cognitive-runtime/learning/cross-episode-evaluation?project=default&limit=500&window_days=90`
- `POST /api/cognitive-runtime/learning/cross-episode-evaluation`
  - JSON: `{"project":"default","limit":500,"window_days":90}`

### Metrics
- Reviewed and unreviewed application counts
- Repeated unhelpful reuse rate (WORSENED / reviewed applications)
- Directional verification contradiction rate
- Verification gap count
- Applications occurring after an `APPLY_CORRECTION` decision
- Candidate-level pattern labels

### Guardrails
- Project-scoped; uses existing v8.0–v8.5 records.
- Latest reviewer assessment per application is counted once.
- Directional contradiction rate uses only SUPPORTS / CONTRADICTS verification outcomes.
- `INCONCLUSIVE` and `NOT_VERIFIED` are counted as verification gaps.
- Missing current evidence references are a gap indicator, not proof evidence did not exist.
- No model-weight updates, automatic memory changes, truth labels, or answer release.
- Reports are observational summaries, not causal estimates.
- Caller/reviewer-entered records are not independently authenticated.

### Validation
See `TEST_RESULTS_v8.6.0.txt` for the clean-database regression result.
