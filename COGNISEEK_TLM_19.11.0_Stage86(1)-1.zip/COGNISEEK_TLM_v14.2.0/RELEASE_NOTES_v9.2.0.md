# COGNISEEK TLM v9.2.0 — Episode-Linked Evidence Acquisition Orchestration

## Purpose
Connect a v9.0 decision cycle to existing acquisition coverage diagnostics and adaptive acquisition planning. The new orchestration can plan by default; external discovery and fetching require explicit opt-in plus exact HTTPS allowlist configuration.

## New API
- `POST /api/cognitive-runtime/acquisition-orchestrations`
- `GET /api/cognitive-runtime/acquisition-orchestrations`
- `GET /api/cognitive-runtime/acquisition-orchestrations/{orchestration_id}`

## Workflow
1. Resolve the cycle in the requested project.
2. Assess the supplied claim against the project's stored document passages and acquisition history.
3. Build a bounded adaptive acquisition plan.
4. By default, save the plan without network activity.
5. If `allow_external=true` and `execute_external=true`, and the server has an exact HTTPS hostname allowlist, run the existing controlled discovery/fetch pipeline.
6. Preserve newly fetched material as unappraised (D=0) for subsequent reviewer appraisal.

## Safety controls
- External acquisition is off by default.
- Execution requires both explicit request flags and a configured allowlist.
- Existing acquisition controls enforce HTTPS, exact host allowlisting, public IP resolution, no redirects, content-type restrictions and size limits.
- Discovery ranking is not evidence; retrieval is not verification; acquisition is not authentication.
- No evidence direction is assigned to fetched material; it remains indeterminate (D=0).
- No source independence, sufficiency, scientific truth, answer generation, answer release or operational execution is inferred.
- Orchestration history is append-only.

## Limits
This is an integration of existing retrieval, discovery and acquisition modules, not autonomous scientific verification or a newly trained foundation model.
