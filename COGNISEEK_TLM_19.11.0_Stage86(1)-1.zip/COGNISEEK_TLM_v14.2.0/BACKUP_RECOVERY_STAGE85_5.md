# Stage 85.5 — Backup and recovery

Provides SQLite online backup, integrity checking and atomic restore helpers.
The included tests exercise backup/restore round-tripping and missing-source
rejection. This is not yet a full disaster-recovery certification: production
must additionally test scheduled backups, off-host copies, encryption, retention,
restore time, point-in-time recovery requirements, and recovery with the real
application stopped and restarted.
