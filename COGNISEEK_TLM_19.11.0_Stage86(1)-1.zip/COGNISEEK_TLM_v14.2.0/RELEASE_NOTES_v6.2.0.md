# COGNISEEK TLM v6.2.0 — Controlled Acquisition and Passage Retrieval

## Added
- New `POST /api/cognitive-runtime/research-requests` endpoint.
- Uses the existing controlled HTTPS acquisition module and its exact-domain allowlist.
- Supports up to 10 user-supplied source URLs per request.
- Acquired pages are extracted and ingested into the project's document/chunk store.
- Retrieves relevant passages from the project's indexed documents.
- Every retrieved passage remains an unassessed candidate with direction D=0 until a reviewer or validated appraisal process codes it.
- Acquisition and retrieval stage details are preserved in a linked append-only enrichment record.
- New `GET /api/cognitive-runtime/reports/{report_id}/enrichments` endpoint.

## Safety and scientific boundaries
- External acquisition remains disabled unless `COGNISEEK_FETCH_ALLOWED_DOMAINS` is configured.
- HTTPS only, exact host allowlist, redirects disabled, public-IP checks, 1 MB response limit, and content-type restrictions are inherited from the existing acquisition module.
- The current acquisition module has previously documented DNS rebinding hardening limitations; production deployment requires stronger network-level egress controls and DNS pinning/revalidation.
- Retrieval does not verify claims. Fetched content is not authenticated as publisher-originated or independent.
- No passage direction is inferred automatically. D=0 represents no appraisal direction assigned yet, not proof that a passage is neutral.
- No model answer is generated from unreviewed passages; no release gate is bypassed.
- Runtime enrichment is append-only and does not rewrite the original episode report.

## Validation
- Full regression suite: 383 passed.
- Python compilation: passed.
- ZIP integrity: passed.
- Acquisition tests use mocked network responses; no external websites were fetched during validation.
