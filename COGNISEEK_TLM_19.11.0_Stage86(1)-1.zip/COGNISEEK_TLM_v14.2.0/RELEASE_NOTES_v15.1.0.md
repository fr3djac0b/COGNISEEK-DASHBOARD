# COGNISEEK TLM v15.1.0 — Stage 36

Adds differentiable grouped-query causal attention and a trainable GroupedQueryTLM reference model. Stage 35 TinyTLM remains as the single-head baseline. See Stage 36 documentation for architecture and limitations.
