# COGNISEEK TLM v7.7.0 — Adaptive Reasoning and Verification Planning

## What changed
- Converts v7.6 reconciliation diagnostics into explainable, prioritized verification tasks.
- Discordant appraisals trigger independent verification tasks.
- D=0 remains F4 and triggers indeterminacy-preservation/review tasks.
- Prior corrections, stale memory, unappraised evidence, and concordant-but-not-independently-verified appraisals each produce distinct tasks.
- Plans are project-scoped and append-only.

## API
- `POST /api/cognitive-runtime/verification/plans`
- `GET /api/cognitive-runtime/verification/plans?project=default&limit=100`

## Request example
```json
{
  "project": "default",
  "reconciliation_id": "REPLACE_WITH_A_REAL_RECONCILIATION_ID",
  "max_tasks": 12
}
```

## Boundaries
- Planning only: no external acquisition, reviewer action, or answer release is executed.
- A planned task is not proof that verification occurred.
- No truth decision, automatic memory promotion, or model-weight update.
- Execution requires suitable inputs and separate authorization.
- D=0 remains indeterminate/F4; no U is calculated.

## Validation
- Full regression: 508 passed, 0 failed (isolated database).
- Python compileall: passed.
- Live external acquisition: not performed.
