# COGNISEEK TLM v6.1.0 — Governed Response Release

## Added
- Connects an existing v5.8 integrated evidence workflow to v5.9 company output governance.
- Adds `POST /api/cognitive-runtime/releases` and `GET /api/cognitive-runtime/releases`.
- Policy is evaluated before any response is released.
- A BLOCK decision prevents response generation/release.
- On ALLOW or ALLOW_WITH_WARNING, the runtime can release the existing deterministic evidence-grounded workflow response.
- Optional OpenAI-compatible model rendering is available with `use_model=true` when credentials/model configuration exist. The model receives only the already-produced workflow response as its evidence context and is treated as a renderer, not an evidence source.
- Release records are append-only and project-scoped.

## Boundaries
- This route requires an existing integrated evidence workflow. It does not invent findings or bypass the v5.9 governance evaluator.
- The policy evaluator remains authoritative for release permission.
- Caller-supplied actor/role remain prototype claims, not authenticated identity.
- LLM rendering can change wording and may introduce errors; generated text is not new evidence. Production should add output-level verification and signed identity controls.
- If no model is configured, deterministic evidence-grounded response is used.
- If policy blocks, no output is released.

## Validation
- Full regression suite: 380 passed.
- Python compilation: passed.
- ZIP integrity: passed.
