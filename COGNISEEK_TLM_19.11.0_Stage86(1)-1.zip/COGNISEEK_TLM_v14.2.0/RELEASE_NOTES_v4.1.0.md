# COGNISEEK TLM v4.1.0 — Continuous Episode Learning and Memory Consolidation

## Added
- `app/memory_consolidation.py` prepares a memory candidate from an episode only after at least one outcome has been recorded.
- Candidate preserves the original request, answer, evidence references and recorded outcomes as a source snapshot; it does not invent a generalized lesson.
- Explicit reviewer decisions: `APPROVE_FOR_CONTEXT`, `REJECT`, `REVOKE_CONTEXT`.
- Only the latest explicit approval permits project-scoped lexical retrieval into a distinct `approved_consolidated_experience_not_evidence` context channel.
- Retrieval, review and candidate history are append-only.
- `/api/chat` now includes approved consolidated experience in a separate context channel.
- APIs:
  - `POST /api/memory/consolidation/prepare`
  - `POST /api/memory/consolidation/reviews`
  - `GET /api/memory/consolidation/history`
  - `POST /api/memory/consolidation/retrieve`

## Safeguards and limitations
- No outcome means no candidate.
- No automatic approval, semantic synthesis, generalized learning, or weight update.
- Reviewer outcome labels are review signals, not ground truth.
- Approved material remains historical precedent, not current evidence.
- Retrieval is lexical only and project-scoped.
- Rejection/revocation prevents future retrieval without deleting prior records.
- No deployment or live model calls during validation.
