# COGNISEEK v19.10.1 — Stage 85.1 Corrective Hardening

## Scope
This is an additive corrective release based on v19.10.0 Stage 85. The prior archive
is retained as the rollback reference. This release addresses the outstanding
security path-validation issue, timeout task-continuation risk, and known resource
leaks, and adds an explicit Docker deployment executor.

## Corrections
1. Production database paths now reject empty, relative, root, standard ephemeral,
   and temporary-looking paths including `/tmpfoo` and `/temporary-data`.
2. `app/main.py` performs production security validation before creating or opening
   application stores.
3. Timed `BoundedWorkPool.submit()` calls execute in an isolated child process.
   On timeout, the child is terminated and then killed if necessary. This is a
   hard process boundary, not a thread cancellation claim. Timed callables and
   results must be pickleable on platforms that use the `spawn` start method.
4. Persistent experience-memory SQLite connections are now explicitly closed.
5. TLM checkpoint reads use context-managed file access.
6. `app/stage85_deployment_executor.py` provides an explicit Docker build/run/health
   workflow. It refuses to deploy unless `execute=True`, production environment
   validation passes, the preflight passes, and Docker is installed.

## Deployment status
The deployment executor is implemented but has NOT been run in this environment:
Docker CLI is unavailable. Therefore this release does not claim a successful
Docker build, live container launch, TLS termination, external network exposure,
or production operation. An operator must run the documented deployment command
in an environment with Docker and a reviewed production env file.

## Important timeout semantics
A timeout can terminate the isolated child process. It cannot guarantee rollback
of external side effects that the child performed before termination (for example,
a database write or remote request). Such operations must be idempotent or use
transactions/compensation.

## Validation
See `STAGE_85_1_VALIDATION_REPORT.md` for the actual test and environment results.
