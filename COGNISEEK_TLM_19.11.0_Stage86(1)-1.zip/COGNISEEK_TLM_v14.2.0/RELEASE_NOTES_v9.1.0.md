# COGNISEEK TLM v9.1.0 — Evidence-Grounded Answer Generation and Release Bridge

## Purpose
Connect a v9.0 unified decision cycle to an existing integrated evidence workflow and its deterministic evidence-grounded response, then apply company output policy before release.

## New API
- `POST /api/cognitive-runtime/answer-release-bridges`
- `GET /api/cognitive-runtime/answer-release-bridges`
- `GET /api/cognitive-runtime/answer-release-bridges/{bridge_id}`

## Release controls
- Requires exact project-scoped cycle and workflow IDs.
- Requires exact equality between current-cycle evidence references and workflow finding IDs.
- Requires an existing deterministic response from the integrated workflow.
- Reuses existing company policy evaluation; BLOCK withholds response text.
- Stores an append-only bridge record with response, workflow, decision and evidence references.

## Boundaries
- Historical memory is never treated as answer evidence.
- No new model-generated claims are added.
- Actor and role are caller-supplied metadata, not authenticated identity.
- No source authenticity, scientific truth, or causality is certified.
- No model-weight update or execution authorization is performed.

## Compatibility
Builds on v9.0.0 without modifying its decision-cycle behavior.
