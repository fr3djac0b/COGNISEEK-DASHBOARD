# COGNISEEK TLM v9.7.0
## Decision-to-Answer Governance Bridge

### Purpose
Connects an episode-linked v9.6 sufficiency decision to the existing reviewer-coded claim-grounding pipeline. It creates an answer-preparation package, not a released answer.

### New API
- `POST /api/cognitive-runtime/answer-packages`
- `GET /api/cognitive-runtime/answer-packages`

POST fields:
- `project`
- `decision_id`
- `draft`
- `reviewer`
- `min_distinct_records` (1–20; default 2)

### Gate behavior
A package is prepared as `QUALIFIED_DRAFT_PREPARED` only when:
1. The v9.6 decision exists in the requested project.
2. Its status is `REVIEWABLE_WITH_LIMITATIONS`.
3. The draft contains an exact claim-text match for the decision's target claim.
4. The existing grounding pipeline marks that claim `SUPPORTED_FOR_REVIEW`.
5. The distinct reviewed-passage threshold is met.

Otherwise, the package is `BLOCKED`, the draft is not included, and reasons are recorded.

### Controls
- Uses the existing reviewer-coded passage grounding pipeline.
- Does not generate new factual claims or rewrite the supplied draft.
- Preserves the claim-level evidence ledger.
- Append-only answer preparation history.
- No publication, external delivery, policy release, or execution authorization.
- No source independence or truth certification.

A qualified package is still a review artifact. Existing company policy and authenticated authorization remain separate requirements for any future release.
