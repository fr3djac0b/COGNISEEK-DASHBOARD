# COGNISEEK TLM v14.3.0 — Stage 28

## Stage 28: Structured Semantic Claim-Support Assessment

### Added
- `app/stage28_semantic_assessment.py`
- `build_review_packet`: prepares a passage-specific semantic review packet without automatically assigning a direction.
- `packet_from_grounded_claim`: imports only exact passages already resolved in a Stage 27 claim ledger, with project and claim identity checks.
- `record_assessment`: records a reviewer-coded direction and a complete eight-dimension semantic rubric.
- `summarize_assessments`: preserves supporting, contradicting, mixed, neutral and indeterminate states.
- `history`: provides append-only, project-scoped reviewer assessment history.
- Seven original Stage 28 tests plus two Stage 27-to-28 integration tests.

### Semantic rubric
Directness, scope match, polarity match, temporality match, modality match, population match, causal match and completeness.

### Boundaries
- No automated semantic direction inference.
- No external model/API dependency.
- No source-truth certification, entailment certification or calibrated confidence.
- Reviewer assessments remain provisional human judgements.
- INDETERMINATE is preserved separately from NEUTRAL.
- Mixed supporting and contradicting evidence remains MIXED_EVIDENCE.
- No public API route added.
- No model-weight update or autonomous learning added.

### Preservation
The protected `app/research/m_rbam.py` source remains byte-for-byte unchanged. Its SHA256 remains:
`5bcafd59da496342370c9877510a9e4e67cd8f9107be76d21377cce12340bf84`
