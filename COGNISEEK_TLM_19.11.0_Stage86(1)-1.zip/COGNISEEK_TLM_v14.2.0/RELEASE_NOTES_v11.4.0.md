# COGNISEEK TLM v11.4.0 — Multi-User Identity, Permissions and Security

## Objective
Strengthen authenticated access to high-impact memory and governed-release operations by using the existing OIDC/JWT identity provider rather than caller-supplied actor/role fields.

## Additions
- `app/api_identity_authorization.py`
  - Verifies bearer JWTs through the existing `identity_provider.verify_bearer_token`.
  - Requires configured issuer, audience and JWKS URL through the existing provider.
  - Enforces signed project membership and mapped roles.
  - Supports ADMIN, REVIEWER, OPERATOR and VIEWER access classes; ADMIN can satisfy lower privilege gates.
  - Records allow/deny outcomes in a project-scoped append-only authorization audit.
- Protected API routes:
  - Governed answer release: ADMIN or OPERATOR.
  - Governed release history: any authenticated project member role.
  - Memory retrieval and memory lifecycle history: any authenticated project member role.
  - Memory consolidation candidate preparation: ADMIN or OPERATOR.
  - Memory consolidation review: ADMIN or REVIEWER.
  - Identity authorization audit history: ADMIN only.
- `identity_provider.py` default external role map now includes `reviewer -> REVIEWER`. Deployments can still override mappings with `COGNISEEK_ROLE_MAP_JSON`.

## Security behaviour
- Missing/invalid bearer credentials fail closed.
- Misconfigured OIDC returns a service-unavailable failure, not an anonymous fallback.
- Signed project membership is verified before route work.
- Caller-supplied `actor`, `role` and `reviewer` fields are ignored on the protected routes; trusted subject/role values are derived from the verified principal.
- Successful and denied authorization decisions are recorded.
- Existing global API-key middleware remains available as an additional perimeter control.

## Scope and limitations
- This release protects the explicitly listed v11.2/v11.3 high-impact routes and adds an audit view. It does not retrofit every legacy endpoint in the large application; other routes may still use their existing authorization patterns.
- OIDC issuer, audience, JWKS URL, role/project claims and role mapping must be configured by the deployment operator.
- PyJWT with cryptographic support, HTTPS/TLS, secure secret management, key rotation, and production-grade shared rate limiting remain deployment requirements.
- The current API-key middleware rate limiter is process-local and is not a substitute for a trusted gateway.
- No live identity-provider/JWKS integration test was performed; automated tests use controlled verified-principal test doubles.
- Authentication does not make submitted evidence true, and a role grant does not authorize operational execution outside the configured policy workflow.

## Mathematics
`app/research/m_rbam.py` remains byte-for-byte identical to v11.3.0. No M-RBAM formulas, categories, thresholds, or protocol behaviour were changed.
