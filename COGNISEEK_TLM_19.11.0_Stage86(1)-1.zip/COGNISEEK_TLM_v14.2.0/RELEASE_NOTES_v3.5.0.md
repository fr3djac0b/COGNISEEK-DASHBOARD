# COGNISEEK TLM v3.5.0 — Controlled Source Discovery

## Added
- `app/source_discovery.py`: optional Tavily Search API integration.
- Search queries can be project-scoped, bounded to 1–10 results, use basic/advanced depth, and optionally include exact domains.
- HTTPS candidate URLs are normalized; non-HTTPS URLs and malformed candidates are discarded.
- Duplicate candidate URLs within a search run are removed.
- Candidate records preserve title, URL, domain, snippet, provider score and provider-supplied publication-date field.
- Every candidate begins `CANDIDATE_REQUIRES_REVIEW`; evidence direction remains null.
- Append-only search-run audit.
- `GET /api/discovery/status`
- `POST /api/discovery/search`
- `GET /api/discovery/history`

## Configuration
Set `TAVILY_API_KEY` on the server. The key is never returned by status or search responses. Search requests are sent only to the fixed HTTPS Tavily API endpoint. No API key is included in frontend code.

## Workflow
1. Search discovers candidate URLs and snippets.
2. A human selects candidates.
3. Selected URLs are fetched separately through `/api/acquisition/fetch`, which still enforces the exact HTTPS host allowlist.
4. Retrieved content is ingested as unverified source material.
5. Existing claim extraction, evidence-link review, conflict analysis and grounded-answer controls remain responsible for subsequent appraisal.

## Boundaries
- Search snippets and rankings are not evidence direction, authority, authenticity, or truth.
- Provider-supplied publication dates are unverified metadata.
- Search does not fetch full pages or automatically ingest documents.
- No automatic candidate promotion, reviewer-direction inference, source independence certification, model training, weight updates, or deployment.
