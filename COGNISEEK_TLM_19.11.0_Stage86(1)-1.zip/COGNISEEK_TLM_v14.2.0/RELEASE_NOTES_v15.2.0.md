# COGNISEEK TLM v15.2.0 — Stage 37

Adds configurable multi-layer decoder stacking using grouped-query attention, bounded context windows, full-stack autodiff/Adam training and validated architecture-aware state round-trip. Prior TinyTLM and GroupedQueryTLM baselines remain available.
