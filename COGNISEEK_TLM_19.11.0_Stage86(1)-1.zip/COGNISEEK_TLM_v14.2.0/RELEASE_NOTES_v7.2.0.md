# COGNISEEK TLM v7.2.0 — Adaptive Evidence Acquisition

## Delivered
- Adaptive acquisition plan based on current project corpus and acquisition diagnostics.
- Explicit operator opt-in before external acquisition.
- Bounded discovery and fetch execution using the existing Tavily discovery adapter and exact HTTPS host allowlist.
- Project-scoped plan storage and append-only execution events.
- Search results remain candidate metadata; fetched content remains unappraised (`D=0`, `UNAPPRAISED`).
- Explicit `SUFFICIENCY_NOT_ESTABLISHED` result; no majority-vote or automatic truth decision.

## API
- `POST /api/cognitive-runtime/acquisition/plans`
- `POST /api/cognitive-runtime/acquisition/plans/{plan_id}/execute?project=...`
- `GET /api/cognitive-runtime/acquisition/plans?project=...`
- `GET /api/cognitive-runtime/acquisition/plans/{plan_id}?project=...`

## Configuration
External execution requires:
- `TAVILY_API_KEY` for candidate discovery.
- `COGNISEEK_FETCH_ALLOWED_DOMAINS` configured with exact hostnames for controlled HTTPS retrieval.
- Request-level `allow_external_acquisition=true`.

No wildcard domains are accepted by the underlying acquisition layer. The test suite uses mocks and does not make live external requests.

## Boundaries
- Search snippets and ranking are not evidence direction.
- Retrieval does not authenticate a publisher or prove source independence.
- New acquisitions remain neutral/unappraised until a reviewer appraises them.
- The planner's sufficiency state is always `SUFFICIENCY_NOT_ESTABLISHED`.
- The prototype does not establish scientific truth or train foundation-model weights.
