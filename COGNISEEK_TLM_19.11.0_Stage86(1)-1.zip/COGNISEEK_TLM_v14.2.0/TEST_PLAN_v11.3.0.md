# v11.3.0 Test Plan

1. Adaptive retrieval delegates to the existing retrieval engine.
2. Selected memory IDs and retrieval metadata are written to the lifecycle ledger.
3. Actor identity metadata is required for recorded actions.
4. Consolidation candidate preparation delegates to the existing outcome-linked module.
5. Preparation requires an explicit rationale.
6. Review and revocation delegate to the existing append-only review engine.
7. Review action and retrieval effect are recorded in the ledger.
8. Project-scoped history does not leak other projects' events.
9. History validates pagination limits and preserves append-only records.
10. Memory remains historical context and is not treated as current evidence.
11. Four API routes register and the FastAPI application imports.
12. Full inherited regression suite runs with a fresh isolated database.
13. Compile all app and test Python files.
14. Confirm M-RBAM math source is byte-for-byte unchanged.
15. Verify ZIP integrity and release manifest.
