# COGNISEEK TLM v12.6.0

## Milestone
**Evidence Provenance Chain and Integrity Verification**

This release adds a reusable, project-scoped append-only provenance event ledger.
Each event records its type, subject, payload, timestamp, prior-event hash and
current event hash. A verifier recomputes the chain and reports broken links or
altered event payloads.

## New component
- `app/provenance_chain.py`
  - `initialize(db)` creates the ledger table and project/sequence index.
  - `append_event(db, project, event_type, subject_id, payload)` appends a
    canonicalized event and links it to the preceding project event.
  - `verify_chain(db, project, limit=10000)` verifies ordering and event hashes.
  - `history(db, project, limit=1000)` returns project-scoped event history.
- `tests/test_v12_6_provenance_chain.py` adds five tests for continuity,
  project isolation, payload-tampering detection, required metadata and limits.

## Integrity model
For event payload `E_n` and prior hash `H_(n-1)`:

`H_n = SHA256(H_(n-1) || newline || canonical_json(E_n))`

The first event in each project starts from `GENESIS`. Canonical JSON uses sorted
keys, compact separators and UTF-8 encoding. A change to a stored event payload,
or a broken link to the previous hash, is reported as `INTEGRITY_FAILURE`.

## Governance boundaries
- Project chains are isolated from one another.
- Events are append-only through this module's API; no update/delete function is
  provided.
- The ledger records provenance metadata; it does not authenticate publishers,
  prove source independence, verify claim truth, or make an evidence item reliable.
- A hash chain is tamper-evident, not tamper-proof. A database administrator who
  can rewrite the entire database and recompute every hash can rewrite the chain.
  Production use should anchor periodic chain heads in independently controlled,
  write-once storage or a separately administered signing service.
- This milestone is a reusable module, not yet connected to HTTP routes or the
  source-acquisition workflow. Route integration and trusted chain-head anchoring
  remain follow-on work.

## Scientific boundary
No M-RBAM formulas, thresholds, category definitions, appraisal rules or
longitudinal calculations were changed. The M-RBAM source file is unchanged
byte-for-byte from v12.5.0.
