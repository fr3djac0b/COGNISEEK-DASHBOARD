# COGNISEEK TLM v0.6.0

## Added
- M-RBAM research-only episode workbench in the web interface.
- Persistent episode records with protocol version and auditable classification output.
- `Delta_A` and evidence-normalized `U` calculation with missing-value preservation.
- Separate QAAT, UAT and CAR trajectory endpoint.
- Explicit protocol profiles: strict alignment F1–F3 + UC/NA, and experimental directional F1–F4.
- Timestamp consistency flags and duplicate-evidence flags in the research result.
- Assistant safety instructions to prevent research classification from being presented as clinical diagnosis or treatment guidance.

## Important limitations
- The default 0–10 alignment boundaries are provisional examples, not validated cut-offs.
- No patient data should be used before protocol, SAP, ethics and privacy review.
- No automatic training or model-parameter update occurs.
- No diagnosis, treatment recommendation, or clinician replacement is provided.
- This does not prove predictive value, causal mechanisms, or clinical validity.
