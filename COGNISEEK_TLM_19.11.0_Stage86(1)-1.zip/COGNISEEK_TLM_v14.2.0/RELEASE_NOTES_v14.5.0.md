# COGNISEEK TLM v14.5.0 — Stage 30

## Stage 30: TLM Neural Architecture Specification

### Added
- `app/tlm_architecture.py`
- Validated decoder-only autoregressive Transformer configuration.
- Parameter-count estimator for grouped-query attention, SwiGLU feed-forward layers, RMSNorm and tied/untied embeddings.
- Causal attention visibility planner.
- Episode-aware trajectory segment planner and context-window overflow reporting.
- Deterministic architecture manifest and internal consistency validator.
- Twelve focused tests.

### Proposed architecture
Learned token embeddings; rotary positional embeddings; causal grouped-query self-attention; pre-normalized RMSNorm residual blocks; SwiGLU feed-forward networks; vocabulary projection.

### Boundaries
This is an executable architecture specification and shape planner only. It does not instantiate neural layers or tensors, train weights, implement a tokenizer, create checkpoints or provide independent inference. No external ML framework dependency is added. Training objectives in the manifest are proposals only.

### Preservation
Protected M-RBAM source remains byte-for-byte unchanged:
`5bcafd59da496342370c9877510a9e4e67cd8f9107be76d21377cce12340bf84`
