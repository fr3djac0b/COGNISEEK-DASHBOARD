# COGNISEEK TLM v12.0.0 — API Route Governance Register

## Added
- `app/route_governance_registry.py` creates a structured inventory for every FastAPI method/path entry.
- Each entry records risk, sensitivity prompt, ownership-scope prompt, review status, authorization status, registered policy (if any), required roles (if known), public-status declaration, and whether automated remediation occurred.
- `scripts/build_route_governance_register.py` generates `ROUTE_GOVERNANCE_REGISTER.json`.
- Seven existing role policies are mapped explicitly.
- Added tests for route coverage, no inferred public routes, policy mapping, conservative review status, and the distinction between source-detected guards and confirmed role policies.

## Safety and scope
This is a governance inventory, not an endpoint authorization change. It assigns no new roles to legacy endpoints, makes no route public, and does not automatically remediate anything. Data sensitivity and project ownership labels are review prompts, not verified lineage. Unreviewed does not mean public.

## Preservation
`app/research/m_rbam.py` is unchanged. No M-RBAM formulas, thresholds, labels, or protocol definitions were modified.
