# COGNISEEK TLM v4.7.0 — Evidence Dependency and Corroboration Intelligence

## Added
- Candidate-level dependency diagnostics across exact document IDs, source URIs, content hashes, and user-supplied source-group hints.
- Shared publisher is displayed as context, not automatically treated as dependency.
- Reviewer-declared candidate relationships: `DERIVED_FROM`, `DUPLICATES`, `CITES`, `SHARES_DATASET`, and `SAME_ORIGIN`.
- Every declared relationship requires a reviewer and rationale and is stored as an append-only event.
- Claim-focused corroboration reports identify potential shared-origin signals and distinguish them from no detected signal.
- Append-only project-scoped corroboration report history.

## APIs
- `POST /api/evidence/dependencies`
- `POST /api/evidence/corroboration/analyze`
- `GET /api/evidence/corroboration/history`

## Interpretation and limits
- A detected dependency signal is a clue requiring review, not proof of common origin.
- No detected dependency signal is not proof of independence.
- Different publishers, URLs, or hashes do not establish independent methods, data, ownership, or citations.
- Reviewer agreement remains separate from source independence.
- The module does not certify independent corroboration, determine truth, assign evidence direction, train model weights, or deploy a model.
