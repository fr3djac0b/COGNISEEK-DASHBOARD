# v12.0.0 Test Plan

1. Generate a governance register for all FastAPI method/path entries.
2. Verify every entry has a non-public, explicitly unknown public status.
3. Verify exactly the seven existing role policies are assigned.
4. Verify source-detected guards without a registered policy remain marked for semantic review.
5. Verify unreviewed sensitive or mutating routes are not automatically remediated.
6. Run focused tests and the full regression suite with isolated SQLite.
7. Run compileall and FastAPI import.
8. Verify M-RBAM source byte-for-byte unchanged.
9. Verify ZIP integrity.
