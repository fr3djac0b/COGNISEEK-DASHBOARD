# COGNISEEK TLM v14.6.0 — Stage 31

Adds a deterministic UTF-8 byte-level BPE tokenizer with trajectory-aware special tokens,
corpus training, reversible encoding/decoding, JSON persistence and SHA-256 model integrity.
Includes multilingual, determinism, persistence, limits and special-token tests.

This release does not train neural-network weights or deliver a standalone generative model.
See `docs/STAGE31_TLM_TOKENIZER_v14.6.0.md`.
