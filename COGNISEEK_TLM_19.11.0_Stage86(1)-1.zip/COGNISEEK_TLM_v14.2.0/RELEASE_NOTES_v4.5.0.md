# COGNISEEK TLM v4.5.0 — Claim Verification and Safe Decision Execution

## Added
- Append-only, project-scoped claim/source review events tied to exact stored passage IDs.
- Review states separate topical relevance from evidence direction:
  - `REVIEWED_RELEVANT` and `REVIEWED_NOT_RELEVANT` do not assign a direction.
  - `REVIEWED_SUPPORTS`, `REVIEWED_CONTRADICTS`, `REVIEWED_NEUTRAL`, and `REVIEWED_INDETERMINATE` preserve reviewer-entered distinctions.
  - `CANDIDATE_REQUIRES_REVIEW` remains provisional.
- Conflicting reviews for the same passage are preserved as separate events; no winner is selected.
- Safe internal execution of acquisition plans with exact project/plan/action matching.
- External acquisition plans cannot be executed through this endpoint; live discovery/fetch remains a separate, controlled workflow.

## APIs
- `POST /api/verification/claim-source/reviews`
- `GET /api/verification/claim-source/reviews`
- `POST /api/acquisition/decision-plan/execute`
- `GET /api/acquisition/decision-executions`

## Safety and scope
- Candidate passage must exist in the same project at review time.
- Reviewer identity and rationale are required.
- The execution endpoint only stages internal work for an operator; it does not perform search or fetch.
- Reviewer classifications are not ground truth. Relevance is not support. Conflicting directions remain unresolved.
- This release does not authenticate sources, prove source independence, run a validated entailment model, decide truth, train model weights, or deploy a model.
