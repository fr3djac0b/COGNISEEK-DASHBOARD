# COGNISEEK TLM v4.6.0 — Reviewer Disagreement and Consensus Reporting

## Added
- Transparent consensus report over exact project-scoped target claims.
- One latest assessment per distinct reviewer is used for the current agreement calculation; earlier events remain preserved in the report.
- Repeated submissions by one reviewer do not inflate the reviewer count.
- Unanimous directional agreement is reported only when the minimum distinct reviewer count is met and all counted reviewers agree.
- Majority opinion never overrides a minority assessment. Any directional disagreement returns `UNRESOLVED_REVIEWER_DISAGREEMENT` with no consensus direction.
- `NEUTRAL` and `INDETERMINATE` remain distinct; relevance-only labels never count as evidence direction.
- Same-passage conflicts and reviewers who changed their assessments are surfaced.
- Consensus report snapshots are append-only.

## APIs
- `POST /api/verification/consensus`
- `GET /api/verification/consensus/history`

## Interpretation and limits
- `REVIEWER_CONSENSUS` means recorded reviewer agreement, not factual truth.
- Reviewers may share assumptions or sources; agreement does not prove independence.
- The report uses the latest review event per reviewer for the current assessment, while retaining earlier event IDs and review history.
- No automatic source adjudication, majority override, truth scoring, model training, weight update, or deployment.
