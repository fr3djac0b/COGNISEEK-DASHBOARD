# Explicit Docker deployment — Stage 85.1

1. Install Docker Engine and ensure the operator account can access the Docker daemon.
2. Create a production env file outside the repository, with at least:
   - `APP_AUTH_TOKEN` (at least 32 characters, generated securely)
   - `CORS_ORIGINS` (explicit HTTPS origin; never `*`)
   - Any model/provider secrets required by the chosen deployment
3. Do not put secrets in Git or in the ZIP archive.
4. Create a persistent host directory for database and application state.
5. From the project root, run:

```bash
APP_ENV=production python -c "from app.stage85_deployment_executor import deploy; print(deploy('.', env_file='/secure/path/cogniseek.env', data_dir='/srv/cogniseek-data', host_port=8000, execute=True))"
```

The runner builds the image, replaces a container with the configured name, mounts
persistent storage at `/var/data`, starts the service bound to localhost, and polls
`/health`. Put a reviewed TLS reverse proxy in front before exposing it publicly.

The command is intentionally opt-in and is not run automatically by application
startup. Test backup and restore before accepting production user data.
