# v11.7.0 Test Plan

1. Verify project membership is rechecked at the API authorization boundary.
2. Verify cross-project requests are denied and audited.
3. Verify role escalation is denied.
4. Verify ADMIN can satisfy lower-privilege role gates.
5. Verify seven explicit route policies and fail-closed behavior for unknown policy names.
6. Run focused authorization tests.
7. Run the full regression suite with a fresh isolated SQLite database.
8. Run compileall and import the FastAPI app.
9. Verify M-RBAM source is byte-for-byte unchanged from v11.6.0.
10. Verify ZIP archive integrity.
