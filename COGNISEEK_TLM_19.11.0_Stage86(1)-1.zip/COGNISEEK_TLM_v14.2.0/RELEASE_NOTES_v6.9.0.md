# COGNISEEK TLM v6.9.0 — Cross-Episode Learning and Controlled Memory Consolidation

## Purpose
Adds a controlled path from recorded episode outcomes to candidate long-term memory. Candidate generation and approval are separate operations. Only an explicit reviewer approval writes an item into the existing reviewed-memory store.

## Added
- Append-only candidate ledger: `cognitive_memory_candidates`.
- Append-only reviewer decision ledger: `cognitive_memory_candidate_events`.
- Candidate proposal API: `POST /api/cognitive-runtime/memory/candidates/propose`.
- Candidate listing API: `GET /api/cognitive-runtime/memory/candidates`.
- Review API: `POST /api/cognitive-runtime/memory/candidates/review`.
- Consolidation diagnostics API: `GET /api/cognitive-runtime/memory/consolidation-diagnostics`.
- Provenance links to source episode, outcome record, and evidence references.
- Duplicate candidate prevention by project and outcome ID.

## Workflow
1. An episode is created through the existing runtime.
2. A caller records an outcome against that episode.
3. Candidate proposal scans recorded outcomes.
4. Confirmed outcomes can generate episodic candidates.
5. Corrected/rejected outcomes generate candidates only when correction text is supplied.
6. Inconclusive and follow-up outcomes are not promoted.
7. A reviewer explicitly approves or rejects each candidate.
8. Approval creates an item in the existing reviewed-memory store; rejection remains in the candidate history.

## Guardrails
- Candidate generation is not approval.
- Outcomes are caller-supplied and not independently verified.
- A confirmed outcome does not prove every statement in the episode.
- Corrections remain associated with their original episode and outcome.
- Rejected candidates remain auditable.
- Reviewer identity and rationale are caller-supplied; no reviewer authentication is implemented.
- Approval updates persistent application memory only. It does not fine-tune or update LLM weights.
- No universal rule is inferred automatically from a single episode.

## Validation
- Full regression suite: 452 passed.
- New v6.9 focused tests: 14 passed (included in full regression).
- Python compileall: PASS.
- ZIP integrity: PASS.
- Isolated temporary SQLite database used; no production/user database modified.
- No live external acquisition performed.
