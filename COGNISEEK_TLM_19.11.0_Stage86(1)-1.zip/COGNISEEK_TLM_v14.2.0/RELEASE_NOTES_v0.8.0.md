# COGNISEEK TLM v0.8.0 — Local Document Retrieval

## Added
- User-supplied text document ingestion with source metadata.
- SHA-256 content duplicate detection within each project.
- Paragraph/sentence chunking with bounded chunk size.
- Transparent lexical retrieval using an IDF-weighted term-frequency ranking.
- Project-scoped document listing and retrieval APIs.
- Chat context can include retrieved passages, explicitly labelled unverified.

## API
- `POST /api/documents`
- `GET /api/documents?project=...`
- `GET /api/retrieval/search?q=...&project=...&limit=8`

## Boundaries
- No live web crawling or URL fetching.
- No PDF/DOCX extraction yet; submit extracted text.
- No embeddings or semantic vector retrieval.
- Retrieval score is relevance only, not truth or source quality.
- Retrieved passages are marked unverified; no automatic evidence direction is assigned.
- No external source is independently authenticated.
