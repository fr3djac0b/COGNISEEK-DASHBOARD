# COGNISEEK TLM v12.1.0

## Milestone
**Evidence, Memory, Learning and Episode Route Review**

This release advances the v12.0 governance register with a source-level,
read-only review of 48 route declarations across evidence, memory, learning,
and episode API families.

## Findings
- 48 route declarations reviewed across 48 unique method/path pairs.
- 27 declare a `project` parameter, but the source review does not establish
  that authorization or project ownership is enforced.
- 21 accept a payload and require payload ownership and downstream data-access
  review.
- 0 of the reviewed handlers contain a detected explicit authorization helper
  call in their own function body.
- 0 duplicate method/path declarations in this scoped source batch.
- 0 routes modified.

These are source-review observations, not proof of exploitable vulnerabilities.
The scanner is intentionally conservative and does not resolve helper behavior,
database query semantics, middleware effects, or every indirect authorization
path. The complete route set is not certified by this milestone.

## Added
- `app/route_semantic_review.py` — read-only AST-based route review.
- `scripts/build_route_semantic_review.py` — reproducible JSON report generator.
- `ROUTE_SEMANTIC_REVIEW_v12.1.0.json` — generated review report.
- `tests/test_v12_1_route_semantic_review.py` — focused regression tests.
- Release test plan, results, and manifest.

## Safety and compatibility
- No endpoint access behavior changed.
- No role policy was added or broadened.
- No endpoint was classified as public or secure.
- Existing v12.0 route governance register remains intact.
- M-RBAM mathematics and source remain unchanged.
