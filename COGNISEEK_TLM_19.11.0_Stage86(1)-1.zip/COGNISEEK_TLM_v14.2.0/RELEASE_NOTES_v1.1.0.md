# COGNISEEK TLM v1.1.0 — Evidence Intelligence Foundation

## Added
- Candidate claim extraction from ingested document chunks using transparent sentence segmentation.
- Claim comparison heuristic using token overlap and negation cues. Results are explicitly review candidates, not entailment or contradiction findings.
- Evidence-direction appraisal with four distinct states: SUPPORTS, CONTRADICTS, NEUTRAL, INDETERMINATE.
- Explicit abstention for indeterminate-only evidence, mixed supporting/contradicting evidence, and insufficient source-group diversity hints.
- Append-only appraisal snapshots with project-scoped history.
- API endpoints:
  - `POST /api/claims/extract`
  - `GET /api/claims/candidates`
  - `POST /api/claims/compare`
  - `POST /api/claims/appraise`
  - `GET /api/claims/appraisals`

## Important boundaries
- Sentence segmentation is not semantic claim extraction; candidate sentences require review.
- Direction labels are supplied by the caller. The system does not independently infer evidence direction.
- Source groups are user-supplied dependency hints, not proof of source independence.
- Provisional support/contradiction is not a truth verdict, probability, or calibrated confidence.
- No external source authentication, live web fact-checking, or model-weight training is performed.
- Existing v1.0 hybrid lexical/optional semantic retrieval remains unchanged.
