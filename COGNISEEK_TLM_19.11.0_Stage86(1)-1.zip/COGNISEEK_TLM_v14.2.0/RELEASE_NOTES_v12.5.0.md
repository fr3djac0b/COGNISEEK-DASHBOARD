# COGNISEEK TLM v12.5.0

## Milestone
**Experience Integrity and Learning Promotion Governance**

This release adds verified-identity and project-membership authorization to 11
experience-learning API method/path entries. It governs who may stage an
experience, review a candidate, apply contextual experience, review an
application, inspect reliability, and invoke governed experience reasoning.

## Newly protected routes

| Method | Route | Roles |
|---|---|---|
| POST | `/api/cognitive-runtime/learning/experience-candidates` | ADMIN, OPERATOR |
| POST | `/api/cognitive-runtime/learning/experience-candidates/review` | ADMIN, REVIEWER |
| GET | `/api/cognitive-runtime/learning/experience-candidates` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| POST | `/api/cognitive-runtime/learning/experience-applications` | ADMIN, OPERATOR |
| POST | `/api/cognitive-runtime/learning/experience-applications/review` | ADMIN, REVIEWER |
| GET | `/api/cognitive-runtime/learning/experience-applications` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| GET | `/api/cognitive-runtime/learning/experience-reliability/{candidate_id}` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| GET | `/api/cognitive-runtime/learning/experience-reliability` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| GET | `/api/cognitive-runtime/learning/experience-selection` | ADMIN, REVIEWER, OPERATOR, VIEWER |
| POST | `/api/cognitive-runtime/learning/experience-reasoning` | ADMIN, OPERATOR |
| POST | `/api/cognitive-runtime/learning/governed-experience-application` | ADMIN, OPERATOR |

## Governance boundaries

- Candidate staging and contextual experience application require ADMIN or OPERATOR.
- Candidate and application review decisions require ADMIN or REVIEWER.
- Reliability, selection and history reads require verified project membership.
- Experience reasoning and governed application require ADMIN or OPERATOR.
- The existing authorization boundary verifies the bearer identity and project membership.
- Authorization decisions are not scientific validation; access permission does not prove an experience is true.
- Reviewed historical experience remains contextual input, not a replacement for current evidence.
- No M-RBAM formulas, thresholds, category definitions or appraisal rules were changed.

## Verification

- New v12.5 authorization tests: 9 passed.
- v12.3 + v12.4 + v12.5 focused authorization tests: 28 passed.
- Full regression suite: 812 passed, 0 failed.
- Python compileall: PASS.
- FastAPI import: PASS; 307 routes registered.
- Route governance register: 299 entries; 45 explicit role policies; 197 review-required;
  57 unclassified; 0 declared public.
- M-RBAM source unchanged byte-for-byte from v12.4.0 baseline.
- M-RBAM SHA-256: `5bcafd59da496342370c9877510a9e4e67cd8f9107be76d21377cce12340bf84`.

## Scope limitations

This is a selected route remediation, not a complete API security certification.
The remaining 197 review-required and 57 unclassified entries still need semantic
review. Live identity-provider/JWKS validation, deployed penetration testing,
and external security certification were not performed.
