# COGNISEEK TLM v16.0.0

**Stage 45 — Persistent Experience and Memory**

This release adds an opt-in, standalone SQLite episodic-memory module. It stores interaction episodes with provenance and evidence references, appends corrections without overwriting originals, retrieves relevant experiences with temporal decay, and exports auditable JSONL records with SHA-256 hashes.

**Preservation guarantee:** all files present in v15.9.0 are copied byte-for-byte. No existing source file is modified. The new module is not wired into existing inference paths.

See `docs/STAGE45_PERSISTENT_EXPERIENCE_MEMORY_v16.0.0.md` for API, retrieval scoring, governance, and limitations.
