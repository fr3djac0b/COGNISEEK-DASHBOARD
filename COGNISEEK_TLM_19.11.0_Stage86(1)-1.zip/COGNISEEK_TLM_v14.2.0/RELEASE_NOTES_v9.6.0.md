# COGNISEEK TLM v9.6.0
## Evidence Sufficiency Decision Engine

Adds a transparent, episode-linked decision profile built from the v9.5 reviewer-defined claim coverage and v9.4 corroboration assessment.

### Decision statuses
- `MIXED_OR_CONFLICTING_EVIDENCE`
- `INDETERMINATE_EVIDENCE`
- `ADDITIONAL_EVIDENCE_REQUIRED`
- `SOURCE_DEPENDENCY_REVIEW_REQUIRED`
- `REVIEWABLE_WITH_LIMITATIONS`

The engine does not issue a `SUFFICIENT_FOR_TRUTH` state. Even complete reviewer-marked coverage only makes a claim reviewable with limitations; it does not certify truth, source independence, methodology, answer release, or action authorization.

### API
- `POST /api/cognitive-runtime/sufficiency-decisions`
- `GET /api/cognitive-runtime/sufficiency-decisions`

POST body:
`project`, `orchestration_id`, `coverage_id`, `target_claim`, `reviewer`.

### Decision discipline
- Preserves reviewer-entered direction counts and contradictory directions.
- Treats `INDETERMINATE` distinctly from `NEUTRAL`.
- Does not use majority voting or an opaque aggregate score.
- Flags uncovered, partially covered, and indeterminate claim aspects.
- Treats source-dependency diagnostics as review warnings, not automatic disqualification.
- Marks methodological appraisal `NOT_ASSESSED` rather than assuming quality.
- Stores append-only decision snapshots.
- Does not generate or release an answer, authorize execution, or certify truth.

No live external acquisition is performed by this release or its tests.
