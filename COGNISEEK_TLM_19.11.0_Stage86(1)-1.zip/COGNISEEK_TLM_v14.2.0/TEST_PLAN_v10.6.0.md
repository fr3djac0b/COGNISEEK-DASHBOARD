# v10.6.0 Test Plan
- Source provenance assessment for successful acquisition.
- Operator trusted-domain registry match and non-match.
- Missing hash / failed acquisition.
- Project isolation and unknown acquisition rejection.
- Append-only assessment history.
- Full inherited v10.5 regression suite.
- Compile and fresh-process API import checks.
