# Stage 85.4 — Docker deployment verification

The repository includes a Dockerfile and this Compose deployment profile. It is
a deployment recipe, not evidence of a successful deployment.

Before use:
1. Install Docker Engine and the Compose plugin.
2. Create a protected production environment file; do not commit secrets.
3. Confirm the application binds to port 8000 and exposes `/health`.
4. Review the image dependencies and run a vulnerability scan.
5. Run `COGNISEEK_ENV_FILE=/secure/path/cogniseek.env docker compose -f docker-compose.stage85.yml build`
6. Start with `COGNISEEK_ENV_FILE=/secure/path/cogniseek.env docker compose -f docker-compose.stage85.yml up -d`
7. Check `docker compose ... ps`, logs, `/health`, persistent data after restart.
8. Configure TLS with a separately managed reverse proxy before public exposure.

This execution environment has no Docker CLI. No build, container launch, health
check, volume persistence, restart or TLS verification is claimed.
