# COGNISEEK TLM v2.7.0 — Evidence Verification and Source Intelligence

## Added
- Sentence-level claim candidates extracted from stored document chunks.
- Exact chunk provenance and character offsets retained for every candidate.
- Candidates remain `CANDIDATE_REQUIRES_REVIEW`; extraction does not verify atomicity or truth.
- Append-only reviewer links assign `SUPPORTS`, `CONTRADICTS`, `NEUTRAL`, or `INDETERMINATE`.
- Claim reports summarize reviewer-coded links, distinct passage IDs, and same-passage direction conflicts.
- Acquisition history grouped into observed URL snapshots; content hashes show whether retrieved bytes changed.
- User-triggered recheck reuses the prior requested URL, obeys the existing exact HTTPS allowlist, and creates a new acquisition event/document snapshot rather than overwriting history.
- Dependency hints surface repeated domains and hashes without certifying source independence.

## API
- `POST /api/intelligence/claims/extract`
- `GET /api/intelligence/claims`
- `POST /api/intelligence/claims/links`
- `GET /api/intelligence/claims/report?project=default&target_claim=...`
- `POST /api/acquisition/recheck`
- `GET /api/acquisition/versions`

## Important limitations
- Sentence splitting is heuristic; candidates are not guaranteed atomic propositions.
- No bundled natural-language-inference model or verified semantic entailment.
- No automatic evidence direction assignment.
- Reviewer labels are human judgments, not ground truth.
- Domain/hash overlap is only a dependency hint; no source independence certification.
- Recheck only works for URLs permitted by the operator-configured allowlist and supported content types.
- Existing v2.6 DNS check is not pinned to the outbound connection; DNS rebinding protection remains incomplete.
- No live acquisition, external source validation, deployment, authentication, or model-weight updates performed.
