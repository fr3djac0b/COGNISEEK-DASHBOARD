# COGNISEEK TLM v1.6.0

## Added
- Append-only expectation records with project, episode, subject, expected direction, optional confidence/appraisal, basis and evidence references.
- Later reviewer-coded observation records.
- Explicit comparison states: expectation-concordant, expectation-discordant, and indeterminate.
- Discordance flags without automatic conflict resolution.
- Project-scoped retrieval and descriptive trajectory evaluation.
- Validation and API tests for indeterminate evidence, discordance, append-only history and project isolation.

## Preserved
- v1.5 appraisal and outcome records remain intact.
- F4 remains reserved for evidence with no interpretable direction.
- Prior episodes and appraisal snapshots are not overwritten.

## Not implemented / limitations
- No automatic direction inference; reviewers supply direction.
- No automated truth adjudication or source-independence verification.
- No model-weight updates or online training.
- Optional confidence values are not calibrated probabilities; no accuracy/Brier/ECE claim.
- No authentication or per-user access control.
- No live external model/embedding provider test and no deployment.
