# COGNISEEK TLM v6.5.0 — Source Dependency and Lineage Diagnostics

## Added
- Append-only source-lineage declarations linked to a passage and runtime report.
- Supported relationship types:
  - `ORIGINAL_SOURCE`
  - `DERIVED_FROM`
  - `SAME_SOURCE_REPUBLICATION`
  - `UNKNOWN`
- Optional lineage-group labels and explicit derivation edges.
- Report-level source dependency diagnostics.
- Exact document/content identity overlap detection when document records are available.
- Explicit unknown-lineage coverage.

## New API
- `POST /api/cognitive-runtime/source-lineage`
- `GET /api/cognitive-runtime/reports/{report_id}/source-dependencies`

## Interpretation
- Exact matching content hashes or document IDs flag duplicate/overlapping material.
- Caller-declared shared lineage and derivation are surfaced as declarations, not verified facts.
- Unknown lineage is not independence.
- Independent source count remains `null`; the system does not invent a number.
- Passage count is not treated as source count.
- This module does not resolve conflicts, prove independence, or declare evidence sufficient.

## Validation
- Full clean-database regression: 401 passed, 0 failed.
- New v6.5 tests plus v6.4/v6.3 tests: 18 passed.
- Python compileall: passed.
- ZIP integrity: passed.
