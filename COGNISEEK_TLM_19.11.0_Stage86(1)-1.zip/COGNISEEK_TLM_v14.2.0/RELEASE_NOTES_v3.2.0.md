# COGNISEEK TLM v3.2.0 — Evidence-First Answer Engine

## What changed
- Introduces explicit context assembly that keeps current project evidence, retrieved document passages, and historical memory in separate channels.
- Deduplicates exact repeated record/passage identities in the assembled context and reports duplicate counts.
- Marks all assembled items as not independently verified; retrieval or storage does not confer truth.
- Strengthens model instructions to prevent historical assistant answers being treated as authoritative evidence and to preserve evidence gaps and conflicts.
- Adds post-generation exact-match grounding review against reviewer-coded claim/passage links.
- Stores an append-only answer evidence review record for chat-generated answers.
- Adds manual evidence-first review endpoint for arbitrary answer drafts.

## New API
- `POST /api/answer/evidence-first` — review a draft against reviewer-coded evidence links.
- `GET /api/answer/evidence-first/history` — retrieve append-only review records.

## Chat response additions
- `evidence_first_manifest`: counts and exact duplicate diagnostics by context channel.
- `answer_grounding_review`: claim-level evidence ledger, with QUALIFY/ABSTAIN action.
- `answer_evidence_review_record`: append-only audit identity.

## Limitations
- Grounding uses exact claim-text matches to reviewer-coded links; semantically equivalent wording may not match.
- Sentence splitting is heuristic and may not isolate atomic claims.
- Reviewer directions are judgments, not ground truth.
- Distinct passages are not necessarily independent sources.
- The post-generation review does not rewrite the generated answer or automatically certify it. Consumers must inspect claim-level instructions and preserve qualifications.
- No external web acquisition is initiated by this release.
- No model weights are trained or changed; no deployment is performed.
