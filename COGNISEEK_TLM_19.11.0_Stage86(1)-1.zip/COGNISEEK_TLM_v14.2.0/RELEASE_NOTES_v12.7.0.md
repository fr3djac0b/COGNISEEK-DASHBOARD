# COGNISEEK TLM v12.7.0

## Milestone
**Provenance Integration with Source Acquisition and Verification**

This release connects the v12.6 project-scoped provenance hash-chain ledger to
the existing source acquisition and source verification workflows.

## What changed
- Every acquisition attempt now appends a `SOURCE_ACQUISITION_RECORDED` event.
  Both successful and failed attempts are recorded, including the acquisition
  identifier, requested/final URL, host, retrieval status, HTTP status, content
  hash, byte count, document identifier and error code where applicable.
- Each acquisition response includes its provenance event identifier and hash.
- Each source verification assessment now appends a
  `SOURCE_VERIFICATION_ASSESSED` event containing the acquisition/document
  identifiers, content hash and the separate transport, domain-policy,
  integrity, publisher, publication-date, claim-truth and overall status fields.
- Each verification response includes its provenance event identifier and hash.
- Both event types share the same project-scoped chain, so their order is
  auditable across acquisition and subsequent verification.
- Added integration tests for successful acquisition followed by verification,
  failed acquisition recording, and project-isolated history.

## Integrity calculation
The existing v12.6 calculation remains unchanged:

`H_n = SHA256(H_(n-1) || newline || canonical_json(E_n))`

## Important interpretation limits
- A chain record proves that the application recorded an event payload; it does
  not prove the payload is true.
- A successful retrieval does not authenticate a publisher or author.
- Domain allowlist/trusted-domain membership is an operator policy signal, not
  independent source authentication.
- Repeated content can be recorded as duplicate content; duplicates are not
  independent corroboration.
- Hash chaining detects alteration when prior chain history is retained. It is
  not immutable storage, a digital signature, or protection against an
  administrator who can rewrite the whole database and recompute the chain.
- This release does not add a public HTTP endpoint for chain history or
  verification. The chain is integrated at the application workflow layer.

## Scientific boundary
No M-RBAM equations, thresholds, categories, appraisal rules, or longitudinal
calculations were modified. `app/research/m_rbam.py` is byte-for-byte identical
to the v12.6.0 baseline.
