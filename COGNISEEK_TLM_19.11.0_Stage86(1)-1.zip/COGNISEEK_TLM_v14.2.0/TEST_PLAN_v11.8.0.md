# v11.8.0 Test Plan

1. Probe a valid Project A principal against Project B authorization.
2. Verify authorization denials are recorded only in the requested project audit view.
3. Seed two projects in one database and verify memory lifecycle history separation.
4. Probe episode review status and history using the wrong project identifier.
5. Verify each project can read its own integrated run but not another project's run.
6. Probe a review reference that belongs to another project.
7. Run focused and full regression suites with an isolated SQLite database.
8. Run compileall and FastAPI import.
9. Verify M-RBAM source is byte-for-byte unchanged.
10. Verify release ZIP integrity.
