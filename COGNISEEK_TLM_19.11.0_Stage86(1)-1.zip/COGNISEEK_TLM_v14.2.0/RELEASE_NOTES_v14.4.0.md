# COGNISEEK TLM v14.4.0 — Stage 29

## Stage 29: Contradiction-Aware Evidence Reasoning

### Added
- `app/stage29_contradiction_reasoning.py`
- Compares Stage 28 reviewer assessments for one exact project and claim.
- Preserves opposing SUPPORTS and CONTRADICTS directions across distinct passages.
- Separates reviewer disagreement about the same passage from cross-passage conflict.
- Flags explicit differences in population, geography, setting, time period, outcome, intervention, comparator, method and scope.
- Accepts explicit dependency declarations: DERIVED_FROM, DUPLICATES, CITES, SHARES_DATASET and SAME_ORIGIN.
- Adds Stage 28 history integration, report hashing, append-only persistence and project/claim-scoped history.
- Eleven focused Stage 29 tests.

### Interpretation
- `UNRESOLVED_DIRECT_CONTRADICTION`: opposing reviewer-coded directions without explicit context mismatch supplied.
- `APPARENT_CONTRADICTION_CONTEXT_MISMATCH`: opposing directions with explicit context differences.
- `REVIEWER_DISAGREEMENT_ON_SAME_PASSAGE`: different reviewers assigned opposing directions to the same passage.
- Missing context is unknown, not equivalent context.
- Declared dependencies are review signals, not proof of common origin.
- No detected dependency is not proof of source independence.

### Boundaries
No automated semantic inference, winner selection, truth certification, source-independence certification, public route, or model-weight update is introduced. NEUTRAL and INDETERMINATE remain distinct. M-RBAM source and mathematics remain unchanged.
