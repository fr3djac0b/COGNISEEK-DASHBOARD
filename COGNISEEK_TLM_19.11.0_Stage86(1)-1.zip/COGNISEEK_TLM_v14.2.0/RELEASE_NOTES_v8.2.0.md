# COGNISEEK TLM v8.2.0 — Experience Reliability and Adaptation

## What changed
- Adds an experience reliability assessment based on the latest reviewer-entered assessment for each episode/application.
- Distinguishes insufficient history, repeatedly helpful patterns, repeatedly unhelpful patterns, mixed/inconclusive patterns, and stale experiences.
- Adds advisory reuse guidance to future episode experience application responses.
- Adds project-level reliability reporting.
- Stale age is configurable (default 180 days).

## New endpoints
- `GET /api/cognitive-runtime/learning/experience-reliability/{candidate_id}?project=default&stale_after_days=180`
- `GET /api/cognitive-runtime/learning/experience-reliability?project=default&limit=100&stale_after_days=180`

## Classification rules
- Fewer than 3 reviewed applications: `INSUFFICIENT_HISTORY`.
- At least 3, improvement fraction >= 0.67 and worsening fraction <= 0.10: `REPEATEDLY_HELPFUL_PATTERN`.
- At least 3, worsening fraction >= 0.50: `REPEATEDLY_UNHELPFUL_PATTERN`.
- Other adequately sampled patterns: `MIXED_OR_INCONCLUSIVE_PATTERN`.
- Experience older than the configured age threshold: `STALE_EXPERIENCE` (takes precedence).

## Boundaries
- Counts only the latest reviewer assessment per application.
- Unreviewed applications do not count.
- Only currently consolidated experiences can be assessed.
- Results are descriptive heuristics, not calibrated reliability probabilities or causal estimates.
- Reviewer-entered assessments are not independently authenticated or verified.
- Guidance never changes evidence direction, proves truth, or updates model weights.
- No live external acquisition or model training was performed.

## Verification
- Full regression suite: 550 passed, 0 failed.
- New v8.2 tests: 9 passed.
- Python compilation: passed.
- ZIP integrity: passed.
