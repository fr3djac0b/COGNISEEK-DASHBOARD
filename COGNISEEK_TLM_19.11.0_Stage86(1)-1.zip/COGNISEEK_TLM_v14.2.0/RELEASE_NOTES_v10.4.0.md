# COGNISEEK TLM v10.4.0
## Company Policy Authorization and Identity-Governed Publication Hold

This release adds request-scoped authorization assessment with append-only records.

### Added
- `POST /api/requests/{request_id}/authorize`
- `GET /api/requests/{request_id}/authorization-history`
- Project-scoped request lookup before authorization assessment.
- Optional evaluation of an existing integrated evidence workflow under the active company policy.
- Exact-draft SHA-256 binding for each assessment.
- Append-only authorization-attempt records and trace events.

### Deliberate fail-closed boundary
No identity provider, signed-token validation, session authentication, or trusted principal mapping is integrated. Caller-supplied `actor` and `role` are untrusted metadata. Even a company-policy `ALLOW` cannot override the identity hold. Every attempt returns `HOLD_IDENTITY_UNAUTHENTICATED`; publication remains false.

This is an authorization-assessment prototype, not a production identity/access-management system. It does not publish or execute answers or actions.
