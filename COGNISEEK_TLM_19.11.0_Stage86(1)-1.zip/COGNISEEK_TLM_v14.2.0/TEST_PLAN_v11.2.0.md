# v11.2.0 Test Plan

1. Incomplete human review blocks before the release bridge is called.
2. Unresolved reviewer disagreement blocks before the release bridge is called.
3. Cross-project integrated-run access is rejected.
4. Integrated run and decision-cycle report IDs must match.
5. Integrated run and decision-cycle episode IDs must match.
6. Current evidence references must exactly match the cycle evidence references.
7. Workflow selected finding IDs must exactly match current evidence references.
8. Failed/blocked workflows and missing evidence-grounded responses are rejected.
9. Existing bridge policy BLOCK remains blocked and returns no release authorization.
10. Existing bridge ALLOW is delegated and recorded in append-only history.
11. Merely completing review does not automatically call release.
12. Both new FastAPI routes register.
13. Full inherited regression suite runs with a fresh isolated database.
14. Compile all app and test Python files.
15. Verify M-RBAM mathematics module remains byte-for-byte unchanged and verify ZIP integrity.
