# COGNISEEK TLM v3.1.0 — Memory-Use Governance

## Core change
Every `/api/chat` request remains a new episode. Retrieved prior episodes now pass through an explicit memory-use policy before being added to model context. The policy is deterministic and auditable.

## Dispositions
- `CORRECTION_SIGNAL_ONLY`: if a prior episode has a `corrected` or `rejected` outcome, its old answer is withheld from model context. Recorded correction text may be included as an unverified review signal.
- `HISTORICAL_OUTCOME_REQUIRES_REVIEW`: other recorded outcomes (including `confirmed`) do not make the old answer ground truth. The old answer is contextual only and must be reviewed.
- `UNVERIFIED_EPISODIC_CONTEXT`: no outcome exists; the old answer is explicitly labelled unverified and contextual only.

All memory remains distinct from current evidence. Staleness is a review warning, not evidence of falsity. Current evidence still requires its own appraisal.

## New API
- `GET /api/memory/governance?project=default&limit=100`: returns append-only memory-use audit history.

## Chat response additions
- `memory_governance`: per-request dispositions and summary.
- `memory_use_audit`: append-only audit record identity.
- Model context marks every historical memory as `historical_unverified`.

## Boundaries
- This is not semantic truth verification, automatic conflict resolution, or a replacement for claim-level evidence appraisal.
- It does not train model weights, rewrite memories, or alter original episodes.
- The current implementation treats every historical answer as non-authoritative, even when an outcome says `confirmed`; independent current evidence is still needed for factual grounding.
