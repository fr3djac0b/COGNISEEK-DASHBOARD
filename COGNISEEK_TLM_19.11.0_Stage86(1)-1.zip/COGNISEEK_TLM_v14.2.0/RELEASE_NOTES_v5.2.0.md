# COGNISEEK TLM v5.2.0
## Statistical Evidence Intelligence

Built directly on the v5.1.0 Structured Findings Extraction ledger.

### Capabilities
- Creates append-only statistical analysis reports from project-scoped finding IDs.
- Includes only findings whose latest reviewer decisions are unanimously APPROVE.
- Preserves source document, chunk, excerpt and exact offsets in each study profile.
- Validates and profiles reported effect estimates, confidence intervals, p-values, sample sizes, event counts and denominators.
- Calculates study-level standard errors from a reported confidence interval only when the confidence level is explicitly supplied.
- Uses log-scale standard errors for RR/OR/HR families and arithmetic-scale standard errors for RD/MD/SMD families.
- Reports whether an interval includes the conventional null value (1 for ratio measures; 0 for additive measures) as descriptive information only.
- Stratifies findings by outcome, measure, population, follow-up, units, comparator and intervention.
- Stores immutable-by-API statistical report snapshots.

### Endpoints
- `POST /api/statistics/analyze` with `{project, finding_ids}`
- `GET /api/statistics/reports?project=...`
- `GET /api/statistics/reports/{report_id}?project=...`

### Explicit limitations
- No automatic extraction from prose and no imputation of missing values.
- No raw-count effect calculation or continuity correction in this release.
- No pooled effect, meta-analysis, CI-overlap significance test or source-independence certification.
- P-values are reported as source-provided and are not independently recomputed.
- Statistical profiles do not establish truth, causality, clinical importance or study quality.
- Reviewer identities remain supplied strings, as in the underlying v5.1 prototype.

See `TEST_RESULTS_v5.2.0.txt`.
