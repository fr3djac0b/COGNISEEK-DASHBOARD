# COGNISEEK TLM v3.3.0 — Contradiction and Temporal Reasoning

## Added
- `app/temporal_reasoning.py`: append-only, project-scoped evidence-event ledger.
- Records claim key, episode, event time, record time, evidence/source identifiers, source version, SHA-256 content fingerprint, reviewer-entered direction, appraisal before/after, rationale and metadata.
- Distinguishes first-seen evidence, repeated evidence, changed source snapshots, unresolved direction disagreement, and reviewer-explicit relation hints.
- `POST /api/temporal/events`
- `GET /api/temporal/history`
- `GET /api/temporal/compare`
- Direction conflict and appraisal-change diagnostics are explicit; no winner is selected.

## Interpretation and safety boundaries
- A content hash detects byte/text changes in submitted content; it does not authenticate the publisher or prove a source is reliable.
- A repeated identifier is a duplicate/reuse warning, not proof that two different identifiers are independent.
- Different reviewer-coded directions remain unresolved disagreement. The system does not infer which one is correct.
- `CORRECTION`, `INTERPRETATION_CHANGE`, `MISSING_EVIDENCE`, and other relation hints are reviewer-supplied labels, not machine-discovered facts.
- Event timestamps are supplied by caller or recorded locally; chronology is not independently verified.
- `NEUTRAL` and `INDETERMINATE` remain distinct; INDETERMINATE remains compatible with the M-RBAM F4 boundary and is not converted into a directional update.
- No model training, weight updates, automatic truth adjudication, external acquisition, or deployment.

## Validation
See `TEST_RESULTS_v3.3.0.txt`.
