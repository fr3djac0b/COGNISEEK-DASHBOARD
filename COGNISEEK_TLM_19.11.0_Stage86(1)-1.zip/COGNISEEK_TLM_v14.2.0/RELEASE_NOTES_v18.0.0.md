# COGNISEEK TLM v18.0.0

Stage 65: Semantic Evidence Direction. Additive release from immutable v17.8.0 baseline.

Produces conservative direction proposals and exposes lexical evidence; it does not perform NLI or certify entailment.
