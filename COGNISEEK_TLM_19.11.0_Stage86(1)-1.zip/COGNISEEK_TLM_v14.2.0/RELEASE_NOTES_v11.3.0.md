# COGNISEEK TLM v11.3.0 — Persistent Experience and Memory Lifecycle

## Objective
Add a single project-scoped lifecycle controller around the existing retrieval and reviewer-governed consolidation modules.

## Additions
- `app/memory_lifecycle.py`
  - Records each requested adaptive-memory retrieval in a new append-only project ledger.
  - Stores the retrieval run ID, selected memory IDs, counts, warnings, and retrieval policy.
  - Prepares outcome-linked consolidation candidates through the existing consolidation engine.
  - Requires an actor and rationale for lifecycle actions.
  - Records approval, rejection, and revocation events through the existing reviewer workflow.
  - Exposes project-scoped lifecycle history.
- Four API endpoints:
  - `POST /api/cognitive-runtime/memory-lifecycle/retrieve`
  - `POST /api/cognitive-runtime/memory-lifecycle/consolidation-candidates`
  - `POST /api/cognitive-runtime/memory-lifecycle/consolidation-candidates/{candidate_id}/review`
  - `GET /api/cognitive-runtime/memory-lifecycle/history`

## Memory governance
- Retrieval is still historical context, not current evidence.
- Existing adaptive retrieval scoring and staleness heuristics are unchanged.
- Candidate preparation requires a previously recorded episode outcome through the existing memory-consolidation module.
- Candidate approval is not automatic.
- Rejection and revocation remain append-only review events.
- Latest review status controls contextual eligibility in the existing retrieval engine.
- No database memory is treated as ground truth.
- No model weights are updated; this release does not implement neural learning.

## Mathematics
`app/research/m_rbam.py` remains byte-for-byte identical to v11.2.0. No M-RBAM formulas, categories, thresholds, or protocol behaviour were modified.
