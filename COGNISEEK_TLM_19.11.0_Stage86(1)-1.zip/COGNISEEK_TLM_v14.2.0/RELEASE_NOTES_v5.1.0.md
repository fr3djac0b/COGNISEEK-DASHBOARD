# COGNISEEK TLM v5.1.0
## Structured Findings Extraction

Introduces a passage-grounded structured findings ledger with candidate creation, append-only review/correction events, numeric validation and stratified comparison of reviewed findings.

### Endpoints
- `POST /api/findings/candidates`
- `GET /api/findings/candidates`
- `POST /api/findings/reviews`
- `GET /api/findings/reviews`
- `POST /api/findings/compare`

### Governance
- Candidate fields are caller-supplied; no unsupported automatic extraction.
- Exact passage text, chunk ID, document ID and offsets are retained.
- No unreviewed candidate is treated as approved.
- Reviewer disagreement is preserved; approval requires all latest distinct reviewer actions to be APPROVE.
- Corrections are append-only and do not overwrite the original candidate.
- Comparison stratifies incompatible outcomes/metrics/populations/follow-up/comparators; no pooling or truth determination.

### Validation
See `TEST_RESULTS_v5.1.0.txt`.
