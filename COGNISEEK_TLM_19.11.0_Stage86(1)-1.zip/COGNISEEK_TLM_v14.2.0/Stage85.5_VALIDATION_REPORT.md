# COGNISEEK 19.10.5 — Stage85.5 validation

Full unittest discovery exit code: 0
Python compileall exit code: 0
ZIP integrity: PASS
Docker available: False
Docker deployment performed: NO
Live service deployment: NOT VERIFIED

## Test output
```text
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6bc7710>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6bc7810>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6bc7a10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42010>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6bc7b10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6bc7c10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6bc7e10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42510>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6bc7f10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42110>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42210>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42910>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42310>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42410>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42610>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192c0510>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192c0610>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192c0710>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192c0e10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192eb410>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192eb510>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192eb710>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192eba10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192ebc10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d192ebf10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d1930a110>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d1930a210>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d1930a910>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d1930aa10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4d1930ab10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42810>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42a10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42c10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/opt/pyvenv/lib/python3.13/site-packages/torch/nn/modules/module.py:1772: ResourceWarning: unclosed database in <sqlite3.Connection object at 0x7f4cf6c42e10>
  def _wrapped_call_impl(self, *args, **kwargs):
ResourceWarning: Enable tracemalloc to get the object allocation traceback
/usr/lib/python3.13/multiprocessing/popen_fork.py:67: DeprecationWarning: This process (pid=947) is multi-threaded, use of fork() may lead to deadlocks in the child.
  self.pid = os.fork()
----------------------------------------------------------------------
Ran 391 tests in 6.212s

OK

```

## Scope and limitations
Adds SQLite online backup, integrity checking and atomic restore helpers with round-trip tests. Full operational disaster recovery, off-host backup, encryption, retention and point-in-time recovery remain unverified.

Passing tests establish only the behaviours covered by the suite. They do not
prove production readiness or independent operation.
