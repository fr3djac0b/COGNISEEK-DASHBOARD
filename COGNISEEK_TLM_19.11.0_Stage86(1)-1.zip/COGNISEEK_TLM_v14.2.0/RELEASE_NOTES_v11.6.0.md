# COGNISEEK TLM v11.6.0 — API Route Security Inventory

## Purpose
This release adds a source-assisted inventory of registered API routes. It identifies routes whose endpoint source visibly calls the existing project-role guard and flags elevated/high-risk routes where that call is not detected.

## Added
- `app/route_security_audit.py`: route inventory, risk classification and manual-review findings.
- `scripts/route_security_audit.py`: generates a JSON report from the actual FastAPI application.
- `tests/test_v11_6_route_security_audit.py`: focused tests for guarded/unguarded route detection and conservative reporting.

## Run
```bash
python scripts/route_security_audit.py > route_security_inventory.json
python -m pytest -q tests/test_v11_6_route_security_audit.py
python -m pytest -q
```

## Important interpretation
- A finding means the scanner did not detect the explicit project-role guard in the endpoint source. It is a review target, not proof of exploitability.
- A route with a detected guard is not thereby proven secure.
- Global API-key middleware is optional and is not equivalent to per-user/project role authorization.
- The release does not automatically modify endpoint access, role requirements, middleware, or legacy client behavior.
- Manual route-by-route review and request-level authorization tests are required before security claims.
- This is not a penetration test or production certification.

## Preservation
No M-RBAM formulas, thresholds, labels, or protocol definitions are changed.
